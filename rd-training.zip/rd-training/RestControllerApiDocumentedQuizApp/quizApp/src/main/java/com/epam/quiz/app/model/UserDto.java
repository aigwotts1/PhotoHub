package com.epam.quiz.app.model;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserDto {

	@NotBlank(message = "username cannot be blank")
	private String username;
	
	@NotBlank(message = "password cannot be blank")
	private String password;

	private boolean isAdmin;

	public UserDto() {
	}
	
	public UserDto(String user_name, String password, boolean isAdmin) {
		this.username = user_name;
		this.password = password;
		this.isAdmin = isAdmin;
	}

	public UserDto(String user_name, String password) {
		this.username = user_name;
		this.password = password;
	}
}