package com.epam.quiz.app.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(unique = true)
	private String title;
	
	

	@ElementCollection
	private List<String> options = new ArrayList<>();
	
	private String dificulty;
	private String topics;
	private int answer;
	private int marks;

	
	
	

	public Question() {
	}

	public Question(String title, List<String> options, String dificulty, String topics, int answer) {
		this.title = title;
		this.options = options;
		this.dificulty = dificulty;
		this.topics = topics;
		this.answer = answer;
	}
}