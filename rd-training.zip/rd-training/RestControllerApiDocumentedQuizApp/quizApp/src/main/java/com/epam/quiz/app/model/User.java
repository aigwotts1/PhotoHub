package com.epam.quiz.app.model;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Component
@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(unique = true)
	private String username;
	private String password;
	@Column(name = "is_admin")
	private boolean isAdmin;

	public User() {
	}

	public User(String user_name, String password, boolean isAdmin) {
		this.username = user_name;
		this.password = password;
		this.isAdmin = isAdmin;
	}

	public User(String user_name, String password) {
		this.username = user_name;
		this.password = password;
	}
}