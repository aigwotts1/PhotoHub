package com.epam.quiz.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@Controller
public class UserQuizAttemptController {
	
	@Autowired
	QuizService quizService;
	
	@Autowired
	QuestionService questionService;

	@RequestMapping("attemptQuiz")
	public ModelAndView attemptQuiz(String title) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("attemptQuiz");
		modelAndView.addObject("quiz", quizService.getQuizByTitle(title));

		return modelAndView;
	}

	@RequestMapping("getResult")
	public ModelAndView getResult(String quizTitle, String userInput) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("displayScore");
		String userInputs[] = userInput.trim().split("\\r?\\n");
		int inputs[] = new int[userInputs.length];
		for(int i = 0; i<inputs.length; i++) {
			inputs[i] = Integer.parseInt(userInputs[i]);
		}
		QuizDto quiz = quizService.getQuizByTitle(quizTitle);
		int totalMarks = quiz.getTotal_marks();
		int scoredMarks = 0;
		for (int i = 0; i < quiz.getQuestionList().size(); i++) {
			if(i <= inputs.length) {
				Question question = quiz.getQuestionList().get(i);
				if (inputs[i]==question.getAnswer()) {
					scoredMarks += question.getMarks();
				}	
			}	
		}
		modelAndView.addObject("scoredMarks", scoredMarks);
		modelAndView.addObject("totalMarks", totalMarks);
		
		return modelAndView;
	}
}