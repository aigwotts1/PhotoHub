package com.epam.quiz.app.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.constants.Constant;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.service.QuestionService;

@Controller
public class QuestionController {

	@Autowired
	QuestionService questionService;

	private static final Logger LOGGER = LogManager.getLogger(QuestionController.class);

	
	ModelAndView modelAndView = new ModelAndView();

	@GetMapping("displayAllQuestions")
	public ModelAndView getAllQuestions() {
		
		try {
			modelAndView.setViewName(Constant.DISPLAY_QUESTION);
			modelAndView.addObject(Constant.DISPLAY_QUESTION, questionService.viewAllQuestions());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, e.getMessage());
		}
		return modelAndView;
	}

	@RequestMapping("createQuestion")
	public ModelAndView createQuestion(QuestionDto questionDto) {
		try {
			questionService.createQuestion(questionDto);
			modelAndView.setViewName(Constant.DISPLAY_QUESTION);
			modelAndView.addObject(Constant.DISPLAY_QUESTION, questionService.viewAllQuestions());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE,"Question Cannot Be Created :(");
		}
		return modelAndView;
	}

	@RequestMapping("deleteQuestion")
	public ModelAndView deleteQuestion(String title) {
		try {
			questionService.removeQuestion(title);
			modelAndView.setViewName(Constant.DISPLAY_QUESTION);
			modelAndView.addObject(Constant.DISPLAY_QUESTION, questionService.viewAllQuestions());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE,"Question Present In Quiz i.e. Cannot Be Deleted :(");
		}
		return modelAndView;
	}

	@RequestMapping("modifyQuestion")
	public ModelAndView modifyQuestion(QuestionDto questionDto, int marks) {
		try {
			questionService.modifyQuestion(questionDto, marks);
			modelAndView.setViewName(Constant.DISPLAY_QUESTION);
			modelAndView.addObject(Constant.DISPLAY_QUESTION, questionService.viewAllQuestions());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, e.getMessage());
		}
		return modelAndView;
	}

	@GetMapping("modifyQuestionFromDisplayer")
	public ModelAndView modify(String title) {
		try {
			modelAndView.setViewName("modifyQuestion");
			QuestionDto questionDto = questionService.viewQuestion(title);
			modelAndView.addObject("question", questionDto);
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, e.getMessage());
		}

		return modelAndView;
	}
}