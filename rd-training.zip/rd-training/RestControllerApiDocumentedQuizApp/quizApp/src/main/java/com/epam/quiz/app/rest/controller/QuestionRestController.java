package com.epam.quiz.app.rest.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.service.QuestionService;

import jakarta.validation.Valid;

@RestController
public class QuestionRestController {

	@Autowired
	QuestionService questionService;

	@Autowired
	ModelMapper modelMapper;

	@PostMapping("create_questions")
	public ResponseEntity<QuestionDto> createQuestion(@RequestBody QuestionDto questionDto) {
			return new ResponseEntity<>(questionService.createQuestion(questionDto),HttpStatus.CREATED);
		
	}

	@DeleteMapping("delete_questions")
	public ResponseEntity<Void> deleteQuestion(@RequestBody QuestionDto questionDto) {
		
			questionService.removeQuestion(questionDto.getTitle());
			return new ResponseEntity<>(HttpStatus.OK);
		
	}

	@PutMapping("modify_questions")
	public ResponseEntity<QuestionDto> modifyQuestion(@RequestBody @Valid QuestionDto questionDto) {
		
			return new ResponseEntity<>(questionService.modifyQuestion(questionDto,questionDto.getMarks()),HttpStatus.OK);
		
	}

	@GetMapping("display_all_questions_present")
	public ResponseEntity<List<QuestionDto>> getAllQuestions() {
		
			Map<String, Question> questionsMap = questionService.viewAllQuestions();
			List<QuestionDto> questionsList = new ArrayList<>();
			questionsMap.values().forEach(question -> {
				modelMapper = new ModelMapper();
				QuestionDto questionDTO = modelMapper.map(question, QuestionDto.class);
				questionsList.add(questionDTO);
			});
			return new ResponseEntity<>(questionsList,HttpStatus.OK);
		
			
	}

	@GetMapping("get_questions_by_title")
	public ResponseEntity<QuestionDto> getQuestion(@RequestBody QuestionDto questionDto) {
		
			return new ResponseEntity<>(questionService.viewQuestion(questionDto.getTitle()),HttpStatus.ACCEPTED);
		
	}

}