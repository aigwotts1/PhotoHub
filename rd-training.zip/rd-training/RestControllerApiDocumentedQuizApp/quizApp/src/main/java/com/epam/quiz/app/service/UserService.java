package com.epam.quiz.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.exceptions.UserException;
import com.epam.quiz.app.model.User;
import com.epam.quiz.app.model.UserDto;
import com.epam.quiz.app.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ModelMapper modelMapper;

	public UserDto addUser(String userName, String password) {
		
		User user = new User();
		user.setUsername(userName);
		user.setPassword(password);
		user = userRepository.save(user);
		return modelMapper.map(user,UserDto.class);
	}

	public UserDto getUser(String userName, String password) {
    	return modelMapper.map(userRepository.findUserByUsernameAndPassword(userName,password).orElseThrow(()-> new UserException("User Not Present :(")),UserDto.class);
	}
}