package com.epam.quiz.app.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionBuilder {
	
	private String title;
	private List<String> options = new ArrayList<>();
	private String dificulty;
	private String topics;
	private int answer;

	public QuestionBuilder setTitle(String title) {
		if(title != null) {
			 this.title = title;	
		}
		return this;
	}
	public QuestionBuilder setOptions(List<String> options) {
		if(!options.isEmpty()) {
			this.options = options;
		}
		return this;
	}
	public QuestionBuilder setDificulty(String dificulty) {
		if(dificulty != null) {
			this.dificulty = dificulty;	
		}
		return this;
	}
	public QuestionBuilder setTopics(String topics) {
		if(topics!=null) {
			this.topics = topics;		
		}
		return this;
	}
	public QuestionBuilder setAnswer(int answer) {
		if(answer != 0) {
			this.answer = answer;		
		}
		return this;
	}

	public Question getQuestionBuilder() {
		return new Question(title, options, dificulty, topics, answer);
	}
}