package com.epam.quiz.app.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.exceptions.QuestionException;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.repository.QuestionRepository;

@Service
public class QuestionService {

	Question question;
	
	@Autowired
	ModelMapper mapper;

	@Autowired
	QuestionRepository questionRepository;

	public QuestionDto createQuestion(QuestionDto questionDto) {

		validateOptions(questionDto);
		validateAnswerNumber(questionDto);
		question = mapper.map(questionDto, Question.class);

		question = questionRepository.save(question);
		return mapper.map(question,QuestionDto.class);
	}

	public QuestionDto viewQuestion(String title) {
		question = questionRepository.findQuestionByTitle(title).orElseThrow(() -> new QuestionException("Question not found"));
		return mapper.map(question,QuestionDto.class);
	
	}

	public Map<String, Question> viewAllQuestions() {
		List<Question> list = (List<Question>) questionRepository.findAll();
		return list.stream().collect(Collectors.toMap(Question::getTitle, Function.identity()));
	}

	public void removeQuestion(String title) {
		Optional<Question> optionalQuestion = questionRepository.findQuestionByTitle(title);
		questionRepository.delete(optionalQuestion.orElseThrow(() -> new QuestionException("Question not found i.e. Cannot be Deleted")));	
	}

	public QuestionDto modifyQuestion(QuestionDto questionDto, int marks) {
		validateOptions(questionDto);
		validateAnswerNumber(questionDto);
		question = questionRepository.findQuestionByTitle(questionDto.getTitle()).orElseThrow();
		int id = question.getId();
		question = mapper.map(questionDto, Question.class);
		question.setId(id);
		question.setMarks(marks);
		question = questionRepository.save(question);
		return mapper.map(question, QuestionDto.class);
	}

	private void validateAnswerNumber(QuestionDto questionDto) {
		if (questionDto.getOptions().size() < questionDto.getAnswer()) {
			throw new QuestionException("Invalid Answer Number :(");
		}
	}

	private void validateOptions(QuestionDto questionDto) {
		if (questionDto.getOptions().size() < 2) {
			throw new QuestionException("Less than two options found :(");
		}
	}
}