package com.epam.quiz.app.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.constants.Constant;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@Controller
public class QuizController {

	@Autowired
	QuizService quizService;

	@Autowired
	QuestionService questionService;

	private static final Logger LOGGER = LogManager.getLogger(QuizController.class);

	ModelAndView modelAndView = new ModelAndView();

	@GetMapping("displayAllQuizes")
	public ModelAndView getQuiz() {
		try {
			modelAndView.setViewName(Constant.DISPLAY_QUIZ);
			modelAndView.addObject(Constant.QUIZ, quizService.viewAllQuiz());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, "Error Displaying Quizes:(");
		}
		return modelAndView;
	}

	@GetMapping(value = "deleteQuiz")
	public ModelAndView deleteQuiz(String title) {
		try {
			quizService.removeQuiz(title);
			modelAndView.setViewName(Constant.DISPLAY_QUIZ);
			modelAndView.addObject(Constant.QUIZ, quizService.viewAllQuiz());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, "Quiz Deletion Error :(");
		}
		return modelAndView;
	}

	@PostMapping("createQuiz")
	public ModelAndView createQuiz(QuizDto quizDto) {
		try {
			quizService.addQuiz(quizDto);
			modelAndView.setViewName(Constant.DISPLAY_QUIZ);
			modelAndView.addObject(Constant.QUIZ, quizService.viewAllQuiz());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, "Quiz Already Present With This Title :(");
		}
		return modelAndView;
	}

	@PostMapping("modifyAddQuestion")
	public ModelAndView addQuestion(String quizTitle, String questionTitle, String marks) {
		try {
			quizService.modifyQuiz(quizTitle, questionTitle, marks);
			modelAndView.setViewName(Constant.DISPLAY_QUIZ);
			modelAndView.addObject(Constant.QUIZ, quizService.viewAllQuiz());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, e.getMessage());
		}

		return modelAndView;
	}

	@GetMapping("addQuestionToQuizModification")
	public ModelAndView modify(String title) {
		try {
			modelAndView.addObject("questions", questionService.viewAllQuestions());
			modelAndView.setViewName("modifyQuiz");
			modelAndView.addObject("quizTitle", title);
			modelAndView.addObject("questionsPresentInQuiz", quizService.getQuizByTitle(title).getQuestionList());
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, "Quiz Modification Fail :(");
		}
		return modelAndView;
	}

	@PostMapping("modifyRemoveQuestion")
	public ModelAndView removeQuestion(String quizTitle, String questionTitle) {

		try {
			modelAndView.setViewName(Constant.DISPLAY_QUIZ);
			modelAndView.addObject(Constant.QUIZ, quizService.viewAllQuiz());
			quizService.modifyQuizRemoveQuestion(quizTitle, questionTitle);
		} catch (RuntimeException e) {
			LOGGER.error(e);
			modelAndView.setViewName(Constant.ERROR_PAGE);
			modelAndView.addObject(Constant.ERROR_MESSAGE, "Quiz Question Removal Failure :(");
		}

		return modelAndView;
	}

}