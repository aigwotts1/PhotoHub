package com.epam.quiz.app.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.exceptions.QuizException;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.repository.QuestionRepository;
import com.epam.quiz.app.repository.QuizRepository;

@Service
public class QuizService {

	@Autowired
	QuizRepository quizRepository;
	
	Quiz quiz;
	Question question;
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	public Map<String,Quiz> viewAllQuiz() {
		List<Quiz> listOfQuiz = (List<Quiz>) quizRepository.findAll();
		return listOfQuiz.stream().collect(Collectors.toMap(Quiz::getTitle,x->x));
	}
	
	public QuizDto addQuiz(QuizDto quizDto) {
		quiz = modelMapper.map(quizDto, Quiz.class);

		return modelMapper.map(quizRepository.save(quiz), QuizDto.class);
	}
	
	public QuizDto getQuizByTitle(String title) {
		quiz = quizRepository.findByTitle(title).orElseThrow(() -> new QuizException("Quiz not found :("));
		return modelMapper.map(quiz, QuizDto.class);
	}
	
	public void removeQuiz(String title) {
		quiz = quizRepository.findByTitle(title).orElseThrow(() -> new QuizException("Quiz not found :( thus Quiz Cannot be deleted"));
		quizRepository.delete(quiz);
	}
	
	public QuizDto modifyQuiz(String quizTitle, String questionTitle, String marks) {
		
		quiz = quizRepository.findByTitle(quizTitle).orElseThrow(() -> new QuizException("Quiz not found :( cannot be modified"));
		question = questionRepository.findQuestionByTitle(questionTitle).orElseThrow(()-> new QuizException("Question Not Present :("));
		if(quiz.getQuestionList().contains(question)) {
			throw new QuizException("Question Already Present In Quiz");
		}
		question.setMarks(Integer.parseInt(marks));
		
		quiz.setTotal_marks(quiz.getTotal_marks()+Integer.parseInt(marks));
		quiz.getQuestionList().add(question);
		
		return modelMapper.map(quizRepository.save(quiz),QuizDto.class);
	}
	
	public QuizDto modifyQuizRemoveQuestion(String quizTitle,String questionTitle) {
		quiz = quizRepository.findByTitle(quizTitle).orElseThrow(() -> new QuizException("Quiz not found :("));
		question = questionRepository.findQuestionByTitle(questionTitle).orElseThrow(()-> new QuizException("Question Not Present :("));
		List<Question> list = quiz.getQuestionList();
		list.remove(question);
		quiz.setTotal_marks(quiz.getTotal_marks() - question.getMarks());
		quiz.setQuestionList(list);
		return modelMapper.map(quizRepository.save(quiz),QuizDto.class);
	}
}
