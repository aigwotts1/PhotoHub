package com.epam.quiz.app.model;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.Range;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class QuizDto {
	
	@NotBlank(message = "title cannot be blank")
	private String title;
	List<Question> questionList = new ArrayList<>();
	@Range(min = 1, max = 100)
	private int total_marks;
	
}