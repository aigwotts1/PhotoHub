package com.epam.quiz.app.exceptions;

public class QuestionException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public QuestionException(String message) {
		super(message);
	}
}
