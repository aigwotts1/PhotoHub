package com.epam.quiz.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.constants.Constant;
import com.epam.quiz.app.model.UserDto;
import com.epam.quiz.app.service.UserService;

@Controller
public class AuthenticationController {
	
	@Autowired
	UserService userService;
	
	ModelAndView modelAndView = new ModelAndView();


	@PostMapping("register")
	public ModelAndView register(String username, String password) {
		try {
            modelAndView.setViewName("userPage");
            modelAndView.addObject("user", userService.addUser(username, password));
        } catch (RuntimeException e) {
            modelAndView.setViewName("authenticationError");
            modelAndView.addObject(Constant.ERROR_MESSAGE, "Username Already Present :(");
        }
        return modelAndView;
	}

	@PostMapping("login")
	public ModelAndView login(String username, String password) {
		try {
            UserDto user = userService.getUser(username,password);
            if (user.isAdmin()) {
                modelAndView.setViewName("adminPage");
            } else {
                modelAndView.setViewName("userPage");
            }
            modelAndView.addObject(user);
        } catch (RuntimeException e) {
            modelAndView.setViewName("authenticationError");
            modelAndView.addObject(Constant.ERROR_MESSAGE, "User Does Not Exist or Incorrect Details :(");
        }
        return modelAndView;
	}
}