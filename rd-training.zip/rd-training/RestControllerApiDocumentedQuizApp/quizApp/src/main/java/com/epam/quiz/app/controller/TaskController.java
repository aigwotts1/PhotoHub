package com.epam.quiz.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TaskController {

	@RequestMapping("/")
	public String start() {
		return "home";
	}
}
