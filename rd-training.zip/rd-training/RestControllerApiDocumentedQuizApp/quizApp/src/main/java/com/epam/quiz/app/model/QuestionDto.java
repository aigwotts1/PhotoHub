package com.epam.quiz.app.model;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class QuestionDto {
	
	@NotBlank(message = "title cannot be blank")
	private String title;
	
	@Size(min = 2)
	private List<String> options;
	
	@NotBlank(message = "Difficulty Level cannot be blank")
	private String dificulty;

	
	@NotBlank(message = "related Topics cannot be blank")
	private String topics;
	
	
	private int answer;
	
	
	private int marks;
	
}