package com.epam.quiz.app.rest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

import jakarta.validation.Valid;

@RestController
public class QuizRestController {

	@Autowired
	QuizService quizService;

	@Autowired
	QuestionService questionService;

	@Autowired
	ModelMapper modelMapper;

	@DeleteMapping("delete_quiz")
	public ResponseEntity<Void> removeQuizByTitle(@RequestBody QuizDto quizDto) {

		quizService.removeQuiz(quizDto.getTitle());
		return new ResponseEntity<>(HttpStatus.OK);

	}

	@PostMapping("create_quiz")
	public ResponseEntity<QuizDto> addQuiz(@RequestBody @Valid QuizDto quizDto) {

		return new ResponseEntity<>(quizService.addQuiz(quizDto),HttpStatus.CREATED);

	}

	@GetMapping("quizes")
	public ResponseEntity<List<QuizDto>> getAllQuiz() {

		Map<String, Quiz> quizMap = quizService.viewAllQuiz();
		List<QuizDto> quizList = new ArrayList<>();
		quizMap.values().forEach(quiz -> {
			modelMapper = new ModelMapper();
			QuizDto quizDtoRest = modelMapper.map(quiz, QuizDto.class);
			quizList.add(quizDtoRest);
		});
		return new ResponseEntity<>(quizList,HttpStatus.OK);

	}

	@GetMapping("get_quiz_by_title")
	public ResponseEntity<QuizDto> getQuiz(@RequestBody QuizDto quizDto) {

		return new ResponseEntity<>(quizService.getQuizByTitle(quizDto.getTitle()),HttpStatus.ACCEPTED);

	}

	@PostMapping("modify_quiz/{quizTitle}/{questionTitle}/{marks}")
	public ResponseEntity<QuizDto> modifyQuiz(@PathVariable String quizTitle , @PathVariable String questionTitle,
			@PathVariable String marks) {

		return new ResponseEntity<>(quizService.modifyQuiz(quizTitle, questionTitle, marks),HttpStatus.OK);

	}

	@DeleteMapping("remove_quiz_question")
	public ResponseEntity<QuizDto> removeQuizQuestion(@RequestParam String quizTitle, @RequestParam String questionTitle) {

		return new ResponseEntity<>(quizService.modifyQuizRemoveQuestion(quizTitle, questionTitle),HttpStatus.OK);

	}

}