package com.epam.quiz.app.exceptions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class RestControllerExceptionHandler {

	private static final Logger LOGGER = LogManager.getLogger(RestControllerExceptionHandler.class);

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ExceptionResponse handleMethodArgumentNotValidException(MethodArgumentNotValidException ex, WebRequest req) {
		List<String> errors = new ArrayList<>();
		ex.getAllErrors().forEach(err -> errors.add(err.getDefaultMessage()));
		LOGGER.error(ex);
		return new ExceptionResponse(new Date().toString(), HttpStatus.NOT_FOUND.name(),
				errors.toString(), req.getDescription(false));
	}

	@ExceptionHandler(UserException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ExceptionResponse handleUserException(UserException ex, WebRequest req) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date().toString(), HttpStatus.NOT_FOUND.name(),
				ex.getMessage(), req.getDescription(false));
		LOGGER.error(ex);
		return exceptionResponse;
	}

	@ExceptionHandler(QuizException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ExceptionResponse handleQuizException(QuizException ex, WebRequest req) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date().toString(), HttpStatus.NOT_FOUND.name(),
				ex.getMessage(), req.getDescription(false));
		LOGGER.error(ex);
		return exceptionResponse;
	}

	@ExceptionHandler(QuestionException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ExceptionResponse handleQuestionException(QuestionException ex, WebRequest req) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date().toString(), HttpStatus.NOT_FOUND.name(),
				ex.getMessage(), req.getDescription(false));
		LOGGER.error(ex);
		return exceptionResponse;
	}
}