package com.epam.quiz.app.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.epam.quiz.app.model.Quiz;

public interface QuizRepository extends CrudRepository<Quiz,Integer> {

	Optional<Quiz> findByTitle(String title);
}
