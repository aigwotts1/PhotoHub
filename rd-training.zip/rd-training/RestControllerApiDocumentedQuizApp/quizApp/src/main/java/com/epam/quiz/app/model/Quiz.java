package com.epam.quiz.app.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(unique = true)
	private String title;
	
	@ManyToMany
	@JoinTable(name = "quiz_question",joinColumns = @JoinColumn(name = "quiz_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "question_id", referencedColumnName = "id"))
	private List<Question> questionList = new ArrayList<>();
	
	private int total_marks;

	public Quiz() {
	}

	public Quiz(String title, List<Question> questionList) {
		this.title = title;
		this.questionList = questionList;
	}

	public Quiz(String title, List<Question> questionList, int total_marks) {
		this.title = title;
		this.questionList = questionList;
		this.total_marks = total_marks;
	}
}