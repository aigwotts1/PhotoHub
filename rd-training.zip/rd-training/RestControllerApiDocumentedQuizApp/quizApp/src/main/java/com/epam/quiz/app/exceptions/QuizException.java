package com.epam.quiz.app.exceptions;

public class QuizException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public QuizException(String message) {
		super(message);
	}
}
