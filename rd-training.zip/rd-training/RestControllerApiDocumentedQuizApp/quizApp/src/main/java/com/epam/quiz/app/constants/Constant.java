package com.epam.quiz.app.constants;

public class Constant {
	private Constant() {
	}
	public static final String SUCCESS = "success";
	public static final String MESSAGE = "message";
	public static final String QUESTION = "question";
	public static final String DISPLAY_QUESTION = "displayQuestions";
	public static final String ERROR_PAGE = "errorPage";
	public static final String ERROR_MESSAGE ="errorMessage";
	public static final String DISPLAY_QUIZ = "displayQuiz";
	public static final String QUIZ = "quiz";
				
}