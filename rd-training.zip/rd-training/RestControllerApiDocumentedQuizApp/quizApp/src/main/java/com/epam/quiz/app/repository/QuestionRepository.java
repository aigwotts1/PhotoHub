package com.epam.quiz.app.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.epam.quiz.app.model.Question;

public interface QuestionRepository extends CrudRepository<Question, Integer> {
	
	Optional<Question> findQuestionByTitle(String title);
	
}
