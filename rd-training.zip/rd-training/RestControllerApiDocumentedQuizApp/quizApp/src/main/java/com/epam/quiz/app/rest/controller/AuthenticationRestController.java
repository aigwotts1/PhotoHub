package com.epam.quiz.app.rest.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.epam.quiz.app.model.UserDto;
import com.epam.quiz.app.service.UserService;

import jakarta.validation.Valid;

@RestController
public class AuthenticationRestController {
	
	@Autowired
	UserService userService;
	
	ModelMapper modelMapper = new ModelMapper();

	@PostMapping("register_user")
	public ResponseEntity<UserDto> register(@RequestBody @Valid UserDto userDto) {
		
			return new ResponseEntity<>(userService.addUser(userDto.getUsername(), userDto.getPassword()),HttpStatus.CREATED);
		
	}

	@GetMapping("login_user")
	public ResponseEntity<UserDto> login(@RequestBody @Valid UserDto userDto) {
		
			return new ResponseEntity<>(userService.getUser(userDto.getUsername(),userDto.getPassword()),HttpStatus.OK);
		
	}
}
