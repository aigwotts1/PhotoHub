package com.epam.quiz.app.tests.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.constants.Constant;
import com.epam.quiz.app.controller.AuthenticationController;
import com.epam.quiz.app.model.UserDto;
import com.epam.quiz.app.service.UserService;

@WebMvcTest(AuthenticationController.class)
class AuthenticationControllerTest {
	
	@Autowired
	MockMvc mockMvc;
	
    @MockBean
    UserService userService;

    @Test
    void happyPath_RegisterTest() throws Exception {
        UserDto dummyUser = new UserDto("testuser", "testpassword", false);
        when(userService.addUser(anyString(), anyString())).thenReturn(dummyUser);

        MvcResult mvcResult = mockMvc.perform(post("/register")
                .param("username", "testuser")
                .param("password", "testpassword"))
                .andReturn();

        ModelAndView modelAndView = mvcResult.getModelAndView();
        assertEquals("userPage", modelAndView.getViewName());
        assertEquals(dummyUser, modelAndView.getModel().get("user"));

        verify(userService).addUser("testuser", "testpassword");
    }

    @Test
    void sadPath_TestRegisterWithDuplicateUsername() throws Exception {
        when(userService.addUser("testuser", "testpassword"))
                .thenThrow(new DataIntegrityViolationException("Duplicate username"));

        mockMvc.perform(MockMvcRequestBuilders.post("/register")
                .param("username", "testuser")
                .param("password", "testpassword"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("authenticationError"))
                .andExpect(MockMvcResultMatchers.model().attribute(Constant.ERROR_MESSAGE, "Username Already Present :("));

        verify(userService).addUser("testuser", "testpassword");
    }
    
    @Test
    void happyPath_TestLoginAsAdmin() throws Exception {
        String username = "admin";
        String password = "password";
        UserDto user = new UserDto(username, password, true);

        when(userService.getUser(username, password)).thenReturn(user);

        mockMvc.perform(post("/login")
                .param("username", username)
                .param("password", password))
                .andExpect(status().isOk())
                .andExpect(view().name("adminPage"));

        verify(userService, times(1)).getUser(username, password);
        verifyNoMoreInteractions(userService);
    }

    @Test
    void happyPath_TestLoginAsUser() throws Exception {
        String username = "user";
        String password = "password";
        UserDto user = new UserDto(username, password, false);

        when(userService.getUser(username, password)).thenReturn(user);

        mockMvc.perform(post("/login")
                .param("username", username)
                .param("password", password))
                .andExpect(status().isOk())
                .andExpect(view().name("userPage"));
        verify(userService, times(1)).getUser(username, password);
        verifyNoMoreInteractions(userService);
    }
    
    @Test
    void sadPath_TestLoginWithInvalidCredentials() throws Exception {
        when(userService.getUser("invaliduser", "invalidpassword"))
                .thenThrow(new NoSuchElementException("User not found"));

        mockMvc.perform(MockMvcRequestBuilders.post("/login")
                .param("username", "invaliduser")
                .param("password", "invalidpassword"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("authenticationError"))
                .andExpect(MockMvcResultMatchers.model().attribute(Constant.ERROR_MESSAGE, "User Does Not Exist or Incorrect Details :("));

        verify(userService).getUser("invaliduser", "invalidpassword");
    }
}