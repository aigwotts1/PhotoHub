package com.epam.quiz.app.tests.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.constants.Constant;
import com.epam.quiz.app.controller.QuizController;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@WebMvcTest(QuizController.class)
class QuizControllerTest {

	@MockBean
	QuizService quizService;

	@MockBean
	QuestionService questionService;

	@Autowired
	MockMvc mockMvc;

	@Test
	void happyPath_TestDeleteQuiz() throws Exception {

		String title = "some title";

		mockMvc.perform(get("/deleteQuiz").param("title", title)).andExpect(status().isOk())
				.andExpect(view().name("displayQuiz"));
		verify(quizService, times(1)).removeQuiz(title);
	}

	@Test
	void happyPath_TestCreateQuiz() throws Exception {
		Quiz quiz = new Quiz();
		String title = "Quiz1";
		quiz.setTitle(title);
		quiz.setTotal_marks(0);
		QuizDto quizDto = new QuizDto();
		quizDto.setTitle(title);

		when(quizService.addQuiz(quizDto)).thenReturn(quizDto);

		mockMvc.perform(MockMvcRequestBuilders.post("/createQuiz").flashAttr("quizDto", quizDto))
				.andExpect(status().isOk()).andExpect(view().name("displayQuiz"))
				.andExpect(model().attributeExists("quiz"));
		verify(quizService).addQuiz(quizDto);
	}

	@Test
	void sadPath_TestCreateQuizWithDuplicateTitle() throws Exception {
		QuizDto quizDto = new QuizDto();
		quizDto.setTitle("Test Quiz");

		when(quizService.addQuiz(any(QuizDto.class))).thenThrow(DataIntegrityViolationException.class);

		mockMvc.perform(post("/createQuiz").flashAttr("quizDto", quizDto)).andExpect(status().isOk())
				.andExpect(view().name(Constant.ERROR_PAGE)).andExpect(model().attributeExists(Constant.ERROR_MESSAGE));

		verify(quizService).addQuiz(quizDto);
	}

	@Test
	void happyPath_TestAddQuestion() throws Exception {
		String title = "some quiz title";
		String questionTitle = "some question title";
		String marks = "5";
		ModelAndView expectedModelAndView = new ModelAndView("modifyQuiz");
		expectedModelAndView.addObject("quizTitle", title);

		mockMvc.perform(post("/modifyAddQuestion").param("quizTitle", title).param("questionTitle", questionTitle)
				.param("marks", marks)).andExpect(status().isOk());
	}

	@Test
	void sadPath_TestModifyQuizException() throws Exception {
		String quizTitle = "Sample Quiz";
		when(quizService.getQuizByTitle(quizTitle)).thenThrow(new RuntimeException("Quiz not found"));

		mockMvc.perform(get("/addQuestionToQuizModification").param("title", quizTitle)).andExpect(status().isOk())
				.andExpect(view().name(Constant.ERROR_PAGE))
				.andExpect(model().attribute(Constant.ERROR_MESSAGE, "Quiz Modification Fail :("))
				.andExpect(model().attributeExists("questions")).andExpect(model().attribute("quizTitle", quizTitle));

		verify(quizService).getQuizByTitle(quizTitle);
	}

	@Test
	void sadPath_TestGetQuizException() throws Exception {
		RuntimeException exception = new RuntimeException("Test Exception");

		when(quizService.viewAllQuiz()).thenThrow(exception);

		mockMvc.perform(get("/displayAllQuizes")).andExpect(status().isOk()).andExpect(view().name(Constant.ERROR_PAGE))
				.andExpect(model().attribute(Constant.ERROR_MESSAGE, "Error Displaying Quizes:("));
	}

	@Test
	void sadPath_TestAddQuestionWithNoSuchElementException() throws Exception {
		String quizTitle = "Test Quiz";
		String questionTitle = "Test Question";
		String marks = "10";

		when(quizService.modifyQuiz(anyString(), anyString(), anyString())).thenThrow(NoSuchElementException.class);

		mockMvc.perform(post("/modifyAddQuestion").param("quizTitle", quizTitle).param("questionTitle", questionTitle)
				.param("marks", marks)).andExpect(status().isOk()).andExpect(view().name(Constant.ERROR_PAGE));

		verify(quizService).modifyQuiz(quizTitle, questionTitle, marks);
	}

	@Test
	void happyPath_TestRemoveQuestion() throws Exception {
		String quizTitle = "Math Quiz";
		String questionTitle = "What is 2 + 2?";

		Quiz quiz = new Quiz();
		quiz.setTitle(quizTitle);
		List<Question> questionList = new ArrayList<>();
		Question question1 = new Question();
		question1.setTitle("What is 2 + 2?");
		questionList.add(question1);
		Question question2 = new Question();
		question2.setTitle("What is 3 + 3?");
		questionList.add(question2);
		quiz.setQuestionList(questionList);

		Map<String, Quiz> quizMap = new HashMap<>();
		quizMap.put(quizTitle, quiz);

		when(quizService.viewAllQuiz()).thenReturn(quizMap);

		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.post("/modifyRemoveQuestion").param("quizTitle", quizTitle)
						.param("questionTitle", questionTitle))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.view().name(Constant.DISPLAY_QUIZ)).andReturn();

		ModelAndView modelAndView = result.getModelAndView();

		verify(quizService, times(1)).viewAllQuiz();
		verify(quizService, times(1)).modifyQuizRemoveQuestion(quizTitle, questionTitle);

		verifyNoMoreInteractions(quizService, questionService);

		assertEquals(Constant.DISPLAY_QUIZ, modelAndView.getViewName());

		@SuppressWarnings("unchecked")
		Map<String, Quiz> returnedQuizMap = (Map<String, Quiz>) modelAndView.getModel().get(Constant.QUIZ);

		assertTrue(returnedQuizMap.containsKey(quizTitle));

		Quiz returnedQuiz = returnedQuizMap.get(quizTitle);

		assertTrue(returnedQuiz.getQuestionList().contains(question1));
		assertTrue(returnedQuiz.getQuestionList().contains(question2));
	}

	@Test
	void sadPath_TestDeleteQuizException() throws Exception {
		String title = "Quiz 1";
		RuntimeException exception = new RuntimeException("Test Exception");

		doThrow(exception).when(quizService).removeQuiz(title);

		mockMvc.perform(get("/deleteQuiz").param("title", title)).andExpect(status().isOk())
				.andExpect(view().name(Constant.ERROR_PAGE))
				.andExpect(model().attribute(Constant.ERROR_MESSAGE, "Quiz Deletion Error :("));

		verify(quizService, times(1)).removeQuiz(title);
	}

	@Test
	void happyPath_TestModify() throws Exception {
		Map<String, Question> questions = new HashMap<>();

		Mockito.when(questionService.viewAllQuestions()).thenReturn(questions);

		String title = "Quiz 1";
		List<Question> questionsInQuiz = new ArrayList<>();

		QuizDto quiz = new QuizDto();
		quiz.setTitle(title);
		quiz.setQuestionList(questionsInQuiz);
		Mockito.when(quizService.getQuizByTitle(title)).thenReturn(quiz);

		mockMvc.perform(MockMvcRequestBuilders.get("/addQuestionToQuizModification").param("title", title))
				.andExpect(MockMvcResultMatchers.status().isOk())
				
				.andExpect(MockMvcResultMatchers.model().attribute("quizTitle", title))
				.andExpect(MockMvcResultMatchers.model().attribute("questionsPresentInQuiz", questionsInQuiz))
				.andExpect(MockMvcResultMatchers.view().name("modifyQuiz"));
	}

	@Test
	void happyPath_TestGetQuiz() throws Exception {
		Map<String, Quiz> quizzes = new HashMap<>();

		Mockito.when(quizService.viewAllQuiz()).thenReturn(quizzes);

		mockMvc.perform(MockMvcRequestBuilders.get("/displayAllQuizes"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.view().name("displayQuiz"));
	}

	@Test
	void sadPath_TestRemoveQuestionError() throws Exception {
		String quizTitle = "Test Quiz";
		String questionTitle = "Test Question";
		doThrow(new RuntimeException()).when(quizService).modifyQuizRemoveQuestion(quizTitle, questionTitle);

		mockMvc.perform(
				post("/modifyRemoveQuestion").param("quizTitle", quizTitle).param("questionTitle", questionTitle))
				.andExpect(status().isOk()).andExpect(view().name(Constant.ERROR_PAGE))
				.andExpect(model().attributeExists(Constant.ERROR_MESSAGE));

		verify(quizService, times(1)).modifyQuizRemoveQuestion(quizTitle, questionTitle);
	}

}