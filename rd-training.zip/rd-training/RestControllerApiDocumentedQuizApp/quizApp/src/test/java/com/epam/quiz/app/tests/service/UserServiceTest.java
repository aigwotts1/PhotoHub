package com.epam.quiz.app.tests.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.epam.quiz.app.exceptions.UserException;
import com.epam.quiz.app.model.User;
import com.epam.quiz.app.model.UserDto;
import com.epam.quiz.app.repository.UserRepository;
import com.epam.quiz.app.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    UserService userService;
    
    @Mock
    ModelMapper modelMapper;

    @Test
    void happyPath_TestAddUser() {
        String userName = "testUser";
        String password = "testPassword";

        User user = new User();
        user.setUsername(userName);
        user.setPassword(password);

        when(userRepository.save(user)).thenReturn(user);

        userService.addUser(userName, password);

        assertEquals(userName, user.getUsername());
        assertEquals(password, user.getPassword());
    }

    @Test
    void happyPath_TestGetUser() {
        String userName = "testUser";
        String password = "testPassword";

        User user = new User();
        user.setUsername(userName);
        user.setPassword(password);
        Optional<User> optionalUser = Optional.of(user);
        when(userRepository.findUserByUsernameAndPassword(userName, password)).thenReturn(optionalUser);

        UserDto userDto = new UserDto();
        userDto.setUsername(userName);
        when(modelMapper.map(user, UserDto.class)).thenReturn(userDto);

        userService.getUser(userName, password);
        verify(userRepository).findUserByUsernameAndPassword(userName, password);
        verify(modelMapper).map(user, UserDto.class);

    }
    
    @Test
    void sadPath_TestGetUserThrowsException() {
        String userName = "testUser";
        String password = "testPassword";
        when(userRepository.findUserByUsernameAndPassword(userName, password)).thenReturn(Optional.empty());
        UserException exception = assertThrows(UserException.class, () -> {userService.getUser(userName, password);});
        verify(userRepository).findUserByUsernameAndPassword(userName, password);
        assertEquals("User Not Present :(", exception.getMessage());
    }
}