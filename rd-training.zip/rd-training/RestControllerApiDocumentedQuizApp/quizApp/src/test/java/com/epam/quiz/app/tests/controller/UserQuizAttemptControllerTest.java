package com.epam.quiz.app.tests.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.controller.UserQuizAttemptController;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@WebMvcTest(UserQuizAttemptController.class)
class UserQuizAttemptControllerTest {
	
	@MockBean
    QuizService quizService;
    
    @MockBean
    QuestionService questionService;
    
    @Autowired
    MockMvc mockMvc;

    @Test
    void happtPath_TestAttemptQuiz_QuizFound() throws Exception {
        Quiz quiz = new Quiz();
        quiz.setTitle("Java Basics");

        List<Question> questionList = new ArrayList<>();
		Question question1 = new Question("Question Title", Arrays.asList("Option 1", "2"), "Easy", "Topic 1", 1);
		Question question2 = new Question("Questions Titles", Arrays.asList("Option 3", "4"), "Easy", "Topic 1", 1);

        questionList.add(question1);
        questionList.add(question2);
        quiz.setQuestionList(questionList);

        QuizDto expectedQuizDto = new QuizDto();
        expectedQuizDto.setTitle("Java Basics");

        when(quizService.getQuizByTitle("Java Basics")).thenReturn(expectedQuizDto);

        mockMvc.perform(get("/attemptQuiz").param("title", "Java Basics"))
            .andExpect(status().isOk())
            .andExpect(view().name("attemptQuiz"))
            .andExpect(model().attributeExists("quiz"))
            .andExpect(model().attribute("quiz", expectedQuizDto));

        verify(quizService, times(1)).getQuizByTitle("Java Basics");
    }
    @Test
    void happyPath_TestGetResult() throws Exception {
        QuizDto quizDto = new QuizDto();
        quizDto.setTitle("Math Quiz");
        quizDto.setTotal_marks(10);
        Question question1 = new Question();
        question1.setMarks(2);
        question1.setAnswer(3);
        Question question2 = new Question();
        question2.setMarks(3);
        question2.setAnswer(1);
        List<Question> questionList = new ArrayList<>();
        questionList.add(question1);
        questionList.add(question2);
        quizDto.setQuestionList(questionList);

        when(quizService.getQuizByTitle("Math Quiz")).thenReturn(quizDto);

        MvcResult result = mockMvc.perform(get("/getResult")
                .param("quizTitle", "Math Quiz")
                .param("userInput", "3\n1\n5"))
                .andExpect(status().isOk())
                .andExpect(view().name("displayScore"))
                .andReturn();

        ModelAndView modelAndView = result.getModelAndView();
        assertEquals(5, modelAndView.getModel().get("scoredMarks"));
        assertEquals(10, modelAndView.getModel().get("totalMarks"));
    }
}