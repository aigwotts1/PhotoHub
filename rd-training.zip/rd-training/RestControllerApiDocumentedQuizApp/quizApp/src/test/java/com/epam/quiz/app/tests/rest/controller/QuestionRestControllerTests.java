package com.epam.quiz.app.tests.rest.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.rest.controller.QuestionRestController;
import com.epam.quiz.app.service.QuestionService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(QuestionRestController.class)
class QuestionRestControllerTests {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	QuestionService questionService;

	@MockBean
	ModelMapper modelMapper;

	@Test
	void happyPath_TestCreateQuestion() throws Exception {
		Question question = new Question("Question Title", Arrays.asList("Option 1", "2"), "Easy", "Topic 1", 1);
		question.setMarks(0);
		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Question Title");
		questionDto.setOptions(Arrays.asList("Option 1", "2"));
		questionDto.setDificulty("Easy");
		questionDto.setTopics("Topic 1");
		questionDto.setAnswer(1);
		questionDto.setMarks(0);

		Mockito.when(questionService.createQuestion(questionDto)).thenReturn(questionDto);

		mockMvc.perform(post("/create_questions").contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(new ObjectMapper().writeValueAsString(questionDto))).andExpect(status().isCreated());
	}

	@Test
	void happyPath_TestDeleteQuestion() throws Exception {
		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Mocked question title");

		doNothing().when(questionService).removeQuestion(questionDto.getTitle());

		mockMvc.perform(delete("/delete_questions").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(questionDto))).andExpect(status().isOk());

		verify(questionService, times(1)).removeQuestion(questionDto.getTitle());
	}

	@Test
	void happyPath_TestModifyQuestion() throws Exception {

		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Question Title");
		questionDto.setOptions(Arrays.asList("Option 1", "2"));
		questionDto.setDificulty("Easy");
		questionDto.setTopics("Topic 1");
		questionDto.setAnswer(1);

		when(questionService.modifyQuestion(any(QuestionDto.class), eq(10))).thenReturn(questionDto);

		mockMvc.perform(put("/modify_questions").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(questionDto))).andExpect(status().isOk());

	}

	@Test
	void happyPath_TestGetAllQuestions() throws Exception {
		Question question1 = new Question("Question Title1", Arrays.asList("Option 1", "2"), "Easy", "Topic 1", 1);
		Question question2 = new Question("Question Title2", Arrays.asList("Option 1", "2"), "Easy", "Topic 1", 1);
		Map<String, Question> mockQuestionsMap = new HashMap<>();
		mockQuestionsMap.put("1", question1);
		mockQuestionsMap.put("2", question2);
		Mockito.when(questionService.viewAllQuestions()).thenReturn(mockQuestionsMap);

		mockMvc.perform(MockMvcRequestBuilders.get("/display_all_questions_present"))
				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	}

	@Test
    void happyPath_TestGetQuestion() throws Exception {
        QuestionDto questionDto = new QuestionDto();
        questionDto.setTitle("Some title");
        
        QuestionDto questionDtoResponse = new QuestionDto();
        questionDtoResponse.setTitle("Some title");

        when(questionService.viewQuestion(questionDto.getTitle())).thenReturn(questionDto);

        mockMvc.perform(get("/get_questions_by_title")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(questionDto)))
                .andExpect(status().isAccepted());
    }	
}