package com.epam.quiz.app.tests.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.epam.quiz.app.exceptions.QuestionException;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.repository.QuestionRepository;
import com.epam.quiz.app.service.QuestionService;

@ExtendWith(MockitoExtension.class)
class QuestionServiceTest {

	@Mock
	QuestionRepository questionRepository;

	@InjectMocks
	QuestionService questionService;

	@Mock
	ModelMapper modelMapper;

	@Test
	void sadPath_TestCreateQuestionWithInvalidOptionSizeDto() {

		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Question Title");
		questionDto.setOptions(Arrays.asList("Option 1"));
		questionDto.setDificulty("Easy");
		questionDto.setTopics("Topic 1");
		questionDto.setAnswer(1);
		assertThrows(QuestionException.class, () -> questionService.createQuestion(questionDto));

		verify(questionRepository, never()).save(any(Question.class));
	}

	@Test
	void sadPath_TestCreateQuestionWithInvalidAnswerNumberDto() {

		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Question Title");
		questionDto.setOptions(Arrays.asList("Option 1", "Option 2"));
		questionDto.setDificulty("Easy");
		questionDto.setTopics("Topic 1");
		questionDto.setAnswer(4);
		assertThrows(QuestionException.class, () -> questionService.createQuestion(questionDto));

		verify(questionRepository, never()).save(any(Question.class));
	}

	@Test
	void happyPath_createQuestionTest() {

		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Question Title");
		questionDto.setOptions(Arrays.asList("Option 1", "Option 2"));
		questionDto.setDificulty("Easy");
		questionDto.setTopics("Topic 1");
		questionDto.setAnswer(1);

		Question question = new Question();
		question.setTitle("Question Title");
		question.setOptions(Arrays.asList("Option 1", "Option 2"));
		question.setDificulty("Easy");
		question.setTopics("Topic 1");
		question.setAnswer(1);

		when(modelMapper.map(questionDto, Question.class)).thenReturn(question);
		when(questionRepository.save(any(Question.class))).thenReturn(question);
		when(modelMapper.map(question, QuestionDto.class)).thenReturn(questionDto);

		QuestionDto result = questionService.createQuestion(questionDto);

		assertNotNull(result);
		assertEquals(question.getTitle(), result.getTitle());
		assertEquals(question.getOptions(), result.getOptions());
		assertEquals(question.getDificulty(), result.getDificulty());
		assertEquals(question.getTopics(), result.getTopics());
		assertEquals(question.getAnswer(), result.getAnswer());
	}

	@Test
	void happyPath_TestViewQuestion() {

		Question question = new Question();
		question.setTitle("Question Title");

		QuestionDto expectedQuestionDto = new QuestionDto();
		expectedQuestionDto.setTitle("Question Title");

		when(questionRepository.findQuestionByTitle(anyString())).thenReturn(Optional.of(question));
		when(modelMapper.map(question, QuestionDto.class)).thenReturn(expectedQuestionDto);

		QuestionDto result = questionService.viewQuestion("Question Title");

		assertNotNull(result);
		assertEquals(question.getTitle(), result.getTitle());
	}

	@Test
	void sadPath_TestViewQuestion_ThrowsEntityNotFoundException() {

		String title = "Non-existent question title";
		when(questionRepository.findQuestionByTitle(title)).thenReturn(Optional.empty());

		assertThrows(QuestionException.class, () -> questionService.viewQuestion(title));
		verify(questionRepository, times(1)).findQuestionByTitle(title);
		verifyNoMoreInteractions(questionRepository);
	}

	@Test
	void happyPath_viewAllQuestionsTest() {

		List<Question> questions = new ArrayList<>();
		Question question1 = new Question();
		question1.setTitle("Question Title 1");
		Question question2 = new Question();
		question2.setTitle("Question Title 2");
		questions.add(question1);
		questions.add(question2);

		when(questionRepository.findAll()).thenReturn(questions);

		Map<String, Question> result = questionService.viewAllQuestions();

		assertNotNull(result);
		assertEquals(2, result.size());
		assertTrue(result.containsKey("Question Title 1"));
		assertTrue(result.containsKey("Question Title 2"));
	}

	@Test
	void happyPath_removeQuestionTest() {

		Question question = new Question();
		question.setTitle("Question Title");
		Optional<Question> optionalQuestion = Optional.of(question);

		when(questionRepository.findQuestionByTitle(anyString())).thenReturn(optionalQuestion);

		questionService.removeQuestion("Question Title");

		verify(questionRepository, times(1)).delete(question);
	}

	@Test
	void sadPath_TestRemoveQuestionThrowsException() {
		String title = "testTitle";

		when(questionRepository.findQuestionByTitle(title)).thenReturn(Optional.empty());

		QuestionException exception = assertThrows(QuestionException.class, () -> {
			questionService.removeQuestion(title);
		});

		verify(questionRepository).findQuestionByTitle(title);

		assertEquals("Question not found i.e. Cannot be Deleted", exception.getMessage());
	}

	@Test
	void happyPath_TestModifyQuestion() {

		QuestionDto questionDto = new QuestionDto();
		questionDto.setTitle("Question Title");
		questionDto.setOptions(Arrays.asList("Option 1", "Option 2"));
		questionDto.setDificulty("Easy");
		questionDto.setTopics("Topic 1");
		questionDto.setAnswer(1);

		Question question = new Question();
		question.setTitle("Question Title");
		question.setOptions(Arrays.asList("Option 2", "Option 4"));
		question.setDificulty("Hard");
		question.setTopics("Topic 2");
		question.setAnswer(2);

		int marks = 1;
		when(questionRepository.findQuestionByTitle(questionDto.getTitle())).thenReturn(Optional.of(question));

		when(modelMapper.map(questionDto, Question.class)).thenReturn(question);
		when(questionRepository.save(any(Question.class))).thenReturn(question);
		when(modelMapper.map(question, QuestionDto.class)).thenReturn(questionDto);

		QuestionDto result = questionService.modifyQuestion(questionDto, marks);

		assertNotNull(result);

	}
}