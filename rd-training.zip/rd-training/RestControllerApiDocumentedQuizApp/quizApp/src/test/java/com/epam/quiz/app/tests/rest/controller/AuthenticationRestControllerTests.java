package com.epam.quiz.app.tests.rest.controller;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.epam.quiz.app.model.UserDto;
import com.epam.quiz.app.rest.controller.AuthenticationRestController;
import com.epam.quiz.app.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(AuthenticationRestController.class)
class AuthenticationRestControllerTests {

	@Autowired
    MockMvc mockMvc;
    
    @MockBean
    UserService userService;
    
    @Test
    void happyPath_TestRegister() throws Exception {
        UserDto userDto = new UserDto();
        userDto.setUsername("testuser");
        userDto.setPassword("testpassword");
        UserDto user = new UserDto("testuser", "testpassword");
        Mockito.when(userService.addUser("testuser", "testpassword")).thenReturn(user);
        
        mockMvc.perform(MockMvcRequestBuilders.post("/register_user")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(userDto)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.username", Matchers.is(user.getUsername())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.password", Matchers.is(user.getPassword())));
    }
    
    @Test
    void happyPath_TestLogin() throws Exception {
        UserDto userDto = new UserDto();
        userDto.setUsername("testuser");
        userDto.setPassword("testpassword");
        UserDto user = new UserDto("testuser", "testpassword");
        Mockito.when(userService.getUser("testuser", "testpassword")).thenReturn(user);
        
        mockMvc.perform(MockMvcRequestBuilders.get("/login_user")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(userDto)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.username", Matchers.is(user.getUsername())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.password", Matchers.is(user.getPassword())));
    }
}