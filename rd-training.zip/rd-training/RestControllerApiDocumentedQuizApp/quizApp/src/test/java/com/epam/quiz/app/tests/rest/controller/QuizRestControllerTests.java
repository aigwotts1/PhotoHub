package com.epam.quiz.app.tests.rest.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.rest.controller.QuizRestController;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(QuizRestController.class)
class QuizRestControllerTests {

	@MockBean
	QuizService quizService;

	@Autowired
	MockMvc mockMvc;

	@MockBean
	QuestionService questionService;

	@MockBean
	ModelMapper modelMapper;

	@Test
	void happyPath_TestRemoveQuizByTitle() throws Exception {
		QuizDto quizDto = new QuizDto();
		quizDto.setTitle("Some title");

		mockMvc.perform(delete("/delete_quiz").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(quizDto))).andExpect(status().isOk());

		verify(quizService, times(1)).removeQuiz(quizDto.getTitle());
	}

	@Test
	void happyPath_TestAddQuiz() throws Exception {
		QuizDto quizDto = new QuizDto();
		quizDto.setTitle("Some title");
		quizDto.setTotal_marks(10);
		QuizDto quizDtoResponse = new QuizDto();
		quizDtoResponse.setTitle("Some title");
		quizDtoResponse.setTotal_marks(10);

		Quiz quiz = new Quiz();
		quiz.setTitle("Some title");
		quiz.setQuestionList(null);
		quiz.setTotal_marks(10);
		when(quizService.addQuiz(quizDto)).thenReturn(quizDto);

		mockMvc.perform(post("/create_quiz").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(quizDto))).andExpect(status().isCreated());
	}

	@Test
	void happyPath_TestGetAllQuizes() throws Exception {
		Quiz quiz = new Quiz();
		quiz.setTitle("What is your name?");
		quiz.setQuestionList(null);
		quiz.setTotal_marks(0);
		Map<String, Quiz> map = new HashMap<>();
		map.put(quiz.getTitle(), quiz);
		when(quizService.viewAllQuiz()).thenReturn(map);
		mockMvc.perform(get("/quizes")).andExpect(status().isOk());
	}

	@Test
	void happyPath_TestGetQuizByTitle() throws Exception {
		QuizDto mockQuizDto = new QuizDto();
		mockQuizDto.setTitle("Mock Quiz");

		Quiz mockQuiz = new Quiz();
		mockQuiz.setTitle("Mock Quiz");

		Mockito.when(quizService.getQuizByTitle("Mock Quiz")).thenReturn(mockQuizDto);

		mockMvc.perform(MockMvcRequestBuilders.get("/get_quiz_by_title").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(mockQuizDto))).andExpect(status().isAccepted());

		Mockito.verify(quizService, times(1)).getQuizByTitle("Mock Quiz");
	}

	@Test
	void happyPath_TestModifyQuiz() throws Exception {
		String quizTitle = "Mock Quiz";
		String questionTitle = "Mock Question";
		String marks = "10";

		QuizDto mockQuiz = new QuizDto();
		mockQuiz.setTitle(quizTitle);
		Question mockQuestion = new Question();
		mockQuestion.setTitle(questionTitle);
		mockQuestion.setMarks(Integer.parseInt(marks));

		Mockito.when(quizService.modifyQuiz(quizTitle, questionTitle, marks)).thenReturn(mockQuiz);

		mockMvc.perform(MockMvcRequestBuilders
				.post("/modify_quiz/{quizTitle}/{questionTitle}/{marks}", quizTitle, questionTitle, marks)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

		Mockito.verify(quizService, times(1)).modifyQuiz(quizTitle, questionTitle, marks);
	}

	@Test
	void happyPath_TestRemoveQuizQuestion() throws Exception {
		String quizTitle = "Mock Quiz";
		String questionTitle = "Mock Question";

		QuizDto mockQuiz = new QuizDto();
		mockQuiz.setTitle(quizTitle);

		Mockito.when(quizService.modifyQuizRemoveQuestion(quizTitle, questionTitle)).thenReturn(mockQuiz);

		mockMvc.perform(MockMvcRequestBuilders.delete("/remove_quiz_question").param("quizTitle", quizTitle)
				.param("questionTitle", questionTitle).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());

		Mockito.verify(quizService, times(1)).modifyQuizRemoveQuestion(quizTitle, questionTitle);
	}
}