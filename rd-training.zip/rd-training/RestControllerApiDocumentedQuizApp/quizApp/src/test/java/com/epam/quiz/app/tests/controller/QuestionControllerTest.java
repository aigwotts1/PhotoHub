package com.epam.quiz.app.tests.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.Collections;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.epam.quiz.app.constants.Constant;
import com.epam.quiz.app.controller.QuestionController;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.service.QuestionService;

@WebMvcTest(QuestionController.class)
class QuestionControllerTest {

    @MockBean
    QuestionService questionService;
    
    @Autowired
    MockMvc mockMvc;

    @Test
    void happyPath_TestGetAllQuestions() throws Exception {
    	
    	Map<String, Question> questionMap = Collections.emptyMap();

        Mockito.when(questionService.viewAllQuestions()).thenReturn(questionMap);

        mockMvc.perform(MockMvcRequestBuilders.get("/displayAllQuestions"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name(Constant.DISPLAY_QUESTION))
                .andExpect(MockMvcResultMatchers.model().attribute("displayQuestions", questionMap));
    } 
    
    @Test
    void sadPath_TestGetAllQuestionsException() throws Exception {
        RuntimeException exception = new RuntimeException("Test Exception");

        when(questionService.viewAllQuestions()).thenThrow(exception);

        mockMvc.perform(get("/displayAllQuestions"))
               .andExpect(status().isOk())
               .andExpect(view().name(Constant.ERROR_PAGE))
               .andExpect(model().attribute(Constant.ERROR_MESSAGE, exception.getMessage()));
    }
    
    @Test
    void happyPath_TestCreateQuestion() throws Exception {
        Mockito.when(questionService.createQuestion(Mockito.any(QuestionDto.class))).thenReturn(new QuestionDto());

        mockMvc.perform(MockMvcRequestBuilders.post("/createQuestion"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name(Constant.DISPLAY_QUESTION))
                .andExpect(MockMvcResultMatchers.model().attribute(Constant.DISPLAY_QUESTION, questionService.viewAllQuestions()));
    }
    @Test
    void sadPath_CreateQuestion_ExceptionTest() throws Exception {
           
        RuntimeException exception = new RuntimeException("Test Exception");

        when(questionService.createQuestion(any(QuestionDto.class))).thenThrow(exception);

        mockMvc.perform(post("/createQuestion"))
                .andExpect(status().isOk())
                .andExpect(view().name(Constant.ERROR_PAGE))
                .andExpect(model().attributeExists(Constant.ERROR_MESSAGE))
                .andExpect(model().attribute(Constant.ERROR_MESSAGE, "Question Cannot Be Created :("));

    }

    @Test
    void sadPath_TestModifyQuestionException1() throws Exception {
      
        String title = "Test Question";
        QuestionDto questionDto = new QuestionDto();
        int marks = 10;

        Mockito.doThrow(new RuntimeException("Something went wrong")).when(questionService).modifyQuestion(questionDto, marks);

        mockMvc.perform(MockMvcRequestBuilders.get("/modifyQuestion")
                .param("title", title)
                .param("marks", String.valueOf(marks))
                .flashAttr("questionDto", questionDto))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name(Constant.ERROR_PAGE))
                .andExpect(MockMvcResultMatchers.model().attributeExists(Constant.ERROR_MESSAGE))
                .andExpect(MockMvcResultMatchers.model().attribute(Constant.ERROR_MESSAGE, "Something went wrong"));

        Mockito.verify(questionService, Mockito.times(1)).modifyQuestion( questionDto, marks);
    }
    
    
    @Test
    void happyPath_TestDeleteQuestion() throws Exception {
  
        String title = "some title";

        mockMvc.perform(get("/deleteQuestion").param("title", title))
               .andExpect(status().isOk())
               .andExpect(view().name(Constant.DISPLAY_QUESTION))
               .andExpect(model().attribute(Constant.DISPLAY_QUESTION, questionService.viewAllQuestions()));
        verify(questionService, times(1)).removeQuestion(title);
    }
    

    
    @Test
    void happyPath_TestModifyQuestion() throws Exception {
        String title = "Test Question";
        QuestionDto questionDto = new QuestionDto();
        int marks = 10;
        
        mockMvc.perform(get("/modifyQuestion")
                .param("title", title)
                .flashAttr("questionDto", questionDto)
                .param("marks", Integer.toString(marks)))
                .andExpect(status().isOk())
                .andExpect(view().name(Constant.DISPLAY_QUESTION))
                .andExpect(model().attributeExists(Constant.DISPLAY_QUESTION));

        verify(questionService).modifyQuestion(questionDto, marks);
    }
    

    
    @Test
    void happyPath_TestModify() throws Exception {
        String title = "Test Question";

        QuestionDto question = new QuestionDto();
        when(questionService.viewQuestion(title)).thenReturn(question);

        mockMvc.perform(get("/modifyQuestionFromDisplayer")
                .param("title", title))
                .andExpect(status().isOk())
                .andExpect(view().name("modifyQuestion"))
                .andExpect(model().attributeExists("question"));

        verify(questionService).viewQuestion(title);

    }
    @Test
    void sadPath_TestModifyQuestionException() throws Exception {
        String title = "Test Question";
        RuntimeException exception = new RuntimeException("Test Exception");

        when(questionService.viewQuestion(title)).thenThrow(exception);

        mockMvc.perform(get("/modifyQuestionFromDisplayer")
               .param("title", title))
               .andExpect(status().isOk())
               .andExpect(view().name(Constant.ERROR_PAGE))
               .andExpect(model().attribute(Constant.ERROR_MESSAGE, exception.getMessage()));
    }
    
    @Test
    void sadPath_TestDeleteQuestion_withQuestionPresentInQuiz_shouldReturnErrorPage() throws Exception {
      String questionTitle = "Sample Question";
      doThrow(new RuntimeException("Question Present In Quiz")).when(questionService).removeQuestion(questionTitle);

      mockMvc.perform(get("/deleteQuestion").param("title", questionTitle))
        .andExpect(status().isOk())
        .andExpect(view().name(Constant.ERROR_PAGE))
        .andExpect(model().attribute(Constant.ERROR_MESSAGE, "Question Present In Quiz i.e. Cannot Be Deleted :("))
        .andReturn();
    }
}