package com.epam.quiz.app.tests.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.epam.quiz.app.exceptions.QuizException;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.repository.QuestionRepository;
import com.epam.quiz.app.repository.QuizRepository;
import com.epam.quiz.app.service.QuizService;

@ExtendWith(MockitoExtension.class)
class QuizServiceTest {

	@Mock
	QuizRepository quizRepository;

	@Mock
	QuestionRepository questionRepository;

	@InjectMocks
	QuizService quizService;

	@Mock
	ModelMapper modelMapper;

	@Test
	void happyPath_TestAddQuiz() {
		QuizDto quizDto = new QuizDto();
		quizDto.setTitle("NewQuiz");

		Quiz quiz = modelMapper.map(quizDto, Quiz.class);
		when(modelMapper.map(quizDto, Quiz.class)).thenReturn(quiz);
		when(quizRepository.save(quiz)).thenReturn(quiz);
		when(modelMapper.map(quiz, QuizDto.class)).thenReturn(quizDto);

		quizService.addQuiz(quizDto);
	}

	@Test
    void sadPath_TestGetQuizByTitle_QuizFound() {
        Quiz quiz = new Quiz();
        quiz.setTitle("Java Basics");

        QuizDto expectedQuizDto = new QuizDto();
        expectedQuizDto.setTitle("Java Basics");

        when(quizRepository.findByTitle("Java Basics")).thenReturn(Optional.of(quiz));
        when(modelMapper.map(quiz, QuizDto.class)).thenReturn(expectedQuizDto);

        QuizDto quizDto = quizService.getQuizByTitle("Java Basics");

        assertNotNull(quizDto);
        assertEquals("Java Basics", quizDto.getTitle());

        verify(quizRepository, times(1)).findByTitle("Java Basics");
        verify(modelMapper, times(1)).map(quiz, QuizDto.class);
    }

	@Test
	void sadPath_TestGetQuizByTitleWhenQuizDoesNotExist() {
	     when(quizRepository.findByTitle("Non-Existent Quiz")).thenReturn(Optional.empty());

	     QuizException exception = assertThrows(QuizException.class,
	                () -> quizService.getQuizByTitle("Non-Existent Quiz"));

	     assertEquals("Quiz not found :(", exception.getMessage());
	     verify(quizRepository, times(1)).findByTitle("Non-Existent Quiz");
	}

	@Test
	void happyPath_TestRemoveQuiz() {
		Quiz quiz = new Quiz("Test Quiz", null);

		when(quizRepository.findByTitle("Test Quiz")).thenReturn(Optional.of(quiz));

		quizService.removeQuiz("Test Quiz");

		verify(quizRepository, times(1)).delete(quiz);
	}

	@Test
	void happyPath_TestViewAllQuiz() {
		List<Quiz> quizList = new ArrayList<>();
		Quiz quiz1 = new Quiz();
		quiz1.setTitle("Quiz 1");
		quizList.add(quiz1);
		Quiz quiz2 = new Quiz();
		quiz2.setTitle("Quiz 2");
		quizList.add(quiz2);

		when(quizRepository.findAll()).thenReturn(quizList);

		Map<String, Quiz> result = quizService.viewAllQuiz();

		assertEquals(quizList.size(), result.size(), "Size of result map should match the size of the quiz list");

		for (Quiz quiz : quizList) {
			Quiz resultQuiz = result.get(quiz.getTitle());
			assertEquals(quiz, resultQuiz, "Quiz object should match in the result map");
		}
	}

	@Test
	void happyPath_ModifyQuiz_shouldReturnModifiedQuizDtoTest() {
		String quizTitle = "Quiz Title";
		String questionTitle = "Question Title";
		String marks = "10";
		Quiz quiz = new Quiz();
		quiz.setTitle(quizTitle);

		Question question = new Question();
		question.setTitle(questionTitle);
		List<Question> questionList = new ArrayList<>();
		questionList.add(question);

		when(quizRepository.findByTitle(quizTitle)).thenReturn(Optional.of(quiz));
		when(questionRepository.findQuestionByTitle(questionTitle)).thenReturn(Optional.of(question));
		when(modelMapper.map(quizRepository.save(quiz), QuizDto.class)).thenReturn(new QuizDto());

		QuizDto actualQuizDto = quizService.modifyQuiz(quizTitle, questionTitle, marks);

		assertNotNull(actualQuizDto);
		assertEquals(10, quiz.getTotal_marks());
		assertEquals(1, quiz.getQuestionList().size());

		verify(quizRepository, times(1)).findByTitle(quizTitle);
		verify(questionRepository, times(1)).findQuestionByTitle(questionTitle);

	}

	@Test
	void happyPath_TestModifyQuizRemoveQuestion() {
		Question question = new Question();
		question.setTitle("Question 1");
		question.setMarks(5);
		Quiz quiz = new Quiz();
		quiz.setTitle("Quiz 1");
		quiz.setTotal_marks(10);

		String quizTitle = "Quiz 1";
		String questionTitle = "Question 1";
		when(quizRepository.findByTitle(quizTitle)).thenReturn(Optional.of(quiz));
		when(questionRepository.findQuestionByTitle(questionTitle)).thenReturn(Optional.of(question));
		quizService.modifyQuizRemoveQuestion(quizTitle, questionTitle);
		verify(quizRepository, times(1)).findByTitle(quizTitle);
		verify(questionRepository, times(1)).findQuestionByTitle(questionTitle);
		assertEquals(5, quiz.getTotal_marks());
		assertEquals(0, quiz.getQuestionList().size());
	}

	@Test
	void sadPath_TestModifyQuizQuestionAlreadyPresent() {
		Quiz quiz = new Quiz();
		quiz.setTitle("Science Quiz");
		quiz.setTotal_marks(10);
		Question question = new Question();
		question.setTitle("What is photosynthesis?");
		question.setMarks(5);
		quiz.getQuestionList().add(question);

		when(quizRepository.findByTitle("Science Quiz")).thenReturn(Optional.of(quiz));

		when(questionRepository.findQuestionByTitle("What is photosynthesis?")).thenReturn(Optional.of(question));

		QuizException exception = assertThrows(QuizException.class,
				() -> quizService.modifyQuiz("Science Quiz", "What is photosynthesis?", "10"));

		assertEquals("Question Already Present In Quiz", exception.getMessage());
	}

	@Test
    void sadPath_TestModifyQuiz_QuizNotFound() {
        when(quizRepository.findByTitle("Java Basics")).thenReturn(Optional.empty());

        QuizException exception = assertThrows(QuizException.class, () -> quizService.modifyQuiz("Java Basics", "What is Java?", "5"));

        assertEquals("Quiz not found :( cannot be modified", exception.getMessage());

        verify(questionRepository, never()).findQuestionByTitle(anyString());
        verify(modelMapper, never()).map(any(), any());
        verify(quizRepository, never()).save(any());
    }
	
	@Test
    void sadPath_TestModifyQuiz_QuestionNotPresent() {
        Quiz quiz = new Quiz();
        quiz.setTitle("Java Basics");

        when(quizRepository.findByTitle("Java Basics")).thenReturn(Optional.of(quiz));
        when(questionRepository.findQuestionByTitle("What is Java?")).thenReturn(Optional.empty());

        QuizException exception = assertThrows(QuizException.class, () -> quizService.modifyQuiz("Java Basics", "What is Java?", "5"));

        assertEquals("Question Not Present :(", exception.getMessage());

        verify(modelMapper, never()).map(any(), any());
        verify(quizRepository, never()).save(any());
    }

	@Test
	void sadPath_TestModifyQuizRemoveQuestionThrowsException() {
		String quizTitle = "Nonexistent Quiz";
		String questionTitle = "Nonexistent Question";

		when(quizRepository.findByTitle(any(String.class))).thenReturn(Optional.empty());

		assertThrows(QuizException.class, () -> quizService.modifyQuizRemoveQuestion(quizTitle, questionTitle));
	}
	
	@Test
    void sadPath_TestModifyQuizRemoveQuestionQuestionNotPresent() {
	        Quiz quiz = new Quiz();
	        quiz.setTitle("Java Basics");

	        when(quizRepository.findByTitle("Java Basics")).thenReturn(Optional.of(quiz));
	        when(questionRepository.findQuestionByTitle("What is Java?")).thenReturn(Optional.empty());

	        QuizException exception = assertThrows(QuizException.class, () -> quizService.modifyQuizRemoveQuestion("Java Basics", "What is Java?"));

	        assertEquals("Question Not Present :(", exception.getMessage());

	        verify(modelMapper, never()).map(any(), any());
	        verify(quizRepository, never()).save(any());
	    }

	@Test
	void sadPath_TestRemoveQuizThrowsException() {
		String quizTitle = "Nonexistent Quiz";
		when(quizRepository.findByTitle(any(String.class))).thenReturn(Optional.empty());
		assertThrows(QuizException.class, () -> quizService.removeQuiz(quizTitle));
		verify(quizRepository, times(0)).delete(any(Quiz.class));
	}
}