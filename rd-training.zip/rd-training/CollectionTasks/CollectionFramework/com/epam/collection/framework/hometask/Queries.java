package com.epam.collection.framework.hometask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Queries {

	private int numberOfMaleEmployees = 0;
	private int numberOfFemaleEmployees = 0;
	private float totalSalaryOfMaleEmployees = 0;
	private float totalSalaryOfFemaleEmployees = 0;
	private HashMap<String, Integer> mapOfEmployeeDepartments = new HashMap<>();
	private final String MALE = "Male";
	private final String PRODUCT_DEVELOPMENT = "Product Development";
	private final String SALES_AND_MARKETING = "Sales And Marketing";
	private final String FEMALE = "Female";
	
    //1.How many male and female employees are there in the organization?
	public void getCountOfAllEmployees(List<Employee> employeeList) {
		for (int i = 0; i < employeeList.size(); i++) {
			if (getGender(employeeList,i).equalsIgnoreCase(MALE)) {
				numberOfMaleEmployees++;
			} else {
				numberOfFemaleEmployees++;
			}
		}
		System.out.println("Number of Male Employees in the Organization : " + numberOfMaleEmployees);
		System.out.println("Number of Female Employees in the Organization : " + numberOfFemaleEmployees);
	}

	//2.Print the name of all departments in the organization?
	public void getAllDepartments(List<Employee> employeeList) {
		HashSet<String> setOfDepartments = new HashSet<>();
		for (int i = 0; i < employeeList.size(); i++) {
			setOfDepartments.add(getDepartment(employeeList,i));
		}
		Iterator<String> itr = setOfDepartments.iterator();
		System.out.println("\nDepartment Names : ");
		while (itr.hasNext()) {
			System.out.print(itr.next() + " | ");
		}
		System.out.println();
	}

	//3.What is the average age of male and female employees?
	public void getAverageAgeOfMaleAndFemaleEmployees(List<Employee> employeeList) {
		int sumOfMaleEmployeeAges = 0;
		int sumOfFemaleEmployeeAges = 0;
		for (int i = 0; i < employeeList.size(); i++) {
			if (getGender(employeeList,i).equalsIgnoreCase(MALE)) {
				sumOfMaleEmployeeAges += getAge(employeeList,i);
			} else {
				sumOfFemaleEmployeeAges += getAge(employeeList,i);
			}
		}
		System.out.println("\nAverage male employee age : " + (sumOfMaleEmployeeAges / numberOfMaleEmployees));
		System.out.println("Average female employee age : " + (sumOfFemaleEmployeeAges / numberOfFemaleEmployees));
	}

	//4.Get the details of highest paid employee in the organization?
	public void getHighestPaidEmployee(List<Employee> employeeList) {
		double maximumSalary = 0;
		int index = 0;
		for (int i = 0; i < employeeList.size(); i++) {
			if (getSalary(employeeList,i) > maximumSalary) {
				maximumSalary = getSalary(employeeList,i);
				index = i;
			}
		}
		System.out.println("\nHighest Paid Employee Details : ");
		System.out.println(employeeList.get(index));
	}

	//5.Get the names of all employees who have joined after 2015?
	public void getNewEmployeeNames(List<Employee> employeeList) {
		System.out.print("\nEmployees who have joined after 2015 : ");
		for (int i = 0; i < employeeList.size(); i++) {
			if (employeeList.get(i).getYearOfJoining() > 2015) {
				System.out.print(employeeList.get(i).getName() + " | ");
			}
		}
		System.out.println();
	}

	//6.Count the number of employees in each department?
	public void getAllDepartmentEmployees(List<Employee> employeeList) {
		for (int i = 0; i < employeeList.size(); i++) {
			String departmentName = getDepartment(employeeList,i);
			if (mapOfEmployeeDepartments.containsKey(departmentName)) {
				mapOfEmployeeDepartments.put(departmentName, 
					mapOfEmployeeDepartments.get(departmentName) + 1);
			} else {
				mapOfEmployeeDepartments.put(departmentName, 1);
			}
		}
		System.out.println();
		System.out.println("Number of Employees in each Department : ");
		for (Map.Entry<String, Integer> entry : mapOfEmployeeDepartments.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
		System.out.println();
	}

	//7.What is the average salary of each department?
	public void getAverageSalaryPerDepartment(List<Employee> employeeList) {
		HashMap<String, Double> salaryMap = new HashMap<>();
		for (int i = 0; i < employeeList.size(); i++) {
			if (salaryMap.containsKey(getDepartment(employeeList,i))) {
				salaryMap.put(getDepartment(employeeList,i),
						salaryMap.get(getDepartment(employeeList,i)) + getSalary(employeeList,i));
			}

			else {
				salaryMap.put(getDepartment(employeeList,i), getSalary(employeeList,i));
			}
		}
		System.out.println("Average Salary of each Department : ");
		for (Map.Entry<String, Double> entry : salaryMap.entrySet()) {
			System.out.println(entry.getKey() + " : "
					+ String.format("%.2f", entry.getValue() / mapOfEmployeeDepartments.get(entry.getKey())));
		}
		System.out.println();
	}

	//8.Get the details of youngest male employee in the product development department?
	public void getYoungestEmployee(List<Employee> employeeList) {
		int minimumAge = Integer.MAX_VALUE;
		int minimumIndex = 0;
		for (int i = 0; i < employeeList.size(); i++) {
			if (isEmployeeInProductDevelopment(i, employeeList, minimumAge)) {
				minimumAge = getAge(employeeList,i);
				minimumIndex = i;
			}
		}
		System.out.println("Youngest Male Employee in the Product Development Department : ");
		System.out.println(employeeList.get(minimumIndex));
	}

	public boolean isEmployeeInProductDevelopment(int index, List<Employee> employeeList, int minimumAge) {
		return getGender(employeeList,index).equalsIgnoreCase(MALE)
				&& getDepartment(employeeList,index).equalsIgnoreCase(PRODUCT_DEVELOPMENT)
				&& (getAge(employeeList,index) < minimumAge);
	}

	//9.Who has the most working experience in the organization?
	public void getMostExperiencedEmployee(List<Employee> employeeList) {
		int maximumYears = 0;
		int maximumYearsIndex = 0;
		for (int i = 0; i < employeeList.size(); i++) {
			if ((2023 - employeeList.get(i).getYearOfJoining()) > maximumYears) {
				maximumYearsIndex = i;
				maximumYears = 2023 - employeeList.get(i).getYearOfJoining();
			}
		}
		System.out.println();
		System.out.println("Most Experienced Employee in the Organization : "
				+ employeeList.get(maximumYearsIndex).getName());
	}

	//10.How many male and female employees are there in the sales and marketing team?
	public void getEmployeesInSalesAndMarketing(List<Employee> employeeList) {
		int malesInSalesAndMarketing = 0;
		int femalesInSalesAndMarketing = 0;
		for (int i = 0; i < employeeList.size(); i++) {
			if (isMaleEmployeeInSalesAndMarketing(employeeList,i)) {
				malesInSalesAndMarketing++;
			} else if (isFemaleEmployeeInSalesAndMarketing(employeeList,i)) {
				femalesInSalesAndMarketing++;
			}
		}
		System.out.println("\nMale Employees in Sales and Marketing : " + malesInSalesAndMarketing);
		System.out.println("Female Employees in Sales and Marketing : " + femalesInSalesAndMarketing);
	}

	private boolean isMaleEmployeeInSalesAndMarketing(List<Employee> employeeList,int index) {
		return getDepartment(employeeList,index).equalsIgnoreCase(SALES_AND_MARKETING)
				&& getGender(employeeList,index).equalsIgnoreCase(MALE);
	}

	private boolean isFemaleEmployeeInSalesAndMarketing(List<Employee> employeeList, int index) {
		return getDepartment(employeeList,index).equalsIgnoreCase(SALES_AND_MARKETING)
				&& getGender(employeeList,index).equalsIgnoreCase(FEMALE);

	}

	//11.What is the average salary of male and female employees?
	public void getAverageSalaryByGender(List<Employee> employeeList) {
		for (int i = 0; i < employeeList.size(); i++) {
			if (getGender(employeeList,i).equalsIgnoreCase(MALE)) {
				totalSalaryOfMaleEmployees += getSalary(employeeList,i);
			}
			else {
				totalSalaryOfFemaleEmployees += getSalary(employeeList,i);
			}
		}
		
		float maleAverageSalary = (totalSalaryOfMaleEmployees / (numberOfMaleEmployees));
		float femaleAverageSalary = (totalSalaryOfFemaleEmployees / numberOfFemaleEmployees);
		System.out.println("\nAverage Male Employee salary : " + maleAverageSalary);
		System.out.println("Average Female Employee salary : " + femaleAverageSalary);
	}

	//12.List down the names of all employees in each department?
	public void getAllEmployeeNames(List<Employee> employeeList) {
		HashMap<String, List<Employee>> employeeMap = new HashMap<>();
		for (int i = 0; i < employeeList.size(); i++) {
			if (employeeMap.containsKey(getDepartment(employeeList,i))) {
				employeeMap.get(getDepartment(employeeList,i)).add(employeeList.get(i));
			} else {
				List<Employee> list = new ArrayList<>();
				list.add(employeeList.get(i));
				employeeMap.put(getDepartment(employeeList,i), list);
			}
		}
		System.out.println("\nNames of all Employees in each Department : ");
		for (Map.Entry<String, List<Employee>> map : employeeMap.entrySet()) {
			System.out.println("\n" + map.getKey() + ":");
			for (int i = 0; i < map.getValue().size(); i++) {
				System.out.println(map.getValue().get(i).getName());
			}
		}
		System.out.println();
	}

	//13.What is the average salary and total salary of the whole organization?
	public void getAverageAndTotalSalary(List<Employee> employeeList) {
		int totalEmployees = numberOfMaleEmployees + numberOfFemaleEmployees;
		float totalSalary = totalSalaryOfMaleEmployees + totalSalaryOfFemaleEmployees;
		System.out.println("Total Salary Of All Employees: " + totalSalary + ", Average Salary Of All Employees : " + (totalSalary/totalEmployees));
	}

	//14.Separate the employees who are younger or equal to 25 years from those employees who are older than 25 years.
	public void getEmployeesSeparatedByAge(List<Employee> employeeList) {
		List<Employee> oldEmployeeList = new ArrayList<>();
		List<Employee> youngEmployeeList = new ArrayList<>();
		for (int i = 0; i < employeeList.size(); i++) {
			if (getAge(employeeList,i) <= 25) {
				youngEmployeeList.add(employeeList.get(i));
			} else {
				oldEmployeeList.add(employeeList.get(i));
			}
		}
		System.out.println("\nEmployees who are younger or equal to 25 years : ");
		System.out.println(youngEmployeeList);
		System.out.println("\nEmployees who are older than 25 years : " );
		System.out.println(oldEmployeeList);
	}

	//15.Who is the oldest employee in the organization? What is his age and which department he belongs to?
	public void getOldestEmployee(List<Employee> employeeList) {
		int oldestEmployeeAge = 0;
		StringBuilder oldestEmployeeDepartment = new StringBuilder("");
		for (int i = 0; i < employeeList.size(); i++) {
			if (getAge(employeeList,i) > oldestEmployeeAge) {
				if (oldestEmployeeDepartment.length() != 0) {
					oldestEmployeeDepartment.delete(0, oldestEmployeeDepartment.length());
				}
				oldestEmployeeAge = getAge(employeeList,i);
				oldestEmployeeDepartment.append(getDepartment(employeeList,i));
			}
		}
		System.out.println("\n" + String.format("Oldest Employee Age: %d, Department : %s", oldestEmployeeAge,
				oldestEmployeeDepartment));
	}
	
	public String getGender(List<Employee> employeeList,int index) {
		return employeeList.get(index).getGender();
	}
	public String getDepartment(List<Employee> employeeList,int index) {
		return employeeList.get(index).getDepartment();
	}
	public double getSalary(List<Employee> employeeList,int index) {
		return employeeList.get(index).getSalary();
	}
	public int getAge(List<Employee> employeeList,int index) {
		return employeeList.get(index).getAge();
	}
	
}