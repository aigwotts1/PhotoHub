package com.epam.collections.hometask;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class ReverseSort implements Comparator<Integer> {

	@Override
	public int compare(Integer first, Integer second) {
		return second.compareTo(first);
	}	
}

public class ReverseSortUsingComparator {

	public static void main(String[] args) {
		List<Integer> listOfNumbers = Arrays.asList(4,3,2,1,5);
		Collections.sort(listOfNumbers, new ReverseSort());
		for (int i = 0; i < listOfNumbers.size(); i++) {
			System.out.println(listOfNumbers.get(i));
		}
	}
}