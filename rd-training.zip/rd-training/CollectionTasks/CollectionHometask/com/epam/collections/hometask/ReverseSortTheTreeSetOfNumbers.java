package com.epam.collections.hometask;

import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;
//reverse naming
public class ReverseSortTheTreeSetOfNumbers {

	public static void main(String[] args) {
		Set<Integer> setOfNumbers = new TreeSet<>(Collections.reverseOrder());
		setOfNumbers.add(3);
		setOfNumbers.add(2);
		setOfNumbers.add(9);
		setOfNumbers.add(1);
		setOfNumbers.add(7);
		setOfNumbers.add(5);
		System.out.println(setOfNumbers);
	}
}