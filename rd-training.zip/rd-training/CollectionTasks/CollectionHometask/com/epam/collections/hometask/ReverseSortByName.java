package com.epam.collections.hometask;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseSortByName {

	public static void main(String[] args) {
		List<String> listOfNames = Arrays.asList("Abhi","Adi","Cck","Jordan");
		Collections.sort(listOfNames, Collections.reverseOrder());
		System.out.println(listOfNames);	
	}
}