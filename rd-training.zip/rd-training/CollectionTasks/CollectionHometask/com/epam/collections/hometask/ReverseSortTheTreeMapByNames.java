package com.epam.collections.hometask;

import java.util.Collections;
import java.util.TreeMap;

public class ReverseSortTheTreeMapByNames {

	public static void main(String[] args) {
		TreeMap<String, Integer> employeeTreeMap = new TreeMap<>(Collections.reverseOrder());
		employeeTreeMap.put("Aditya", 2);
		employeeTreeMap.put("Deepan", 9);
		employeeTreeMap.put("Chaitanya", 10);
		employeeTreeMap.put("Abhinav", 1);
		System.out.println(employeeTreeMap);
	}
}