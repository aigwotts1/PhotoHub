package com.epam.collections.hometask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ReverseSortTheTreeMapByValues {

	public static void main(String[] args) {
		Map<String, Integer> employeeTreeMap = new TreeMap<>();
		employeeTreeMap.put("Abhi", 0);
		employeeTreeMap.put("Deepan", 4);
		employeeTreeMap.put("Aadi", 1);
		employeeTreeMap.put("CCK", 2);
		employeeTreeMap.put("Ronaldo", 3);
		
		Set<Map.Entry<String, Integer>> valueSet = employeeTreeMap.entrySet();
		List<Map.Entry<String, Integer>> valueList = new ArrayList<>(valueSet);
		
		Collections.sort(valueList, new Comparator<Map.Entry<String, Integer>>() {
			public int compare(Map.Entry<String, Integer> e1, Map.Entry<String, Integer> e2) {
				return e2.getValue().compareTo(e1.getValue());
			}
		});	
		employeeTreeMap.clear();
		System.out.println(valueList);
	}
}