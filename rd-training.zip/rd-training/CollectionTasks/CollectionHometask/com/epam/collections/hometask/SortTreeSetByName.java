package com.epam.collections.hometask;

import java.util.Set;
import java.util.TreeSet;

public class SortTreeSetByName {

	public static void main(String[] args) {
		Set<String> nameSet = new TreeSet<>();
		nameSet.add("Chaitanya");
		nameSet.add("Deepan");
		nameSet.add("Abhinav");
		nameSet.add("Aditya");
		System.out.println(nameSet);
	}
}