package com.epam.collections.hometask;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class SortByName implements Comparator<String> {

	@Override
	public int compare(String firstName, String secondName) {
		return firstName.compareTo(secondName);
	}
}

public class SortByNameUsingComparator {

	public static void main(String[] args) {
		List<String> employeeList = Arrays.asList("Deepan","Abhi","Aadi","Chaitanya");
		Collections.sort(employeeList, new SortByName());
		for (int i = 0; i < employeeList.size(); i++) {
			System.out.println(employeeList.get(i));
		}
	}
}