package com.epam.core.java;

public class Task5 {
	
	public static String findTheDay(String days[], String day, int daysToSkip) {
		int totalWeekDays = 7;
		daysToSkip = (daysToSkip % totalWeekDays);
		int index = 0;		
		for (int i = 0; i < totalWeekDays; i++) {
			if (days[i].equals(day)) {
				index = i;
			}
		}	
		return days[(index + daysToSkip) % totalWeekDays];
	}

	public static void main(String args[]) {
		String days[] = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
		int daysToSkip = 3;
		String currentDay = "Wednesday";
		System.out.println(findTheDay(days, currentDay, daysToSkip));
	}
}