package com.epam.core.java;

import java.util.List;

public class Trainer extends Employee implements Printable {

	private List<String> skills;
	private List<String> certifications;

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public List<String> getCertifications() {
		return certifications;
	}

	public void setCertifications(List<String> certifications) {
		this.certifications = certifications;
	}

	@Override
	public void printDetails() {
		System.out.println("Skills: " + skills + " and Certifications: " + certifications);
	}
}