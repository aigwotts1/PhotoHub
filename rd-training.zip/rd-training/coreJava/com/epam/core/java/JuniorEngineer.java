package com.epam.core.java;

public class JuniorEngineer extends Employee implements Printable {

	float assessmentScore;
	String feedback;
	
	public float getAssessmentScore() {
		return assessmentScore;
	}
	
	public void setAssessmentScore(float assessmentScore) {
		this.assessmentScore = assessmentScore;
	}
	
	public String getFeedback() {
		return feedback;
	}
	
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
}