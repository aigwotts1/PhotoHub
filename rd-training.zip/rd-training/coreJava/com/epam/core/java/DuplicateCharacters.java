package com.epam.core.java;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class DuplicateCharacters {
	
	public static void main(String[] args) {
		Set<Character> characterSet = new HashSet<>();
		String sentence = "epam systems";
		char characterArray[]= sentence.toCharArray();
		Arrays.sort(characterArray);
		for(int i = 0 ; i < characterArray.length-1; i++) {
			if(characterArray[i] == characterArray[i+1]) {
				characterSet.add(characterArray[i]);
			}
		}
		System.out.println("Duplicate Characters in the given String : " + characterSet);
	}
}