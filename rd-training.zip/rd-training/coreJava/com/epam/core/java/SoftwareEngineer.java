package com.epam.core.java;

public class SoftwareEngineer extends Employee implements Printable {

	private String projectName;

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	@Override
	public void printDetails() {
		System.out.println("Software Engineer Employee ID is " + getId() + " , his name is " + getName()
				+ " , Employee salary is " + getSalary() + " Rupees" + " and Project Name: " + getProjectName());
	}
}