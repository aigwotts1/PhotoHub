package com.epam.core.java;

interface Printable {
	
	void printDetails();
}