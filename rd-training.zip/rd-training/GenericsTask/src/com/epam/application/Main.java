package com.epam.application;

import com.epam.Customer;
import com.epam.GenericUtility;


public class Main {
	
	public static void main(String[] args) {
	System.out.println(GenericUtility.receiveLeastValue(10, 12)); 
	System.out.println(GenericUtility.receiveLeastValue(10.9, 45.8));
        System.out.println(GenericUtility.receiveLeastValue(28.9f, 12.8f));
        System.out.println(GenericUtility.receiveLeastValue(new Customer("Adam John", 65000.90), new Customer("Steve Rolca", 40000.0)));
	}
}
