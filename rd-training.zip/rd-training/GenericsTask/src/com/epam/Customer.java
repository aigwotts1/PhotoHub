package com.epam;

public class Customer implements Comparable<Customer>{

	private String customerName;
	private double customerSalary;

	public Customer(String customerName, double customerSalary) {
		super();
		this.customerName = customerName;
		this.customerSalary = customerSalary;
	}

	public String getCustomerName() {
		return customerName;
	}

	public double getCustomerSalary() {
		return customerSalary;
	}

	public String toString(){
                return customerName+ " , " + customerSalary;
        }

	@Override
	public int compareTo(Customer c2){
		if(this.customerSalary<c2.getCustomerSalary()) {
		return -1;
		}
		return 1;
	}
}

