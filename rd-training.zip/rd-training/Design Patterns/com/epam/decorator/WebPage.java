package com.epam.decorator;

public interface WebPage {

	public double rank();
}