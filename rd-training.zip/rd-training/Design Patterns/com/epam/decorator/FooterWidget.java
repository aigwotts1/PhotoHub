package com.epam.decorator;

public class FooterWidget extends WebPageDecorator {

	public FooterWidget(WebPage webPage) {
		super(webPage);
		System.out.println("adding footer widget");
	}

	@Override
	public double rank() {
		return super.rank() + 100;
	}
}