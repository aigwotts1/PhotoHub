package com.epam.decorator;

public class PlainWebPage implements WebPage {

	public PlainWebPage() {
		System.out.println("plain webpage");
	}

	public double rank() {
		return 0;
	}
}