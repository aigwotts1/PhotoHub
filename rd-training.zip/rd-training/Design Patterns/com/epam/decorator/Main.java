package com.epam.decorator;

public class Main {

	public static void main(String[] args) {

		WebPage webpage = new NavigationBarWidget(new FooterWidget(new PlainWebPage()));
		System.out.println(webpage.rank());
	}
}