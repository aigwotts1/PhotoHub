package com.epam.decorator;

public class NavigationBarWidget extends WebPageDecorator {

	public NavigationBarWidget(WebPage webPage) {
		super(webPage);
		System.out.println("adding navbar widget");
	}
	
	@Override
	public double rank() {
		return super.rank() + 50;
	}
}