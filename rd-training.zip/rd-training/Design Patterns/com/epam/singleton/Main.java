package com.epam.singleton;

public class Main {

	public static void main(String[] args) {

		CandyMaker candyobject1 = CandyMaker.getInstance();
		CandyMaker candyobject2 = CandyMaker.getInstance();
		System.out.println(candyobject1);
		System.out.println(candyobject2);
	}
}