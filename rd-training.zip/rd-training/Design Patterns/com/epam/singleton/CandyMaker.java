package com.epam.singleton;

public class CandyMaker {

	private CandyMaker() {
		empty = true;
		boiled = false;
	}

	private boolean empty;
	private boolean boiled;

	private static CandyMaker candyMakerObject = new CandyMaker();

	public static CandyMaker getInstance() {
		return candyMakerObject;
	}

	public void fill() {
		if (isEmpty()) {
			empty = false;
			boiled = false;
		}
	}

	public void drain() {
		if (isNotEmpty() && isBoiled()) {
			empty = true;
		}
	}

	public void boil() {
		if (isNotEmpty() && isNotBoiled()) {
			boiled = true;
		}
	}

	private boolean isEmpty() {
		return empty;
	}

	public boolean isBoiled() {
		return boiled;
	}
	
	private boolean isNotBoiled() {
		return !isBoiled();
	}
	
	private boolean isNotEmpty() {
		return !isEmpty();
	}

}