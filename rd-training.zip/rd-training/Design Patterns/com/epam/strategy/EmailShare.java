package com.epam.strategy;

public class EmailShare implements Shareable{
	
	public void share() {
		System.out.println("sharing image via email");
	}
}