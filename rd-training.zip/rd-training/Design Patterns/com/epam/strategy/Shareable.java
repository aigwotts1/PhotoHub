package com.epam.strategy;

public interface Shareable {
	
	public void share();
}
