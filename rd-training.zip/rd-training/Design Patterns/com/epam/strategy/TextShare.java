package com.epam.strategy;

public class TextShare implements Shareable {

	public void share() {
		System.out.println("sharing image via text");
	}
}