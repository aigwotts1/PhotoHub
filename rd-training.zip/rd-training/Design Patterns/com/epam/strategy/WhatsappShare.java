package com.epam.strategy;

public class WhatsappShare implements Shareable {

	public void share() {
		System.out.println("sharing image via whatsapp");
	}
}