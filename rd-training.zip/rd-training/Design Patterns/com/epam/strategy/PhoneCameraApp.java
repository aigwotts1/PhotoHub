package com.epam.strategy;

public class PhoneCameraApp {
	
	public void takePhoto() {
		// implementation
	}

	public void editPhoto() {
		// implementation
	}

	public void savePhoto() {
		// implementation
	}

	public void sharePhoto(Shareable shareFunctionality) {
		shareFunctionality.share();
	}
}