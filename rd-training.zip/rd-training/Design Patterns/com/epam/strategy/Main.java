package com.epam.strategy;

public class Main {

	public static void main(String[] args) {
		
		PhoneCameraApp phoneCameraApp = new PhoneCameraApp();
		phoneCameraApp.sharePhoto(new TextShare());
	}
}