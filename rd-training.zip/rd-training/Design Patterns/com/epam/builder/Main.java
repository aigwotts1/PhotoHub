package com.epam.builder;

public class Main {

	public static void main(String[] args) {

		Bicycle bicycle = new BicycleBuilder().setDoubleSeats(true).getBicycle();
		System.out.println(bicycle);
	}
}