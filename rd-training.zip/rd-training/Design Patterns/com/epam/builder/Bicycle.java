package com.epam.builder;

public class Bicycle {

	private boolean gears;
	private boolean doubleSeats;
	private boolean doubleStands;
	private boolean carrier;

	@Override
	public String toString() {
		return "Bicycle [gears=" + gears + ", doubleSeats=" + doubleSeats + ", doubleStands=" + doubleStands
				+ ", carrier=" + carrier + "]";
	}

	public Bicycle(boolean gears, boolean doubleSeats, boolean doubleStands, boolean carrier) {
		super();
		this.gears = gears;
		this.doubleSeats = doubleSeats;
		this.doubleStands = doubleStands;
		this.carrier = carrier;
	}
}