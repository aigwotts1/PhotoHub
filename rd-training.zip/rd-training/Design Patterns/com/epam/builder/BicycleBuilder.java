package com.epam.builder;

public class BicycleBuilder {

	private boolean gears;
	private boolean doubleSeats;
	private boolean doubleStands;
	private boolean carrier;

	public BicycleBuilder setGears(boolean gears) {
		this.gears = gears;
		return this;
	}

	public BicycleBuilder setDoubleSeats(boolean doubleSeats) {
		this.doubleSeats = doubleSeats;
		return this;
	}

	public BicycleBuilder setDoubleStands(boolean doubleStands) {
		this.doubleStands = doubleStands;
		return this;
	}

	public BicycleBuilder setCarrier(boolean carrier) {
		this.carrier = carrier;
		return this;
	}

	public Bicycle getBicycle() {
		return new Bicycle(gears, doubleSeats, doubleStands, carrier);
	}
}