package com.epam.quiz.app.model;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Component
@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(unique = true)
	private String user_name;
	private String password;
	@Column(name = "is_admin")
	private boolean isAdmin;

	public User() {
	}
	public String getUserName() {
		return user_name;
	}

	public void setUserName(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	@Override
	public String toString() {
		return "User [user_name=" + user_name + ", password=" + password + ", isAdmin=" + isAdmin + "]";
	}

	public User(String user_name, String password, boolean isAdmin) {
		this.user_name = user_name;
		this.password = password;
		this.isAdmin = isAdmin;
	}

	public User(String user_name, String password) {
		this.user_name = user_name;
		this.password = password;
	}
}