package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.service.QuestionService;

@Component
public class RemoveQuestionView {
	
	@Autowired
	QuestionService questionService;
	
	private static final Logger LOGGER = LogManager.getLogger(RemoveQuestionView.class);
	Scanner inputScanner = new Scanner(System.in);

	public void deleteQuestion() {
		LOGGER.info("-----------------------------------\n");
		LOGGER.info("Enter Title Of Question To Be Removed :");
		String questionTitle = inputScanner.nextLine();
		questionService.removeQuestion(questionTitle);
		LOGGER.info("-------Question Removed :)------\n");
	}
}