package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.service.QuizService;

@Component
public class DeleteQuizView {
	
	@Autowired
	QuizService quizService;

	private static final Logger LOGGER = LogManager.getLogger(DeleteQuizView.class);
	Scanner inputScanner = new Scanner(System.in);

	public void deleteQuiz() {
		
		LOGGER.info("----------------------------------------\n");
		LOGGER.info("\nEnter the title of the quiz to be deleted: ");
    	String title = inputScanner.nextLine();
    	quizService.removeQuiz(title);
		LOGGER.info("---------Quiz removed!!!------------\n");
	}
}