package com.epam.quiz.app.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.service.QuestionService;

@Component
public class CreateQuestionView {

	@Autowired
	QuestionService questionService;
	
	@Autowired
	Question question;
	
	private static final Logger LOGGER = LogManager.getLogger(CreateQuestionView.class);
	Scanner inputScanner = new Scanner(System.in);
	private static final String FOUR = "4";
	private static final String TWO = "2";

	public void addQuestion() {

		LOGGER.info("-----------------------\n");
		String title = getTitleFromUser();
		List<String> numberOfOptions = getNumberOfOptionsFromUser();
		String difficulty = getDifficultyFromUser();
		String topicTags = getTopicTagsFromUser();
		int answerNumber = getCorrectAnswerNumberFromUser();
		
		question.setTitle(title);
		question.setOptions(numberOfOptions);
		question.setDificulty(difficulty);
		question.setTopics(topicTags);
		question.setAnswer(answerNumber);
		//questionService.createQuestion(question);
		LOGGER.info("-------Question Created :)----------\n");
	}

	private String getTitleFromUser() {
		LOGGER.info("Enter Title Of New Question :");
		String questionTitle = inputScanner.nextLine();
		throwExceptionIfBlankInput(questionTitle);
		return questionTitle;
	}
	
	private List<String> getNumberOfOptionsFromUser() {
		LOGGER.info("Enter Number Of  Options i.e. 2/4 :");
		String option = inputScanner.nextLine();
		return addOptions(option);
	}

	private String getDifficultyFromUser() {
		LOGGER.info("Enter Difficulty i.e. Easy,Medium,etc :");
		String difficulty = inputScanner.nextLine();
		throwExceptionIfBlankInput(difficulty);
		return difficulty;
	}

	private String getTopicTagsFromUser() {
		LOGGER.info("Enter Topic Tags :");
		String topics = inputScanner.nextLine();
		throwExceptionIfBlankInput(topics);
		return topics;
	}

	private int getCorrectAnswerNumberFromUser() {
		LOGGER.info("Type Answer Number Which Is Correct :");
		return inputScanner.nextInt();
	}
	
	private void throwExceptionIfBlankInput(String input) {
		if(input.isBlank()) {
			throw new IllegalArgumentException("Input Should Not Be Blank!!!");
		}
	}

	private List<String> addOptions(String option) {
		List<String> questionOptions;
		String optionOne;
		String optionTwo;
		String optionThree;
		String optionFour;
		
		switch (option) {
		case FOUR:
			optionOne = getOptionOneFromUser();
			optionTwo = getOptionTwoFromUser();
			optionThree = getOptionThreeFromUser();
			optionFour = getOptionFourFromUser();
			questionOptions = Arrays.asList(optionOne,optionTwo,optionThree,optionFour);
			break;
		case TWO:
			optionOne = getOptionOneFromUser();
			optionTwo = getOptionTwoFromUser();
			questionOptions = Arrays.asList(optionOne,optionTwo);
			break;
		default:
			throw new IllegalArgumentException("Enter Valid Number");
		}
		return questionOptions;
	}

	private String getOptionFourFromUser() {
		String optionFour;
		LOGGER.info("Enter option 4 :");
		optionFour = inputScanner.nextLine();
		return optionFour;
	}

	private String getOptionThreeFromUser() {
		String optionThree;
		LOGGER.info("Enter option 3 :");
		optionThree = inputScanner.nextLine();
		return optionThree;
	}

	private String getOptionTwoFromUser() {
		String optionTwo;
		LOGGER.info("Enter option 2 :");
		optionTwo = inputScanner.nextLine();
		return optionTwo;
	}

	private String getOptionOneFromUser() {
		String optionOne;
		LOGGER.info("Enter option 1 :");
		optionOne = inputScanner.nextLine();
		return optionOne;
	}
}