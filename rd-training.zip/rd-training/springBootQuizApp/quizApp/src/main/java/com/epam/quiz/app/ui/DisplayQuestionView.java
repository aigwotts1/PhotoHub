package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.service.QuestionService;

@Component
public class DisplayQuestionView {
	
	@Autowired
	QuestionService questionService;

	private static final Logger LOGGER = LogManager.getLogger(DisplayQuestionView.class);
	Scanner inputScanner = new Scanner(System.in);

	public void viewQuestion() {
		LOGGER.info("----------------------------------------\n");
		LOGGER.info("Enter Title of Specific Question To View :");
		String questionTitle = inputScanner.nextLine();
		LOGGER.info(questionService.viewQuestion(questionTitle));
		LOGGER.info("\n-------------------------------\n");
	}
}