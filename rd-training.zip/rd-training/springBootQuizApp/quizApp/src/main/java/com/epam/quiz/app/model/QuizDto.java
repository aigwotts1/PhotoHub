package com.epam.quiz.app.model;


import java.util.List;

public class QuizDto {
	
	private String title;
	List<Question> questionList;
	private int total_marks;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}
	public int getTotalMarks() {
		return total_marks;
	}
	@Override
	public String toString() {
		return "QuizDto [title=" + title + ", questionList=" + questionList + ", total_marks=" + total_marks + "]";
	}
	public void setTotalMarks(int totalMarks) {
		this.total_marks = totalMarks;
	}
}