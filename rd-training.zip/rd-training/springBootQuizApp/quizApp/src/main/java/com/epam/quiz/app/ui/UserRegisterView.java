package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.model.User;
import com.epam.quiz.app.service.UserService;

@Service
public class UserRegisterView {

	@Autowired
	UserService service;
	
	private static final Logger LOGGER = LogManager.getLogger(UserRegisterView.class);
	Scanner input = new Scanner(System.in);
	private static final String ONE = "1";
	
	public User registerUser() {
		LOGGER.info("-------------\n");
		LOGGER.info("Enter Username :");
		String userName = input.nextLine();
		LOGGER.info("Enter Password :");
		String password = input.nextLine();
		LOGGER.info("Press 1 if user is set to be Admin or Press Enter If Not :");

		String adminCheck = input.nextLine();
		boolean isUserAdmin = false;
		if(adminCheck.equals(ONE)) {
			isUserAdmin = true;
		}
		LOGGER.info("-------User Registered :)--------\n");
		return service.addUser(userName, password,isUserAdmin);
	}
}