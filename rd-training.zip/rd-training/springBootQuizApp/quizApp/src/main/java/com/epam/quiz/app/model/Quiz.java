package com.epam.quiz.app.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Component;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;

@Component
@Entity
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(unique = true)
	private String title;
	
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name = "quiz_question",joinColumns = @JoinColumn(name = "quiz_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "question_id", referencedColumnName = "id"))
	private List<Question> questionList = new ArrayList<>();
	
	private int total_marks;

	public Quiz() {
	}

	public Quiz(String title, List<Question> questionList) {
		this.title = title;
		this.questionList = questionList;
	}

	public Quiz(String title, List<Question> questionList, int total_marks) {
		this.title = title;
		this.questionList = questionList;
		this.total_marks = total_marks;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	@Override
	public int hashCode() {
		return Objects.hash(questionList, title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Quiz other = (Quiz) obj;
		return Objects.equals(questionList, other.questionList) && Objects.equals(title, other.title);
	}

	@Override
	public String toString() {
		return "Quiz [title=" + title + ", questionList=" + questionList + "]";
	}

	public int getTotalMarks() {
		int sumMarks = 0;
		for (Question question : questionList) {
			sumMarks += question.getMarks();
			this.total_marks = sumMarks;
		}
		return total_marks;
	}

	public void setTotalMarks(int total_marks) {
		this.total_marks = total_marks;
	}
}