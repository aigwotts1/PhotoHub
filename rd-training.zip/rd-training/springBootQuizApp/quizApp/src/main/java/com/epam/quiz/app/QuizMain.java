package com.epam.quiz.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.ui.QuizAppView;

@Component
public class QuizMain {
	
	@Autowired
	QuizAppView quizApp;
	
    public void createQuiz()
    {		
		quizApp.initializeQuiz();
    }
}