package com.epam.quiz.app.dao;

import java.util.Map;

import com.epam.quiz.app.model.Quiz;

public interface QuizOperations {

	Quiz addQuiz(Quiz quiz);
	Quiz removeQuiz(String title);
	Quiz modifyQuiz(String title, Quiz quiz);
	Map<String, Quiz> viewAllQuiz();
	public Quiz addMarksToQuizQuestion(String title, int questionMarks, Quiz quiz);
	Quiz getQuizByTitle(String title);
}