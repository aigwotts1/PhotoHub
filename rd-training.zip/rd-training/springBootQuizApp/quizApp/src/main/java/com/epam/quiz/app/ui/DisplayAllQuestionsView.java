package com.epam.quiz.app.ui;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.service.QuestionService;

@Component
public class DisplayAllQuestionsView {

	@Autowired
	QuestionService questionService;

	private static final Logger LOGGER = LogManager.getLogger(DisplayAllQuestionsView.class);

	public void viewAllQuestions() {
		
		Map<String, Question> questionMap = questionService.viewAllQuestions();
		throwExceptionIfNoQuestionFound(questionMap);
		printQuestionMap(questionMap);
		LOGGER.info("-----------------------------\n");
	}

	private void printQuestionMap(Map<String, Question> questionMap) {
		for (Map.Entry<String, Question> map : questionMap.entrySet()) {
			LOGGER.info("{}\n", map.getValue());
		}
	}

	private void throwExceptionIfNoQuestionFound(Map<String, Question> questionMap) {
		if (questionMap.isEmpty()) {
			throw new IllegalArgumentException("No Questions Added");
		}
	}
}