package com.epam.quiz.app.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.dao.QuizOperations;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;

@Service
public class QuizService {

	@Autowired
	QuizOperations quizUtility;
	
	Quiz quiz = new Quiz();
	
	public Quiz addQuiz(QuizDto quizDto) {
		quiz.setTitle(quizDto.getTitle());
		return quizUtility.addQuiz(quiz);
	}

	public Quiz removeQuiz(String title) {
		return quizUtility.removeQuiz(title);
	}

	public Quiz modifyQuiz(String title, Quiz quiz) {
		return quizUtility.modifyQuiz(title, quiz);
	}

	public Map<String, Quiz> viewAllQuiz() {
		return quizUtility.viewAllQuiz();
	}

	public Quiz addMarksToQuizQuestion(String title, int questionMarks, Quiz quiz) {
		return quizUtility.addMarksToQuizQuestion(title, questionMarks, quiz);
	}
	public Quiz getQuizByTitle(String title) {
		return quizUtility.getQuizByTitle(title);
	}
}