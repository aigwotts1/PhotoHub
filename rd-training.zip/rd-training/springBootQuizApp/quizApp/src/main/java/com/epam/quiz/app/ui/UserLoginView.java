package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.model.User;
import com.epam.quiz.app.service.UserService;

@Service
public class UserLoginView {
	
	@Autowired
	UserService userService;
	
	private static final Logger LOGGER = LogManager.getLogger(UserLoginView.class);
	Scanner inputScanner = new Scanner(System.in);
	
	public User loginUser() {
		
		LOGGER.info("--------------");
		LOGGER.info("\nEnter Username: \n");
		String username = inputScanner.nextLine();
		LOGGER.info("Enter Password: \n");
		String password = inputScanner.nextLine();
		
		User user = userService.getUser(username, password);
		LOGGER.info("\n---------Login Success :)--------------\n");
		return user;
	}
}