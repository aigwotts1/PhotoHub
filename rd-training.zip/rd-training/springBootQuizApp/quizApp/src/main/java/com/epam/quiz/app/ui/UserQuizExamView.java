package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.service.QuizService;

@Component
public class UserQuizExamView {
	
	@Autowired
	QuizService quizService;

	private static final Logger LOGGER = LogManager.getLogger(UserQuizExamView.class);
	Scanner inputScanner = new Scanner(System.in);
	
	public void takeQuiz() {

		String quizTitle = getTitleFromUser();
		int marksScored = 0;
		Quiz quiz = quizService.viewAllQuiz().get(quizTitle);
		throwExceptionIfQuizNotFound(quiz);

		for (Question question : quiz.getQuestionList()) {
			LOGGER.info("------------------------------\n");
			
			diplayQuestions(question);
			int answerNumber = getAnswerNumberFromUser();
			marksScored = getMarksScoredByUser(marksScored, question, answerNumber);
			
			LOGGER.info("------------------------------\n");
		}
		LOGGER.info("your score: {} out of {}", marksScored, quiz.getTotalMarks());
	}

	private int getMarksScoredByUser(int marksScored, Question question, int answerNumber) {
		if (answerNumber == question.getAnswer()) {
			marksScored += question.getMarks();
		}
		return marksScored;
	}

	private int getAnswerNumberFromUser() {
		LOGGER.info("Type Answer Number: ");
		return inputScanner.nextInt();
	}

	private void diplayQuestions(Question question) {
		LOGGER.info("Question : {}\n", question.getTitle());
		LOGGER.info("Options :\n");
		for (int i = 0; i < question.getOptions().size(); i++) {
			if (question.getOptions().get(i) == null) {
				break;
			}
			LOGGER.info("{}) {}\n", i + 1, question.getOptions().get(i));
		}
	}

	private String getTitleFromUser() {
		LOGGER.info("Enter quiz title: ");
		return inputScanner.nextLine();
	}

	private void throwExceptionIfQuizNotFound(Quiz quiz) {
		if (quiz == null) {
			throw new IllegalArgumentException("quiz not found");
		}
	}
}