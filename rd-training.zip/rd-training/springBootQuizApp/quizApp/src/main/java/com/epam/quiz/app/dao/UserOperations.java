package com.epam.quiz.app.dao;

import com.epam.quiz.app.model.User;

public interface UserOperations {
	
	User addUser(String userName, String password, boolean isAdmin);
	User getUser(String userName, String password);
}