package com.epam.quiz.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
public class QuizAppApplication {

	EntityManagerFactory eFactory ;
	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(QuizAppApplication.class, args);
		context.getBean(QuizMain.class).createQuiz();
	}

	@Bean
	public EntityManager entityManager() {

		eFactory = Persistence.createEntityManagerFactory("JPADemo");
		return eFactory.createEntityManager();
	}
}
