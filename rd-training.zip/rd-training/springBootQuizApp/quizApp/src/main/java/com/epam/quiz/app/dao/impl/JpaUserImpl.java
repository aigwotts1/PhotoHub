package com.epam.quiz.app.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.epam.quiz.app.dao.UserOperations;
import com.epam.quiz.app.model.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;

@Repository
@Primary
public class JpaUserImpl implements UserOperations {
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	User user;
	
	@Override
	public User addUser(String userName, String password, boolean isAdmin) throws IllegalArgumentException {
		throwExceptionIfUsernameEmpty(userName);
		throwExceptionIfPasswordEmpty(password);
		
		user.setUserName(userName);
		user.setPassword(password);
		user.setIsAdmin(isAdmin);
		
		entityManager.getTransaction().begin();
		try {
			entityManager.persist(user);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public User getUser(String userName, String password) throws IllegalArgumentException {
		throwExceptionIfUsernameEmpty(userName);
		throwExceptionIfPasswordEmpty(password);
		try {
			user = entityManager.createQuery("FROM User u WHERE u.user_name='" + userName + "'",User.class).getSingleResult();
		}
		catch(NoResultException e) {
			throw new NullPointerException("No User Found");
		}
		return user;
	}

	private void throwExceptionIfPasswordEmpty(String password) {
		if (password.isBlank()) {
			throw new IllegalArgumentException("password can't be empty");
		}
	}

	private void throwExceptionIfUsernameEmpty(String userName) {
		if (userName.isBlank()) {
			throw new IllegalArgumentException("username can't be empty");
		}
	}
}