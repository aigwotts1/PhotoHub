package com.epam.quiz.app.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.epam.quiz.app.dao.QuestionOperations;
import com.epam.quiz.app.model.Question;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;

@Repository
@Primary
public class JpaQuestionImpl implements QuestionOperations {

	@Autowired
	EntityManager entityManager;

	@Autowired
	Question question;
	
	@Autowired
	Question newQues;
	
	private static final String INVALID_TITLE = "invalid title";

	@Override
	public Question createQuestion(Question question) {

		throwExceptionIfInvalidTitle(question);
		entityManager.getTransaction().begin();
		try {
			entityManager.persist(question);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();	
			e.printStackTrace();
		}
		return question;
	}

	@Override
	public Question removeQuestion(String title) {

		throwExceptionIfInvalidTitle(title);
		try {
			question = entityManager.createQuery("FROM Question q WHERE q.title = '" + title + "'",Question.class).getSingleResult();
		}
		catch(NoResultException e) {
			throw new NullPointerException("No Question Found");
		}	
		if (checkIfQuestionIsNotMappedToAnyQuiz(question)) {
			return removeQuestionByEntityManager(question);
		} else {
			throw new IllegalArgumentException("Question is mapped to a quiz can't be deleted you can modify it");
		}
	}

	@Override
	public Question modifyQuestion(String title, Question question) {
		
		throwExceptionIfInvalidTitle(title);
	    newQues = viewQuestion(title);
		entityManager.getTransaction().begin();
		try {
			newQues.setAnswer(question.getAnswer());
			newQues.setDificulty(question.getDificulty());
			newQues.setOptions(question.getOptions());
			newQues.setTopics(question.getTopics());
			entityManager.merge(newQues);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
		}
		return question;
	}

	@Override
	public Question viewQuestion(String title) {
		
		throwExceptionIfInvalidTitle(title);
		try{
			question = entityManager.createQuery("FROM Question q WHERE q.title = '" + title + "'",Question.class).getSingleResult();
		}
		catch(NoResultException e) {
			throw new NullPointerException("No Question Found");
		}
		
		return question;
	}


	@Override
	public Map<String, Question> viewAllQuestions() {
		List<Question> questionList = entityManager.createQuery("FROM Question",Question.class).getResultList();
		return questionList.stream().collect(Collectors.toMap(Question::getTitle, x -> x));
	}

	private void throwExceptionIfInvalidTitle(Question question) {
		if (question.getTitle().isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
	}
	
	private void throwExceptionIfInvalidTitle(String title) {
		if (title.isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
	}
	
    private boolean checkIfQuestionIsNotMappedToAnyQuiz(Question question) {
		return question.getQuizList().isEmpty();
	}

	private Question removeQuestionByEntityManager(Question question) {
		entityManager.getTransaction().begin();
		try {
			entityManager.remove(question);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
		}
		return question;
	}
}