package com.epam.quiz.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.dao.UserOperations;
import com.epam.quiz.app.model.User;

@Service
public class UserService {
	
	@Autowired
	UserOperations userOperations;

	public User addUser(String userName, String password, boolean isAdmin) {
		return userOperations.addUser(userName, password, isAdmin);
	}

	public User getUser(String userName, String password) {
    	return userOperations.getUser(userName, password);
	}
}