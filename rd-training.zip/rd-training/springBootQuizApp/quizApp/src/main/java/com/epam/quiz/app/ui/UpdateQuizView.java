package com.epam.quiz.app.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@Component
public class UpdateQuizView {
	
	@Autowired
	QuizService quizService;
	
	@Autowired
	QuestionService questionService;
	
	@Autowired
	Quiz quiz;

	private static final Logger LOGGER = LogManager.getLogger(UpdateQuizView.class);
	Scanner inputScanner = new Scanner(System.in);

	public void updateQuiz() {
	
		String title = getTitleFromUser();
		String updatedTitle;
		List<Question> questionsList = new ArrayList<>();
	
		do {
			String questionTitle = getQuestionTitleFromUser();
			updatedTitle = getQuizTitleToBeModified();	 
			int questionMarks = getModifiedMarksFromUser();
			
			Question question = questionService.viewAllQuestions().get(questionTitle);
			question.setMarks(questionMarks);
			questionsList.add(question);
			
			LOGGER.info("input '1' to exit or any other key to Modify Again: ");
		} while(isInputNotEqualToOne());
		
		quiz.setTitle(updatedTitle);
		quiz.setQuestionList(questionsList);
		quizService.modifyQuiz(title, quiz);
		LOGGER.info("---------Quiz modified :)--------\n");
	}

	private int getModifiedMarksFromUser() {
		LOGGER.info("Enter Marks :");
		return Integer.parseInt(inputScanner.nextLine());
	}

	private String getQuizTitleToBeModified() {
		LOGGER.info("Enter Quiz Title to be modified: ");
		return inputScanner.nextLine();
	}

	private String getQuestionTitleFromUser() {
		LOGGER.info("Enter question title: ");
		String questionTitle = inputScanner.nextLine();

		if (isQuestionNotPresent(questionTitle)) {
			throw new IllegalArgumentException("No Question Exist with the Given Title");
		}
		return questionTitle;
	}

	private String getTitleFromUser() {
		LOGGER.info("----------------------------------------\n");
		LOGGER.info("\nEnter title of the quiz to be modified: ");
		String title = inputScanner.nextLine();
		throwExceptionIfNoQuizExist(title);
		return title;
	}

	private void throwExceptionIfNoQuizExist(String title) {
		if(isQuizNotPresent(title)) {
			throw new IllegalArgumentException("No Quiz Exist with the Given Title");
		}
	}

	private boolean isInputNotEqualToOne() {
		return !inputScanner.nextLine().equals("1");
	}

	private boolean isQuizNotPresent(String title) {
		return !quizService.viewAllQuiz().containsKey(title);
	}

	private boolean isQuestionNotPresent(String questionTitle) {
		return !questionService.viewAllQuestions().containsKey(questionTitle);
	}
}