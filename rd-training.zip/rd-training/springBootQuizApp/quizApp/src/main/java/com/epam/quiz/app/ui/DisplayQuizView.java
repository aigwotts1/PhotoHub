package com.epam.quiz.app.ui;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.service.QuizService;

@Component
public class DisplayQuizView {
	
	@Autowired
	QuizService quizService;

	private static final Logger LOGGER = LogManager.getLogger(DisplayQuizView.class);

	public void viewAllQuiz() {
		Map<String, Quiz> quizMap = quizService.viewAllQuiz();
		throwExceptionIfNoQuizFound(quizMap);
		printQuizMap(quizMap);
		LOGGER.info("-----------------------------\n");
	}
	private void printQuizMap(Map<String, Quiz> quizMap) {
		for(Map.Entry<String, Quiz> map : quizMap.entrySet()) {
			LOGGER.info("{}\n",map.getValue());
		}
	}
	private void throwExceptionIfNoQuizFound(Map<String, Quiz> questionMap) {
		if (questionMap.isEmpty()) {
			throw new IllegalArgumentException("No Questions Added");
		}
	}
}