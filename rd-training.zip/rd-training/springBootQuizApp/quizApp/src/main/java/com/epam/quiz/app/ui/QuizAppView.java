package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.User;

@Component
public class QuizAppView {
	
	@Autowired
	UserLoginView login;
	
	@Autowired
	UserRegisterView register;
	
	@Autowired
	QuestionLibraryView questionOperations;
	
	@Autowired
	QuizLibraryView quizOperations;
	
	@Autowired
	UserQuizExamView quizExam;
	
	private static final Logger LOGGER = LogManager.getLogger(QuizAppView.class);
	Scanner inputScanner = new Scanner(System.in);
	private static final String ONE = "1";
	private static final String TWO = "2";
	private static final String THREE = "3";
	

	public void initializeQuiz() {

		LOGGER.info("\n-------Welcome To The Quiz :)-------");
		
		do {
			LOGGER.info("\nPress:\n'1' for Login\n'2' for Register\n");
			String input = inputScanner.nextLine();

//---------Check If The Person Is Admin Or User:----------------	
			User user = null;
			switch (input) {
			case ONE:
				user = login.loginUser();
				break;
			case TWO:
				user = register.registerUser();
				break;
			default:
				throw new IllegalArgumentException("Enter Valid Number\n");
			}

			if (user.isAdmin()) {
				do {
					LOGGER.info("TYPE: \n '1' to modify question library \n '2' to modify quiz library \n '3' to exit \n");
					input = inputScanner.nextLine();
					switch (input) {
//----------Question Library Code For Admins:-------------------					
					case ONE:
						questionOperations.performQuestionOperations();
						break;
//----------Quiz Library code For Admins:------------------------
					case TWO:
						quizOperations.performQuizOperations();
						break;
					case THREE:
						break;
					default:
						throw new IllegalArgumentException("Enter Valid Number\n");
					}
				} while(isInputNotEqualToThree(input));
			}
//----------User Giving Quiz Code:-------------------------------			
			else {	
				quizExam.takeQuiz();
				break;
			}
			LOGGER.info("Enter 1 to exit the Quiz or Press Enter to Continue Quiz:");
		} while (isInputNotEqualToOne(inputScanner.nextLine()));
	}
	private boolean isInputNotEqualToThree(String input) {
		return !input.equals(THREE);
	}
	private boolean isInputNotEqualToOne(String input) {
		return !input.equals(ONE);
	}
}