package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QuestionLibraryView {
	
	@Autowired
	CreateQuestionView createQuestion;
	
	@Autowired
	RemoveQuestionView removeQuestion;
	
	@Autowired
	ModifyQuestionView modifyQuestion;
	
	@Autowired
	DisplayQuestionView viewQuestion;
	
	@Autowired
	DisplayAllQuestionsView viewAll;
	
	private static final Logger LOGGER = LogManager.getLogger(QuestionLibraryView.class);
	Scanner inputScanner = new Scanner(System.in);

	enum UserOption {
		
		ADD_QUESTION("1"),
		REMOVE_QUESTION("2"),
		MODIFY_QUESTION("3"),
		VIEW_SPECIFIC_QUESTION("4"),
		VIEW_ALL_QUESTIONS("5"),
		BACK("6");

		private final String option;

		UserOption(String option) {
			this.option = option;
		}

		public String getOption() {
			return option;
		}
	}

	public void performQuestionOperations() {
		
		LOGGER.info("-----------------------\n");
		LOGGER.info("Press 1 to Add Question :\n");
		LOGGER.info("Press 2 to Remove Question :\n");
		LOGGER.info("Press 3 to Modify Question :\n");
		LOGGER.info("Press 4 to View Specific Question :\n");
		LOGGER.info("Press 5 to View All Questions :\n");
		LOGGER.info("Press 6 to Go Back :\n");

			String input = inputScanner.nextLine();
		    UserOption selectedOption = null;
		    
		    selectedOption = getSelectedOption(input, selectedOption);
		    throwExceptionIfInvalidInput(selectedOption);
		    
			switch (selectedOption) {
				case ADD_QUESTION:
					createQuestion.addQuestion();
					break;

				case REMOVE_QUESTION:
					removeQuestion.deleteQuestion();
					break;

				case MODIFY_QUESTION:
					modifyQuestion.updateQuestion();
					break;

				case VIEW_SPECIFIC_QUESTION:
					viewQuestion.viewQuestion();
					break;

				case VIEW_ALL_QUESTIONS:
					viewAll.viewAllQuestions();
					break;

				case BACK:
					break;
			}		
	}

	private UserOption getSelectedOption(String input, UserOption selectedOption) {
		for (UserOption option : UserOption.values()) {
		    if (option.getOption().equals(input)) {
		        selectedOption = option;
		    }
		}
		return selectedOption;
	}

	private void throwExceptionIfInvalidInput(UserOption selectedOption) {
		if (selectedOption == null) {
		    throw new IllegalArgumentException("Enter Valid Number");
		}
	}
}