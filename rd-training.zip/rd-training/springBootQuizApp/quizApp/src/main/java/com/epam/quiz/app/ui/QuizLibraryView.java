package com.epam.quiz.app.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.service.QuizService;

@Component
public class QuizLibraryView {
	
	@Autowired
	CreateQuizView create;
	
	@Autowired
	UpdateQuizView update;
	
	@Autowired
	DeleteQuizView delete;
	
	@Autowired
	DisplayQuizView display;
	
	private static final Logger LOGGER = LogManager.getLogger(QuizLibraryView.class);
	QuizService quizLibrary = new QuizService();
	Scanner inputScanner = new Scanner(System.in);

    enum QuizOptions {	
    	
	    CREATE("1"),
	    UPDATE("2"),
	    DELETE("3"),
	    DISPLAY("4"),
		EXIT("5");

	    private final String option;
	    
	    QuizOptions(String option) {
	        this.option = option;
	    }

	    public String getOption() {
	        return option;
	    }
	}

	public void performQuizOperations() {
		
		LOGGER.info("-----------------------\n");
		LOGGER.info("TYPE: \n '1' to create a quiz \n '2' to modify a quiz \n '3' to delete a quiz \n '4' to view all quizes \n '5' to Go Back\n");

	    String input = inputScanner.nextLine();
	    QuizOptions selectedOption = null;

	    selectedOption = getSelectedOption(input, selectedOption);
	    throwExceptionIfInvalidInput(selectedOption);

	    switch (selectedOption) {
	        case CREATE:
	            create.createQuiz();
	            break;
	        case UPDATE:
	            update.updateQuiz();
	            break;
	        case DELETE:
	            delete.deleteQuiz();
	            break;
	        case DISPLAY:
	            display.viewAllQuiz();
	            break;
	        case EXIT:
	        	break;
	    }
	}

	private QuizOptions getSelectedOption(String input, QuizOptions selectedOption) {
		for (QuizOptions option : QuizOptions.values()) {
	        if (option.getOption().equals(input)) {
	            selectedOption = option;
	        }
	    }
		return selectedOption;
	}

	private void throwExceptionIfInvalidInput(QuizOptions selectedOption) {
		if (selectedOption == null) {
	        throw new IllegalArgumentException("Enter Valid Number");
	    }
	}
}