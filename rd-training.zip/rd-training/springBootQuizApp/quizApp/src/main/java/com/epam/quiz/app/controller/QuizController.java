package com.epam.quiz.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@Controller
public class QuizController {

	@Autowired
	QuizService quizService;
	
	@Autowired
	QuestionService questionService;
	
	@GetMapping("displayQuiz")
	public ModelAndView getQuiz() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("quiz", quizService.viewAllQuiz());
		return mv;
	}
	
	@GetMapping(value = "deleteQuiz")
	public ModelAndView deleteQuiz(String title) {
		ModelAndView mv = new ModelAndView();
		quizService.removeQuiz(title);
		mv.setViewName("quizSuccess");
		return mv;
	}
	
	@PostMapping("createQuiz")
	public ModelAndView createQuiz(QuizDto quizDto) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addQuestions");
		modelAndView.addObject("quiz", quizService.addQuiz(quizDto));
		return modelAndView;
	}
	
	@PostMapping("addQuestion")
	public String addQuestionToQuiz(String quizTitle, String questionTitle, String marks) {
		Quiz quiz = quizService.getQuizByTitle(quizTitle);
		quizService.addMarksToQuizQuestion(questionTitle, Integer.parseInt(marks), quiz);
		quizService.modifyQuiz(questionTitle, quiz);
		return "addQuestions";
	}
	@RequestMapping("attemptQuiz")
	public ModelAndView attemptQuiz(String title) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("attemptQuiz");
		modelAndView.addObject("quiz", quizService.getQuizByTitle(title));

		return modelAndView;
	}

	@RequestMapping("getResult")
	public ModelAndView getResult(String quizTitle, String userInput) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("displayScore");
		String userInputs[] = userInput.trim().split("\\r?\\n");
		int inputs[] = new int[userInputs.length];
		for(int i = 0; i<inputs.length; i++) {
			inputs[i] = Integer.parseInt(userInputs[i]);
		}
		Quiz quiz = quizService.getQuizByTitle(quizTitle);
		int totalMarks = quiz.getTotalMarks();
		int scoredMarks = 0;
		for (int i = 0; i < quiz.getQuestionList().size(); i++) {
			if(i == inputs.length) break;
			Question question = quiz.getQuestionList().get(i);
			if (inputs[i]==question.getAnswer())
				scoredMarks += question.getMarks();
		}
		modelAndView.addObject("scoredMarks", scoredMarks);
		modelAndView.addObject("totalMarks", totalMarks);
		
		return modelAndView;
	}
	@PostMapping("modifyAddQuestion")
	public ModelAndView addQuestion(String quizTitle, String questionTitle, String marks) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("quizTitle", quizTitle);
		modelAndView.setViewName("modifyQuiz");
		Quiz quiz = quizService.getQuizByTitle(quizTitle);
		Question question = questionService.viewQuestion(questionTitle);
		question.setMarks(Integer.parseInt(marks));
		QuestionDto questionDto = new QuestionDto();
		questionDto.setAnswer(question.getAnswer());
		questionDto.setDificulty(question.getDificulty());
		questionDto.setOptions(question.getOptions());
		questionDto.setTitle(question.getTitle());
		questionDto.setTopics(question.getTopics());
		questionDto.setMarks(question.getMarks());
		questionService.modifyQuestion(questionTitle, questionDto);
		List<Question> list = quiz.getQuestionList();
		list.add(question);
		quiz.setTotalMarks(quiz.getTotalMarks() + Integer.parseInt(marks));
		quiz.setQuestionList(list);
		quizService.modifyQuiz(quizTitle, quiz);

		return modelAndView;
	}
	
	
}
