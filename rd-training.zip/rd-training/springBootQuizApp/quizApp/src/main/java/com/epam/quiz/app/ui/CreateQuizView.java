package com.epam.quiz.app.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.service.QuizService;

@Component
public class CreateQuizView {

	@Autowired
	QuizService quizService;
	
	@Autowired
	Quiz quiz;
	
	private static final Logger LOGGER = LogManager.getLogger(CreateQuizView.class);
    Scanner scanner = new Scanner(System.in);
    private static final String ONE = "1";

	public void createQuiz() {
		LOGGER.info("--------------\n");
		String title = getTitleFromUser();
		List<Question> questionsList = new ArrayList<>();
		quiz.setTitle(title);
		quiz.setQuestionList(questionsList);
		String input;
		do {
			String questionTitle = getQuestionTitleFromUser();
			int questionMarks = getMarksFromUser();
			quizService.addMarksToQuizQuestion(questionTitle, questionMarks, quiz);
			LOGGER.info("\ninput '1' to add more question or any other key to exit: \n");
			input = scanner.nextLine();
		}
		while(input.equals(ONE));
		//quizService.addQuiz(quiz);
		LOGGER.info("----------Quiz added :)------------- \n");	
	}

	private int getMarksFromUser() {
		LOGGER.info("Enter marks: ");
		return Integer.parseInt(scanner.nextLine());
	}

	private String getQuestionTitleFromUser() {
		LOGGER.info("Enter question title :");
		return scanner.nextLine();
	}

	private String getTitleFromUser() {
		LOGGER.info("\nEnter title: ");
		return scanner.nextLine();
	}
}