package com.epam.quiz.app.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.quiz.app.dao.QuestionOperations;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;

@Service
public class QuestionService {

	@Autowired
	QuestionOperations questionUtility;

	Question question = new Question();

	public Question createQuestion(QuestionDto questionDto) {
		question.setTitle(questionDto.getTitle());
		question.setOptions(questionDto.getOptions());
		question.setDificulty(questionDto.getDificulty());
		question.setTopics(questionDto.getTopics());
		question.setAnswer(questionDto.getAnswer());
		return questionUtility.createQuestion(question);
	}

	public Question removeQuestion(String title) {
		return questionUtility.removeQuestion(title);
	}

	public Question modifyQuestion(String title, QuestionDto questionDto) {
		question.setTitle(questionDto.getTitle());
		question.setOptions(questionDto.getOptions());
		question.setDificulty(questionDto.getDificulty());
		question.setTopics(questionDto.getTopics());
		question.setAnswer(questionDto.getAnswer());
		return questionUtility.modifyQuestion(title, question);
	}

	public Question viewQuestion(String title) {
		return questionUtility.viewQuestion(title);
	}

	public Map<String, Question> viewAllQuestions() {
		return questionUtility.viewAllQuestions();
	}
}