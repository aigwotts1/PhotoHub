package com.epam.quiz.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.service.QuestionService;

@Controller
public class QuestionController {
	
	private static final String SUCCESS = "success";
	private static final String MESSAGE = "message";
	private static final String QUESTION = "question";

	@Autowired
	QuestionService questionRepository;

	@GetMapping("displayQuestions")
	public ModelAndView getAllQuestions() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("displayQuestions");
		modelAndView.addObject("questions", questionRepository.viewAllQuestions());
		return modelAndView;
	}

	@RequestMapping("createQuestion")
	public ModelAndView createQuestion(QuestionDto questionDto) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName(SUCCESS);
		modelAndView.addObject(QUESTION, questionRepository.createQuestion(questionDto));
		modelAndView.addObject(MESSAGE, "Question Created :)");
		return modelAndView;
	}

	@RequestMapping("deleteQuestion")
	public ModelAndView deleteQuestion(String title) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName(SUCCESS);
		modelAndView.addObject(QUESTION, questionRepository.removeQuestion(title));
		modelAndView.addObject(MESSAGE, "question deleted");
		return modelAndView;
	}

	@RequestMapping("modifyQuestion")
	public ModelAndView modifyQuestion(String title, QuestionDto questionDto) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName(SUCCESS);
		modelAndView.addObject(QUESTION, questionRepository.modifyQuestion(title, questionDto));
		modelAndView.addObject(MESSAGE, "question modified");
		return modelAndView;
	}
}