package com.epam.quiz.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.model.User;
import com.epam.quiz.app.service.UserService;

@Controller
public class AuthenticationController {
	@Autowired
	UserService userService;

	@RequestMapping("register")
	public ModelAndView register(String username, String password) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("userPage");
		modelAndView.addObject("user", userService.addUser(username, password,false));
		return modelAndView;
	}

	@RequestMapping("login")
	public ModelAndView login(String username, String password) {
		ModelAndView modelAndView = new ModelAndView();
		User user = userService.getUser(username,password);
		if (user.isAdmin()) {
		modelAndView.setViewName("adminPage");
		} else {
		modelAndView.setViewName("userPage");
		}
	
		modelAndView.addObject(user);
		return modelAndView;
	}

}
