package com.epam.quiz.app.dao;

import java.util.Map;

import com.epam.quiz.app.model.Question;

public interface QuestionOperations {

	Question createQuestion(Question question);
	Question removeQuestion(String title);
	Question modifyQuestion(String title, Question question);
	Question viewQuestion(String title);
	Map<String, Question> viewAllQuestions();
}