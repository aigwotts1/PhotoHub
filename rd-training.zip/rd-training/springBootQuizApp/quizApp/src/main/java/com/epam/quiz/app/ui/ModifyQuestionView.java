package com.epam.quiz.app.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.epam.quiz.app.dao.QuestionOperations;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.service.QuestionService;

@Component
public class ModifyQuestionView {
	
	@Autowired
	QuestionService questionService;
	
	@Autowired
	QuestionOperations questionOperations;
	
	private static final Logger LOGGER = LogManager.getLogger(ModifyQuestionView.class);
	Scanner inputScanner = new Scanner(System.in);
	private static final String FOUR = "4";
	private static final String TWO = "2";

	public void updateQuestion() {
		
		LOGGER.info("--------------------------------------\n");
		
		String oldTitle = getTitleToBeModifiedFromUser();
		Question question = questionOperations.viewQuestion(oldTitle);
		String numberOfOptions = getNumberOfOptions();
		List<String> questionOptions = addOptions(numberOfOptions);
		String dificulty = getDiifficultyFromUser();
		String topics = getTopicTagsFromUser();
		int answerNumber = getAnswerNumber();
		
		question.setTitle(oldTitle);
     	question.setOptions(questionOptions);
	    question.setDificulty(dificulty);
		question.setTopics(topics);
		question.setAnswer(answerNumber);
		
		//questionService.modifyQuestion(oldTitle, question);
		LOGGER.info("-------Question Modified :)--------------\n");
	}

	private int getAnswerNumber() {
		LOGGER.info("Select Answer Number :");
		return inputScanner.nextInt();
	}

	private String getTopicTagsFromUser() {
		LOGGER.info("Enter Topics Tags : ");
		return inputScanner.nextLine();
	}

	private String getDiifficultyFromUser() {
		LOGGER.info("Enter  Difiiculty i.e. Easy,Medium,etc : ");
	    return inputScanner.nextLine();
	}

	private String getNumberOfOptions() {
		LOGGER.info("Enter Number Of  Options i.e. 2/4 :");
		return inputScanner.nextLine();
	}

	private String getTitleToBeModifiedFromUser() {
		LOGGER.info("Enter Title of Question To Be Modified :");
		return inputScanner.nextLine();
	}
	
	private List<String> addOptions(String option) {
		List<String> questionOptions;
		String optionOne;
		String optionTwo;
		String optionThree;
		String optionFour;
		
		switch (option) {
		case FOUR:
			optionOne = getOptionOneFromUser();
			optionTwo = getOptionTwoFromUser();
			optionThree = getOptionThreeFromUser();
			optionFour = getOptionFourFromUser();
			questionOptions = Arrays.asList(optionOne,optionTwo,optionThree,optionFour);
			break;
		case TWO:
			optionOne = getOptionOneFromUser();
			optionTwo = getOptionTwoFromUser();
			questionOptions = Arrays.asList(optionOne,optionTwo);
			break;
		default:
			throw new IllegalArgumentException("Enter Valid Number");
		}
		return questionOptions;
	}

	private String getOptionFourFromUser() {
		String optionFour;
		LOGGER.info("Enter option 4 :");
		optionFour = inputScanner.nextLine();
		return optionFour;
	}

	private String getOptionThreeFromUser() {
		String optionThree;
		LOGGER.info("Enter option 3 :");
		optionThree = inputScanner.nextLine();
		return optionThree;
	}

	private String getOptionTwoFromUser() {
		String optionTwo;
		LOGGER.info("Enter option 2 :");
		optionTwo = inputScanner.nextLine();
		return optionTwo;
	}

	private String getOptionOneFromUser() {
		String optionOne;
		LOGGER.info("Enter option 1 :");
		optionOne = inputScanner.nextLine();
		return optionOne;
	}
}