package com.epam.quiz.app.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.epam.quiz.app.dao.QuestionOperations;
import com.epam.quiz.app.dao.QuizOperations;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;

@Repository
@Primary
public class JpaQuizImpl implements QuizOperations {

	@Autowired
	QuestionOperations questionUtility;

	@Autowired
	EntityManager entityManager;
	
	@Autowired
	Quiz quiz;
	
	private static final String INVALID_TITLE = "invalid title";
	private static final String NO_QUIZ_FOUND = "No Quiz Found";

	public Quiz addMarksToQuizQuestion(String title, int questionMarks, Quiz quiz) {
		Question question = questionUtility.viewQuestion(title);
		question.setMarks(questionMarks);
		questionUtility.modifyQuestion(title, question);
		quiz.getQuestionList().add(question);
		
		return quiz;
	}

	@Override
	public Quiz addQuiz(Quiz quiz) {
		throwExceptionIfBlankInput(quiz);
		entityManager.getTransaction().begin();
		try {
			for (Question question : quiz.getQuestionList()) {
				question.getQuizList().add(quiz);
			}
			quiz.getTotalMarks();
			entityManager.persist(quiz);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
		}
		return quiz;
	}

	@Override
	public Quiz removeQuiz(String title) {

		throwExceptionIfInvalidTitle(title);
		try {
			quiz = entityManager.createQuery("FROM Quiz q WHERE q.title = '" + title + "'",Quiz.class).getSingleResult();
		}
		catch(NoResultException e) {
			throw new NullPointerException(NO_QUIZ_FOUND);
		}
		entityManager.getTransaction().begin();
		try {
			for (Question question : quiz.getQuestionList()) {
				question.getQuizList().remove(quiz);
			}
			entityManager.remove(quiz);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
		}
		return quiz;
	}

	@Override
	public Quiz modifyQuiz(String title, Quiz quiz) {

		throwExceptionIfInvalidTitle(title);
		Quiz oldquiz;
		try {
			oldquiz = entityManager.createQuery("FROM Quiz q WHERE q.title='" + title + "'",Quiz.class).getSingleResult();
		}
		catch(NoResultException e) {
			throw new NullPointerException(NO_QUIZ_FOUND);
		}
		Quiz modifiedQuiz = oldquiz;
		modifiedQuiz.setQuestionList(quiz.getQuestionList());
		entityManager.getTransaction().begin();
		try {
			modifiedQuiz.getTotalMarks();
			modifiedQuiz.setTitle(quiz.getTitle());
			modifiedQuiz.getQuestionList();
			entityManager.merge(modifiedQuiz);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
		}
		return modifiedQuiz;
	}

	@Override
	public Map<String, Quiz> viewAllQuiz() {
		List<Quiz> quizList = entityManager.createQuery("FROM Quiz",Quiz.class).getResultList();
		return quizList.stream().collect(Collectors.toMap(Quiz::getTitle, x -> x));
	}
	@Override
	public Quiz getQuizByTitle(String title) {
		throwExceptionIfInvalidTitle(title);
		try{
			quiz = entityManager.createQuery("FROM Quiz q WHERE q.title = '" + title + "'",Quiz.class).getSingleResult();
		}
		catch(NoResultException e) {
			throw new NullPointerException(NO_QUIZ_FOUND);
		}
		
		return quiz;
	}
	
	private void throwExceptionIfInvalidTitle(String title) {
		if (title.isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
	}
	
	private void throwExceptionIfBlankInput(Quiz quiz) {
		if (quiz.getTitle().isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
	}
}