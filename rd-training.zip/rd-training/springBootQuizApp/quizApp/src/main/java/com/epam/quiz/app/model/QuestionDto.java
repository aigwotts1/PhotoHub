package com.epam.quiz.app.model;

import java.util.List;

public class QuestionDto {
	
	private String title;
	private List<String> options;
	private String dificulty;
	@Override
	public String toString() {
		return "QuestionDto [title=" + title + ", options=" + options + ", dificulty=" + dificulty + ", topics="
				+ topics + ", answer=" + answer + ", marks=" + marks + "]";
	}
	private String topics;
	private int answer;
	private int marks;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<String> getOptions() {
		return options;
	}
	public void setOptions(List<String> options) {
		this.options = options;
	}
	public String getDificulty() {
		return dificulty;
	}
	public void setDificulty(String difficulty) {
		this.dificulty = difficulty;
	}
	public String getTopics() {
		return topics;
	}
	public void setTopics(String topics) {
		this.topics = topics;
	}
	public int getAnswer() {
		return answer;
	}
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
}