package com.epam.quiz.controller.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.controller.AuthenticationController;
import com.epam.quiz.app.model.User;
import com.epam.quiz.app.service.UserService;

@ExtendWith(MockitoExtension.class)
class AuthenticationTest {
	
	private MockMvc mockMvc;
	
    @Mock
    private UserService userService;

    @InjectMocks
    private AuthenticationController controller;

    @Test
    void testRegister() throws Exception {
        User dummyUser = new User("testuser", "testpassword", false);
        when(userService.addUser(anyString(), anyString(), anyBoolean())).thenReturn(dummyUser);

        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/register")
                .param("username", "testuser")
                .param("password", "testpassword"))
                .andReturn();

        ModelAndView modelAndView = mvcResult.getModelAndView();
        assertEquals("userPage", modelAndView.getViewName());
        assertEquals(dummyUser, modelAndView.getModel().get("user"));

        verify(userService).addUser("testuser", "testpassword", false);
    }

    @Test
    void testLoginForAdmin() throws Exception {
        User dummyAdminUser = new User("adminuser", "adminpassword", true);
        when(userService.getUser(anyString(), anyString())).thenReturn(dummyAdminUser);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/login")
                .param("username", "adminuser")
                .param("password", "adminpassword"))
                .andReturn();
        ModelAndView modelAndView = mvcResult.getModelAndView();
        assertEquals("adminPage", modelAndView.getViewName());
        assertEquals(dummyAdminUser, modelAndView.getModel().get("user"));
        verify(userService).getUser("adminuser", "adminpassword");
    }

    @Test
    void testLoginForUser() throws Exception {
        User dummyUser = new User("testuser", "testpassword", false);
        when(userService.getUser(anyString(), anyString())).thenReturn(dummyUser);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/login")
                .param("username", "testuser")
                .param("password", "testpassword"))
                .andReturn();
        ModelAndView modelAndView = mvcResult.getModelAndView();
        assertEquals("userPage", modelAndView.getViewName());
        assertEquals(dummyUser, modelAndView.getModel().get("user"));
        verify(userService).getUser("testuser", "testpassword");
    }
}