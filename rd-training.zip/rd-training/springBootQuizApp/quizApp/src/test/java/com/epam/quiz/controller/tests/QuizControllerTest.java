package com.epam.quiz.controller.tests;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.controller.QuizController;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuestionService;
import com.epam.quiz.app.service.QuizService;

@ExtendWith(MockitoExtension.class)
class QuizControllerTest {

    @Mock
    private QuizService quizService;
    
    @Mock
    private QuestionService questionService;
    
    @InjectMocks
    private QuizController quizController;
    
    MockMvc mockMvc;
    
    @Test
    void testCreateQuiz() {
        // Prepare test data
        QuizDto quizDto = new QuizDto();
        quizDto.setTitle("Quiz1");

        // Setup mock response for addQuiz() method
        Quiz quiz = new Quiz();
        quiz.setTitle("Quiz1");
        when(quizService.addQuiz(quizDto)).thenReturn(quiz);

        // Call the method being tested
        ModelAndView mav = quizController.createQuiz(quizDto);

        // Assert the results
        assertEquals("addQuestions", mav.getViewName()); // Verify the view name
        assertEquals(1, mav.getModel().size()); // Only one key-value pair in the model
        verify(quizService).addQuiz(quizDto); // Verify that addQuiz() was called with the expected parameter
        assertEquals(quiz, mav.getModel().get("quiz")); // Verify the Quiz object in the model
    }
    @Test
    void testAddQuestionToQuiz() {
        // Prepare test data
        String quizTitle = "Quiz1";
        String questionTitle = "Question1";
        String marks = "5";

        // Setup mock response for getQuizByTitle() method
        Quiz quiz = new Quiz();
        quiz.setTitle("Quiz1");
        when(quizService.getQuizByTitle(quizTitle)).thenReturn(quiz);

        // Call the method being tested
        String viewName = quizController.addQuestionToQuiz(quizTitle, questionTitle, marks);

        // Assert the results
        assertEquals("addQuestions", viewName); // Verify the returned view name
        verify(quizService).getQuizByTitle(quizTitle); // Verify that getQuizByTitle() was called
        verify(quizService).addMarksToQuizQuestion(questionTitle, Integer.parseInt(marks), quiz); // Verify that addMarksToQuizQuestion() was called with the expected parameters
        verify(quizService).modifyQuiz(questionTitle, quiz); // Verify that modifyQuiz() was called with the expected parameters
    }
    @Test
    void testAttemptQuiz() {
        // Prepare test data
        String quizTitle = "Quiz1";

        // Setup mock response for getQuizByTitle() method
        Quiz quiz = new Quiz();
        quiz.setTitle("Quiz1");
        when(quizService.getQuizByTitle(quizTitle)).thenReturn(quiz);

        // Call the method being tested
        ModelAndView modelAndView = quizController.attemptQuiz(quizTitle);

        // Assert the results
        assertEquals("attemptQuiz", modelAndView.getViewName()); // Verify the returned view name
        assertEquals(quiz, modelAndView.getModel().get("quiz")); // Verify the returned quiz object
        verify(quizService).getQuizByTitle(quizTitle); // Verify that getQuizByTitle() was called
    }
    @Test
    void testGetResult() {
        // Mock quiz and question data
        Quiz quiz = new Quiz();
        quiz.setTitle("Test Quiz");
        quiz.setTotalMarks(10);
        Question question1 = new Question();
        question1.setTitle("Question 1");
        question1.setMarks(5);
        question1.setAnswer(2);
        Question question2 = new Question();
        question2.setTitle("Question 2");
        question2.setMarks(5);
        question2.setAnswer(1);
        quiz.setQuestionList(Arrays.asList(question1, question2));

        // Mock quizService to return the above quiz when getQuizByTitle is called
        when(quizService.getQuizByTitle("Test Quiz")).thenReturn(quiz);

        // Call the getResult method with mock input values
        String userInput = "2\n1\n";
        ModelAndView result = quizController.getResult("Test Quiz", userInput);

        // Verify that the ModelAndView object contains the expected scoredMarks and totalMarks values
        assertEquals(10, result.getModel().get("scoredMarks"));
        assertEquals(10, result.getModel().get("totalMarks"));
    }
    @Test
    public void testDeleteQuiz() {
        Quiz quiz = new Quiz();

        String title = "Test Quiz";
        ModelAndView expectedModelAndView = new ModelAndView("quizSuccess");

        when(quizService.removeQuiz(title)).thenReturn(quiz);

        ModelAndView actualModelAndView = quizController.deleteQuiz(title);

        verify(quizService).removeQuiz(title);
        assertSame(expectedModelAndView.getViewName(), actualModelAndView.getViewName());
    }
}
