package com.epam.quiz.controller.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.servlet.ModelAndView;

import com.epam.quiz.app.controller.QuestionController;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.service.QuestionService;

@ExtendWith(MockitoExtension.class)
class QuestionControllerTest {

    private static final String SUCCESS = "success";
    private static final String MESSAGE = "message";
    private static final String QUESTION = "question";
    
    @Mock
    private QuestionService questionService;
    
    @InjectMocks
    private QuestionController questionController;
    
    
    @Test
    void testCreateQuestion() {
        // Arrange
        QuestionDto questionDto = new QuestionDto();
        questionDto.setTitle("Test Question");
        Question createdQuestion = new Question();
        createdQuestion.setTitle("Test Question");
        when(questionService.createQuestion(any(QuestionDto.class))).thenReturn(createdQuestion);

        // Act
        ModelAndView modelAndView = questionController.createQuestion(questionDto);

        // Assert
        assertEquals("success", modelAndView.getViewName());
        assertEquals(createdQuestion, modelAndView.getModel().get("question"));
        assertEquals("Question Created :)", modelAndView.getModel().get("message"));
    }

    @Test
    void testDeleteQuestion() {
        // Arrange
        String questionTitle = "Test Question";
        Question removedQuestion = new Question();
        removedQuestion.setTitle("Test Question");
        when(questionService.removeQuestion(anyString())).thenReturn(removedQuestion);

        // Act
        ModelAndView modelAndView = questionController.deleteQuestion(questionTitle);

        // Assert
        assertEquals("success", modelAndView.getViewName());
        assertEquals(removedQuestion, modelAndView.getModel().get("question"));
        assertEquals("question deleted", modelAndView.getModel().get("message"));
    }

    
    @Test
    void testModifyQuestion() {

        String title = "Question Title";
        QuestionDto questionDto = new QuestionDto();
        questionDto.setAnswer(1);
        questionDto.setMarks(10);
        
        Question question = new Question();
        question.setTitle(title);
        question.setAnswer(questionDto.getAnswer());
        question.setMarks(questionDto.getMarks());
        
        when(questionService.modifyQuestion(title, questionDto)).thenReturn(question);

        ModelAndView modelAndView = questionController.modifyQuestion(title, questionDto);

        verify(questionService, times(1)).modifyQuestion(title, questionDto);
        assertEquals(SUCCESS, modelAndView.getViewName());
        assertEquals(question, modelAndView.getModel().get(QUESTION));
        assertEquals("question modified", modelAndView.getModel().get(MESSAGE));
    }
    
    @Test
    void testGetAllQuestions() throws Exception {
    	Map<String, Question> questionMap = Collections.emptyMap();
        Mockito.when(questionService.viewAllQuestions()).thenReturn(questionMap);

        ModelAndView modelAndView = questionController.getAllQuestions();

        assertEquals("displayQuestions", modelAndView.getViewName());
        assertEquals(questionMap, modelAndView.getModel().get("questions"));
    }
   
}
