package com.epam.quiz.dao.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.quiz.app.dao.impl.JpaUserImpl;
import com.epam.quiz.app.model.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;
import jakarta.persistence.TypedQuery;

@ExtendWith(MockitoExtension.class)
class JpaUserUtilityTest {
 
    @Mock
    private EntityManager entityManager;
    
    @Mock
    private EntityTransaction transaction;
    
    @Mock
    private TypedQuery<User> query;
    
    @Mock
    User user;
    
    @InjectMocks
    private JpaUserImpl userJPAUtility;
    
    @Test
    void happyPath_TestAddUser() {
        String userName = "testuser";
        String password = "testpassword";
        boolean isAdmin = false;
        when(entityManager.getTransaction()).thenReturn(transaction);

        userJPAUtility.addUser(userName, password, isAdmin);

        verify(entityManager).persist(user);
        verify(transaction).commit();
        verify(transaction, never()).rollback();
    }
    
    @Test
    void sadPathtestAddUserRollback() {
        String userName = "testUser";
        String password = "testPassword";
        boolean isAdmin = false;
        
        when(entityManager.getTransaction()).thenReturn(transaction);
        doThrow(PersistenceException.class).when(entityManager).persist(user);
        
        userJPAUtility.addUser(userName, password, isAdmin);
        
        verify(user).setUserName(userName);
        verify(user).setPassword(password);
        verify(user).setIsAdmin(isAdmin);
        verify(entityManager,times(2)).getTransaction();
        verify(transaction).begin();
        verify(entityManager).persist(user);
        verify(transaction, never()).commit();
        verify(transaction).rollback();
    }
    @Test
	void sadPath_TestAddUserWithInvalidUsername() {
		assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.addUser("", "testpassword", true); });
	}
	
	@Test
	void sadPath_testAddUserWithInvalidPassword() {
		assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.addUser("testuser", "", true); });
	}
    
    @Test
    void sadPath_TestAddUserWithEmptyUsernameWithFalseAdmin() {

        String username = "";
        String password = "testpassword";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> userJPAUtility.addUser(username, password,false));
        assertEquals("username can't be empty", exception.getMessage());
        verify(entityManager, never()).persist(any());
        verify(transaction, never()).commit();
    }

    @Test
    void sadPath_TestAddUserWithEmptyPasswordWithFalseAdmin() {

        String username = "testuser";
        String password = "";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> userJPAUtility.addUser(username, password,false));
        assertEquals("password can't be empty", exception.getMessage());
        verify(entityManager, never()).persist(any());
        verify(transaction, never()).commit();
    }   
    

    @Test
    void sadPath_TestGetUserWithValidUsernameAndPassword() {
        String userName = "testUser";
        String password = "testPassword";
        User user = new User(userName, password);

        when(query.getSingleResult()).thenReturn(user);
        when(entityManager.createQuery("FROM User u WHERE u.user_name='" + userName + "'",User.class)).thenReturn(query);

        assertEquals(user, userJPAUtility.getUser(userName, password));
    }
   
    @Test
    void sadPath_TestGetUserWithBlankUsername() {
        String userName = "";
        String password = "testPassword";

        assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.getUser(userName, password); });
        verify(entityManager, never()).createQuery(anyString());
    }
    @Test
    void sadPath_TestGetUserWithBlankPassword() {
        String userName = "testUser";
        String password = "";

        assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.getUser(userName, password); });
        verify(entityManager, never()).createQuery(anyString());
    }
    @Test
    void testGetUserWithNoResult() {

        String userName = "nonexistentuser";
        String password = "password";
        when(entityManager.createQuery("FROM User u WHERE u.user_name='" + userName + "'", User.class)).thenReturn(query);
        when(query.getSingleResult()).thenThrow(NoResultException.class);
        
        assertThrows(NullPointerException.class, () -> userJPAUtility.getUser(userName, password));
    }
}