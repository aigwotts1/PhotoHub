package com.epam.quiz.dao.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.quiz.app.dao.impl.JpaQuestionImpl;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;
import jakarta.persistence.TypedQuery;

@ExtendWith(MockitoExtension.class)
class JpaQuestionUtilityTest {

	@Mock
	EntityManagerFactory entityManagerFactory;
	
    @Mock
    private EntityManager entityManager;

    @Mock
    private EntityTransaction transaction;
    
    @Mock
	private TypedQuery<Question> query;

    @InjectMocks
    private JpaQuestionImpl questionJPAUtility;
    
    @Mock
    Question newQues;

    @Test
    void happyPath_CreateValidQuestionTest() {
        Question question = new Question();
        question.setTitle("valid title");

        when(entityManager.getTransaction()).thenReturn(transaction);

        Question result = questionJPAUtility.createQuestion(question);

        assertEquals(question, result);
        verify(transaction).begin();
        verify(entityManager).persist(question);
        verify(transaction).commit();
    }

    @Test
    void sadPath_CreateQuestion_withInvalidTitle_shouldThrowIllegalArgumentException() {
        Question question = new Question();
        question.setTitle("valid title");
        when(entityManager.getTransaction()).thenReturn(transaction);
        doThrow(PersistenceException.class).when(entityManager).persist(question);
        questionJPAUtility.createQuestion(question);
        verify(entityManager,times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
    }

    @Test
    void sadPath_CreateQuestionWithEmptyTitle() {
    	Question question = new Question();
    	question.setTitle("");
    	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,() -> questionJPAUtility.createQuestion(question));
    	assertEquals("invalid title", exception.getMessage());
    }

    
	@Test
	void happyPath_TestRemoveQuestion() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);

		List<Question> questionList = new ArrayList<>();
		questionList.add(testQuestion);
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "testQuestion" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(testQuestion);
		when(entityManager.getTransaction()).thenReturn(transaction);
		Question result = questionJPAUtility.removeQuestion("testQuestion");
		assertEquals(testQuestion, result);
		verify(query, times(1)).getSingleResult();
	}
	@Test
	void sadPath_TestRemoveQuestionFail() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		List<Question> questionList = new ArrayList<>();
		questionList.add(testQuestion);
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "testQuestion" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(testQuestion);
		when(entityManager.getTransaction()).thenReturn(transaction);      
		doThrow(PersistenceException.class).when(entityManager).remove(testQuestion);
		questionJPAUtility.removeQuestion("testQuestion");
        verify(entityManager, times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
	}
	
	@Test
	void sadPath_testRemoveQuestionFailIfQuizListPresent() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		List<Question> questionList = new ArrayList<>();
		questionList.add(testQuestion);
		Quiz quiz = new Quiz();
		testQuestion.setQuizList(List.of(quiz));
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "testQuestion" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(testQuestion);
		Exception exception = assertThrows(IllegalArgumentException.class, () -> questionJPAUtility.removeQuestion("testQuestion"));
		assertEquals("Question is mapped to a quiz can't be deleted you can modify it",exception.getMessage());
		
	}
	
	@Test
	void sadPath_RemoveQuestionWithEmptyTitleTest() {
		Question question = new Question();
    	question.setTitle("");
    	assertThrows(RuntimeException.class,() -> questionJPAUtility.removeQuestion(""));
	}
	
	@Test
	void sadPath_RemoveQuestionWithQuestionNotFoundTest() {

		when(query.getSingleResult()).thenThrow(NoResultException.class);
        when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "testQuestion" + "'",Question.class)).thenReturn(query);
        assertThrows(NullPointerException.class, () ->  questionJPAUtility.removeQuestion("testQuestion") );
	}
	
    @Test
	void happyPath_TestModifyQuestion() {
		Question question = new Question();
		question.setTitle("title");
        when(entityManager.getTransaction()).thenReturn(transaction);
        question.setTitle("title");
		
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "title" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(question);
		Question result = questionJPAUtility.modifyQuestion("title", question);

		verify(entityManager,times(2)).getTransaction();
		verify(transaction).begin();
		verify(entityManager).merge(question);
		verify(transaction).commit();
		assertEquals(question, result);
	}
    @Test
	void sadPath_TestModifyQuestion_WithInvalidTitle() {

		Question question = new Question();
		question.setTitle("title");

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {questionJPAUtility.modifyQuestion("", question);});
		assertEquals("invalid title", exception.getMessage());
	}
    @Test
	void sadPath_TestModifyQuestionNotPresent() {
    	Question question = new Question();
		question.setTitle("title");
        when(entityManager.getTransaction()).thenReturn(transaction);
        question.setTitle("title");
		
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "title" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(question);
		doThrow(PersistenceException.class).when(entityManager).merge(any(Question.class));
        questionJPAUtility.modifyQuestion("title", question);
        verify(entityManager, times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
	}
    @Test
	void happyPath_TestViewQuestion() {

		Question question = new Question();
		question.setTitle("title");
		List<Question> questionList = new ArrayList<>();
		questionList.add(question);
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "title" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(question);

		Question result = questionJPAUtility.viewQuestion("title");
		
		assertEquals(question, result);
	}
    @Test
	void sadPath_TestViewQuestion_WithInvalidTitle() {

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {questionJPAUtility.viewQuestion("");});
		assertEquals("invalid title", exception.getMessage());
	}
	@Test
	void sadPath_TestViewQuestion_NotFound() {
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "title" + "'",Question.class)).thenReturn(query);
		when(query.getSingleResult()).thenThrow(NoResultException.class);;

		assertThrows(NullPointerException.class, () -> {questionJPAUtility.viewQuestion("title");});

	}
	@Test
	void happyPath_TestViewAllQuestion() {

		List<Question> questionList = new ArrayList<>();
		Question question1 = new Question();
		question1.setTitle("title1");
		Question question2 = new Question();
		question2.setTitle("title2");
		questionList.add(question1);
		questionList.add(question2);
		when(entityManager.createQuery("FROM Question",Question.class)).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);

		Map<String, Question> result = questionJPAUtility.viewAllQuestions();

		verify(entityManager).createQuery("FROM Question",Question.class);
		verify(query).getResultList();
		assertEquals(2, result.size());
		assertEquals(question1, result.get("title1"));
		assertEquals(question2, result.get("title2"));
	}
}