package com.epam.quiz.service.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.quiz.app.dao.QuizOperations;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.Quiz;
import com.epam.quiz.app.model.QuizDto;
import com.epam.quiz.app.service.QuizService;

@ExtendWith(MockitoExtension.class)
class QuizServiceTest {

	@InjectMocks
    private QuizService quizService;

    @Mock
    private QuizOperations quizUtility;

    QuizDto quizDto;
    Question question;
    Quiz quiz;
    List<Question> listOfQuestions;
    
    @BeforeEach
    void setup() {
    	question = new Question("JAVA IS GOOD?",Arrays.asList("Option1","Option2"),"easy","java",1);
        listOfQuestions = Arrays.asList(question);
    }
    
    @Test
	void createQuizTest() {
    	quiz = new Quiz();
    	quizDto = new QuizDto();
		when(quizUtility.addQuiz(quiz)).thenReturn(quiz);
		
		quizDto.setTitle(quiz.getTitle());
		quizDto.setQuestionList(quiz.getQuestionList());
		quizDto.setTotalMarks(quiz.getTotalMarks());
		Quiz receivedValue = quizService.addQuiz(quizDto);
		verify(quizUtility).addQuiz(quiz);
		assertEquals(quiz, receivedValue);
	}

    @Test
    void happyPath_TestRemoveQuiz() {
        String title = "Math Quiz";
        Quiz quiz = new Quiz(title, listOfQuestions);

        when(quizUtility.removeQuiz(title)).thenReturn(quiz);

        Quiz removedQuiz = quizService.removeQuiz(title);
        assertEquals(quiz, removedQuiz);

        verify(quizUtility).removeQuiz(title);
    }

    @Test
    void happyPath_TestModifyQuiz() {
        String title = "Math Quiz";
        Quiz quiz = new Quiz(title, listOfQuestions);

        when(quizUtility.modifyQuiz(title, quiz)).thenReturn(quiz);

        Quiz modifiedQuiz = quizService.modifyQuiz(title, quiz);
        assertEquals(quiz, modifiedQuiz);

        verify(quizUtility).modifyQuiz(title, quiz);
    }

    @Test
	void happyPath_TestViewAllQuiz() {
		Map<String, Quiz> expectedQuizzes = new HashMap<>();
		expectedQuizzes.put("Quiz 1", new Quiz("Quiz 1",listOfQuestions));
		expectedQuizzes.put("Quiz 2", new Quiz("Quiz 2",listOfQuestions));
		
		when(quizUtility.viewAllQuiz()).thenReturn(expectedQuizzes);
		
		Map<String, Quiz> actualQuizzes = quizService.viewAllQuiz();
		
		verify(quizUtility).viewAllQuiz();
		assertEquals(expectedQuizzes,actualQuizzes);
	}
	
	@Test
	void happyPath_TestAddMarksToQuizQuestion() {
		String title = "Quiz 1";
		int questionMarks = 10;
		Quiz quiz = new Quiz(title,listOfQuestions);
		Quiz expectedQuiz = new Quiz(title,listOfQuestions);
		expectedQuiz.setTotalMarks(questionMarks);
		
		when(quizService.addMarksToQuizQuestion(title, questionMarks, quiz)).thenReturn(expectedQuiz);
		
		Quiz actualQuiz = quizService.addMarksToQuizQuestion(title, questionMarks, quiz);
		assertEquals(expectedQuiz, actualQuiz);
	}
	@Test
    void getQuizByTitleTest() {
		quiz = new Quiz();
        when(quizUtility.getQuizByTitle(quiz.getTitle())).thenReturn(quiz);
        Quiz result = quizService.getQuizByTitle(quiz.getTitle());
        assertEquals(result,quiz);
        verify(quizUtility).getQuizByTitle(quiz.getTitle());
    }
}