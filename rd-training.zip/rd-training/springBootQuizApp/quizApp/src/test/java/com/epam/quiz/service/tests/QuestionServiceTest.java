package com.epam.quiz.service.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.quiz.app.dao.QuestionOperations;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionDto;
import com.epam.quiz.app.service.QuestionService;

@ExtendWith(MockitoExtension.class)
 class QuestionServiceTest {

	@InjectMocks
    private QuestionService questionService;

    @Mock
    private QuestionOperations questionUtility;

    String title;
    
    
    Question question;
    QuestionDto questionDto;
    
    @BeforeEach
    void setup() {
    	question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java",1);
		questionDto=new QuestionDto();
		questionDto.setAnswer(question.getAnswer());
		questionDto.setDificulty(question.getDificulty());
		questionDto.setOptions(question.getOptions());
		questionDto.setTitle(question.getTitle());
		questionDto.setTopics(question.getTopics());
        title = "Title";
    }
  
    @Test
	void happyPath_createQuestionTest() {
		when(questionUtility.createQuestion(question)).thenReturn(question);
		Question recievedValue = questionService.createQuestion(questionDto);
		verify(questionUtility).createQuestion(question);
		assertEquals(recievedValue,question);
	}

    @Test
    void happyPath_TestRemoveQuestion() {
        when(questionUtility.removeQuestion(title)).thenReturn(question);

        Question removedQuestion = questionService.removeQuestion(title);
        assertEquals(question, removedQuestion);

        verify(questionUtility).removeQuestion(title);
    }

    @Test
    void happyPath_TestModifyQuestion() {
        when(questionUtility.modifyQuestion((title), question)).thenReturn(question);

        Question modifiedQuestion = questionService.modifyQuestion(title, questionDto);
        assertEquals(question, modifiedQuestion);

        verify(questionUtility).modifyQuestion((title),(question));
    }

    @Test
    void happyPath_TestVeiwQuestion() {
        when(questionUtility.viewQuestion(title)).thenReturn(question);

        Question viewedQuestion = questionService.viewQuestion(title);
        assertEquals(question, viewedQuestion);

        verify(questionUtility).viewQuestion(title);

    }

    @Test
    void happyPath_TestVeiwAllQuestion() {
        Map<String, Question> questionMap = new HashMap<>();
        questionMap.put("Title1", new Question("Title1", null, "Content1", null, 0));
        questionMap.put("Title2", new Question("Title2", null, "Content2", null, 0));
        when(questionUtility.viewAllQuestions()).thenReturn(questionMap);

        Map<String, Question> viewedQuestionMap = questionService.viewAllQuestions();
        assertEquals(questionMap, viewedQuestionMap);

        verify(questionUtility).viewAllQuestions();
    }
}