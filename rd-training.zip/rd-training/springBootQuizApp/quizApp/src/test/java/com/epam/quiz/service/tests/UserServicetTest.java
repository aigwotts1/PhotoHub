package com.epam.quiz.service.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.quiz.app.dao.UserOperations;
import com.epam.quiz.app.model.User;
import com.epam.quiz.app.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserServicetTest {

    @Mock
    private UserOperations userUtility;

    @InjectMocks    
    private UserService userService;

    String username;
    String password;
    boolean isAdmin;
    
    @BeforeEach
    void setup() {
    	username = "john.doe";
        password = "password";
        isAdmin = true;
    }
    
    @Test
	void happyPath_TestAddUser() {
		User expectedUser = new User();
		when(userUtility.addUser("testuser", "testpassword", true)).thenReturn(expectedUser);
		
		User result = userService.addUser("testuser", "testpassword", true);
		
		verify(userUtility).addUser("testuser", "testpassword", true);
		
		assertEquals(expectedUser, result);
	}

    @Test
    void happyPath_TestGetUser() {
        
        User expectedUser = new User(username, password, false);

        when(userUtility.getUser(username, password)).thenReturn(expectedUser);

        User actualUser = userService.getUser(username, password);
        assertEquals(expectedUser, actualUser);
        verify(userUtility).getUser(username, password);
    }
}