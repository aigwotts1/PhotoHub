package com.epam.quiz.dao.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.quiz.app.dao.impl.JpaQuestionImpl;
import com.epam.quiz.app.dao.impl.JpaQuizImpl;
import com.epam.quiz.app.model.Question;
import com.epam.quiz.app.model.QuestionBuilder;
import com.epam.quiz.app.model.Quiz;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceException;
import jakarta.persistence.TypedQuery;

@ExtendWith(MockitoExtension.class)
class JpaQuizUtilityTest {

	@Mock
	private EntityManager entityManager;

	@Mock
	private JpaQuestionImpl questionUtility;

	@Mock
	private EntityTransaction entityTransaction;

	@Mock
	private TypedQuery<Quiz> query;

	@InjectMocks
	private JpaQuizImpl quizJPAUtility;

	@Test
    void happyPath_AddMarksToQuizQuestionTest() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		List<Question> list = Arrays.asList(testQuestion);
		Quiz quiz = new Quiz("java",list,10);
        
        when(questionUtility.viewQuestion("testQuestion")).thenReturn(testQuestion);

       
        quiz.setQuestionList(new ArrayList<>());

        quizJPAUtility.addMarksToQuizQuestion("testQuestion", 10, quiz);

        verify(questionUtility).modifyQuestion("testQuestion", testQuestion);

        
        assertEquals(10,testQuestion.getMarks());
    }

	@Test
	void happyPath_TestAddQuiz() {
		Quiz quiz = new Quiz();
		quiz.setTitle("Sample Quiz");
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		quiz = quizJPAUtility.addQuiz(quiz);
		verify(entityTransaction).begin();
		verify(entityManager).persist(quiz);
		verify(entityTransaction).commit();
		assertEquals("Sample Quiz", quiz.getTitle());
	}

	@Test
	void sadPath_addQuizFailTest() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);

		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		doThrow(PersistenceException.class).when(entityManager).persist(testQuiz);
		quizJPAUtility.addQuiz(testQuiz);
		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(entityTransaction).rollback();
	}

	@Test
	void sadPath_addQuizWithNoTitleTest() {
		Question question = new Question();
		Quiz quiz = new Quiz("", List.of(question));
		Exception exception = assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.addQuiz(quiz));
		assertEquals("invalid title",exception.getMessage());
	}

	@Test
	void happyPath_RemoveQuizTest() {
		String title = "Test Quiz";
		Quiz quiz = new Quiz(title, new ArrayList<>());
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(quiz);

		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		when(entityManager.createQuery("FROM Quiz q WHERE q.title = '" + title + "'",Quiz.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(quiz);

		quizJPAUtility.removeQuiz(title);

		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(query).getSingleResult();
		verify(entityManager).remove(quiz);
		verify(entityTransaction).commit();
	}

	@Test
	void sadPath_RemoveQuiz_invalidTitleTest() {
		String title = "";
		Exception exception = assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.removeQuiz(title));
		assertEquals("invalid title",exception.getMessage());
	}

	@Test
	void happyPath_TestModifyQuiz() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Question newQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		Quiz newTestQuiz = new Quiz("testQuiz", Arrays.asList(newQuestion), 10);
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(testQuiz);

		when(entityManager.createQuery("FROM Quiz q WHERE q.title='" + "testQuiz" + "'",Quiz.class)).thenReturn(query);
		when(query.getSingleResult()).thenReturn(testQuiz);
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		Quiz result = quizJPAUtility.modifyQuiz("testQuiz", newTestQuiz);
		assertEquals(testQuiz, result);
		verify(query, times(1)).getSingleResult();
	}

	@Test
	void happyPath_TestViewAllQuiz() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		Map<String, Quiz> testMap = new HashMap<>();
		testMap.put("testQuiz", testQuiz);
		List<Quiz> quizList = List.of(testQuiz);
		when(entityManager.createQuery("FROM Quiz",Quiz.class)).thenReturn(query);
		when(query.getResultList()).thenReturn(quizList);
		Map<String, Quiz> result = quizJPAUtility.viewAllQuiz();
		assertEquals(testMap, result);
		verify(query, times(1)).getResultList();
	}

	@Test
	void sadPath_ModifyQuiz_InvalidInput_ThrowsException() {
		String title = "";
		Quiz quiz = new Quiz("Valid Quiz Title",
				Arrays.asList(new QuestionBuilder().setTitle("Question 1").getQuestionBuilder(),
						new QuestionBuilder().setTitle("Question 2").getQuestionBuilder()));

		assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.modifyQuiz(title, quiz));
		verify(entityManager, never()).persist(any());
		verify(entityManager, never()).getTransaction();
	}

	@Test
	void sadPath_ModifyQuizNotFoundTest() {
		String title = "quiz";
		Quiz quiz = new Quiz("quiz", Arrays.asList(new QuestionBuilder().setTitle("Question 1").getQuestionBuilder(),
				new QuestionBuilder().setTitle("Question 2").getQuestionBuilder()));
		when(entityManager.createQuery("FROM Quiz q WHERE q.title='" + title + "'",Quiz.class)).thenReturn(query);
		when(query.getSingleResult()).thenThrow(NoResultException.class);
		assertThrows(NullPointerException.class, () -> quizJPAUtility.modifyQuiz(title, quiz));

	}

	@Test
	void sadPath_TestRemoveQuizFail() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(testQuiz);
		when(entityManager.createQuery("FROM Quiz q WHERE q.title = '" + "testQuiz" + "'",Quiz.class)).thenReturn(query);
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		when(query.getSingleResult()).thenReturn(testQuiz);
		doThrow(PersistenceException.class).when(entityManager).remove(testQuiz);
		quizJPAUtility.removeQuiz("testQuiz");
		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(entityTransaction).rollback();
	}

	@Test
	void sadPath_modifyQuizTest() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(testQuiz);
		when(entityManager.createQuery("FROM Quiz q WHERE q.title='" + "testQuiz" + "'",Quiz.class)).thenReturn(query);
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		when(query.getSingleResult()).thenReturn(testQuiz);
		doThrow(PersistenceException.class).when(entityManager).merge(testQuiz);
		quizJPAUtility.modifyQuiz("testQuiz", testQuiz);
		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(entityTransaction).rollback();
	}

	@Test
	void sadPath_TestRemoveQuizWhenNoQuizFound() {
	
		when(entityManager.createQuery("FROM Quiz q WHERE q.title = '" + "quiz" + "'",Quiz.class)).thenThrow(new NoResultException());
		assertThrows(NullPointerException.class, () -> quizJPAUtility.removeQuiz("quiz"));
		
	}
	@Test
	void testGetQuizByTitleIfExist() {
		Quiz quiz =new Quiz("title",null);
		String title = quiz.getTitle();
		when(entityManager.createQuery("FROM Quiz q WHERE q.title = '" + title + "'",Quiz.class))
				.thenReturn(query);
		when(query.getSingleResult()).thenReturn(quiz);
		Quiz result = quizJPAUtility.getQuizByTitle(title);
		assertEquals(quiz, result);
		verify(entityManager).createQuery("FROM Quiz q WHERE q.title = '" + title + "'",Quiz.class);
		verify(query).getSingleResult();
	}
	 @Test
	    void testGetQuizByTitle_WithNoQuizFound_ShouldThrowException() {
	        when(entityManager.createQuery("FROM Quiz q WHERE q.title = '" + "title" + "'",Quiz.class))
			.thenReturn(query);
	        when(query.getSingleResult()).thenThrow(new NoResultException());
	        assertThrows(NullPointerException.class, () -> quizJPAUtility.getQuizByTitle("title"));
	    }

	@Test
	void testGetQuizWithoutTitleFail() {
		assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.getQuizByTitle(""));
	}

	

}