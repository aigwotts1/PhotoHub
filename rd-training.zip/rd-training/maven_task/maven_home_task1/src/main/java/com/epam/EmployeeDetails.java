//task 1 and task 3 i.e. creating employee class with address class functionality 
public class EmployeeDetails extends Address{
    int id,salary;
 String name;
  void ID(int id) {
    this.id=id;
  }
  void name(String name){
      this.name=name;
  }
  void salary(int salary) {
    this.salary=salary;
  }
  void printDetails(){
      System.out.println("Employee ID is "+id+" , Employee name is "+name+" and Employee salary is "+salary+" Rupees");
  }

 
  public static void main(String[] args) {
    EmployeeDetails emp = new EmployeeDetails();
    CourseDetails cs = new CourseDetails();
    EmployeeDetails je=new JuniorEngineer();
    EmployeeDetails se=new SoftwareEngineer();
    Trainer te=new Trainer();
    emp.ID(10001);
    emp.name("Abhinav");
    emp.salary(50000);
    emp.printDetails();
    
    se.ID(10001);
    se.name("Abhinav");
    se.salary(50000);
    se.printDetails();
    te.printDetails();
  }
}
//task 1 i.e. creating course class
 class CourseDetails {
  int id,duration;
  String name;
}
//task 2 i.e. creating JE , SE and Trainer classes
class JuniorEngineer extends EmployeeDetails {
	int assessmentScore;
	String feedback;
}
//task 4 having different print methods for child classes
class SoftwareEngineer extends EmployeeDetails {
	String projectName="SPRING";
	void ID(int id) {
    this.id=id;
  }
  void name(String name){
      this.name=name;
  }
  void salary(int salary) {
    this.salary=salary;
  }
	 void printDetails() {
	     
		System.out.println("Software Engineer Employee ID is "+id+" , his name is "+name+" , Employee salary is "+salary+" Rupees"+" and Project Name: "+projectName);
	}
}

class Trainer extends EmployeeDetails {
	String skills="Java";
	String certifications="Epam Developer";
	
	public void printDetails() {
		System.out.println("Skills: "+skills+" and Certifications: "+certifications);
	}
}
// task 3 i.e. creating address class 
class Address {
	int floorNumber;
	String streetName;
	String cityName;
	String state;
	String country;
}
