public class task5
{static String FindTheDay(String days[], String day, int p) {
		p = p%7;
		int idx = 0;
		for(int i = 0; i < 7; i++) if(days[i].equals(day)) idx = i;
		return days[(idx + p)%7];
	}
	public static void main(String args[]) {
		String daysOfWeekend[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
		int p = 3;
		String Given_day = "Saturday";
		System.out.println(FindTheDay(daysOfWeekend, Given_day, p));
	}
	
}