package com.epam.library.app.controller.tests;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.epam.library.app.client.BookClient;
import com.epam.library.app.client.UserClient;
import com.epam.library.app.controller.LibraryController;
import com.epam.library.app.model.BookDto;
import com.epam.library.app.model.LibraryDto;
import com.epam.library.app.model.UserDto;
import com.epam.library.app.service.LibraryService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(LibraryController.class)
class LibraryControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private LibraryService libraryService;

	@MockBean
	BookClient bookClient;

	@MockBean
	UserClient userClient;

	@Test
	void testGetBookById() throws Exception {
		BookDto book = BookDto.builder().id(1).name("Book1").author("Author1").publisher("Publisher1").build();

		when(bookClient.getBookById(1)).thenReturn(ResponseEntity.ok(book));
		mockMvc.perform(get("/library/books/1", 1)).andExpect(status().isOk())
				.andExpect(jsonPath("$.name", is(book.getName())))
				.andExpect(jsonPath("$.publisher", is(book.getPublisher())))
				.andExpect(jsonPath("$.author", is(book.getAuthor()))).andDo(print());
		verify(bookClient).getBookById(1);
	}

	@Test
	void testAddBook() throws Exception {
		BookDto bookDTO = BookDto.builder().name("Book 1").publisher("Publisher 1").author("Author 1").build();
		when(bookClient.addBook(bookDTO)).thenReturn(ResponseEntity.ok(bookDTO));
		mockMvc.perform(post("/library/books").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(bookDTO))).andExpect(status().isOk())
				.andExpect(jsonPath("$.name", is(bookDTO.getName())))
				.andExpect(jsonPath("$.publisher", is(bookDTO.getPublisher())))
				.andExpect(jsonPath("$.author", is(bookDTO.getAuthor())));
		verify(bookClient).addBook(bookDTO);
	}

	@Test
	void testDeleteBookById() throws Exception {
		Long bookId = 1L;
		doNothing().when(libraryService).deleteLibrary(bookId);
		mockMvc.perform(delete("/library/books/{bookId}", bookId)).andExpect(status().isOk());
		verify(libraryService).deleteLibrary(bookId);
	}

	@Test
	void testGetAllBooks() throws Exception {
		BookDto book1 = BookDto.builder().id(1).name("Book1").author("Author1").publisher("Publisher1").build();
		List<BookDto> bookDTOList = Arrays.asList(book1);
		Mockito.when(bookClient.getAllBooks()).thenReturn(new ResponseEntity<>(bookDTOList, HttpStatus.OK));
		mockMvc.perform(get("/library/books")).andExpect(status().isOk())
				.andExpect(jsonPath("$.size()").value(bookDTOList.size()))
				.andExpect(jsonPath("$.[0].name").value(bookDTOList.get(0).getName()));
		verify(bookClient).getAllBooks();
	}

	

	@Test
	void testIssueBooks() throws Exception {
		Long bookId = 123L;
		String username = "john.doe";
		LibraryDto libraryDTO = LibraryDto.builder().username(username).bookId(bookId).build();
		when(libraryService.issueBook(username, 123)).thenReturn(libraryDTO);
		mockMvc.perform(post("/library/users/{username}/books/{bookId}", username, bookId))
				.andExpect(status().isCreated());
		verify(libraryService, times(1)).issueBook(username, 123);
	}

	@Test
	void testAddUser() throws Exception {
		UserDto userDTO = new UserDto(1, "user1", "user1@example.com", "User One");
		Mockito.when(userClient.addUser(userDTO)).thenReturn(new ResponseEntity<>(userDTO, HttpStatus.CREATED));
		mockMvc.perform(post("/library/users").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(userDTO)))
				.andExpect(MockMvcResultMatchers.status().isCreated());
		verify(userClient).addUser(userDTO);
	}

	@Test
	void testUpdateUser() throws Exception {
		UserDto userDTO = new UserDto(1, "user1", "user1@example.com", "user");
		Mockito.when(userClient.updateUser("user1", userDTO)).thenReturn(new ResponseEntity<>(userDTO, HttpStatus.OK));
		mockMvc.perform(put("/library/users/{username}", "user1").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(userDTO))).andExpect(status().isOk())
				.andExpect(jsonPath("$.username", is(userDTO.getUsername())))
				.andExpect(jsonPath("$.email", is(userDTO.getEmail())))
				.andExpect(jsonPath("$.name", is(userDTO.getName())));
		verify(userClient).updateUser("user1", userDTO);
	}

	@Test
	void testDeleteUserByUsername() throws Exception {
		String username = "testuser";
		mockMvc.perform(delete("/library/users/" + username).contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
		verify(userClient).deleteUser(username);
	}

	@Test
	void testGetAllUsers() throws Exception {
		UserDto userDTO1 = new UserDto(1, "testuser1", "testuser1@example.com", "Test User 1");
		List<UserDto> userDTOList = List.of(userDTO1);
		when(userClient.getAllUsers()).thenReturn(ResponseEntity.ok(userDTOList));
		mockMvc.perform(get("/library/users").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].username", is(userDTO1.getUsername())))
				.andExpect(jsonPath("$.[0].email", is(userDTO1.getEmail())))
				.andExpect(jsonPath("$.[0].name", is(userDTO1.getName())));
		verify(userClient).getAllUsers();
	}

	@Test
	void testWithDrawBookFromUser() throws Exception {
		String username = "testuser";
		Long bookId = 123L;
		doNothing().when(libraryService).unIssueBook(username, bookId);
		mockMvc.perform(delete("/library/users/{username}/books/{bookId}", username, bookId)
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNoContent());
		verify(libraryService).unIssueBook(username, bookId);
	}
	
	@Test
	void TeestModifyBook() throws Exception {
		int bookId = 1;
		BookDto bookDTO = new BookDto(1, "Book Name", "Publisher", "Author",100);
		Mockito.when(bookClient.updateBook(bookDTO)).thenReturn(ResponseEntity.ok(bookDTO));
		mockMvc.perform(put("/library/books", bookId).contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(bookDTO))).andExpect(status().isOk());
		verify(bookClient).updateBook(bookDTO);
	}
	
	@Test
	void testGetUserByUsername() throws Exception {
		String username = "user1";
		BookDto book1 = BookDto.builder().id(1).name("Book1").author("Author1").publisher("Publisher1").build();
		List<BookDto> bookDTOList = Arrays.asList(book1);
		Mockito.when(userClient.getUserByUsername(username)).thenReturn(
				new ResponseEntity<>(new UserDto(1, "user1", "user1@example.com", "User One"), HttpStatus.OK));
		//Mockito.when(libraryService.getAllByUsername(username)).thenReturn(bookDTOList);
		mockMvc.perform(get("/library/users/{username}", username)).andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].username").value(username));
		verify(userClient).getUserByUsername(username);
		verify(libraryService).getAllByUsername(username);
	}

}
