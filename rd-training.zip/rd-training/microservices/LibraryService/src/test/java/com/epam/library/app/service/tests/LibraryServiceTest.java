package com.epam.library.app.service.tests;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.epam.library.app.client.BookClient;
import com.epam.library.app.client.UserClient;
import com.epam.library.app.exception.LibraryException;
import com.epam.library.app.model.BookDto;
import com.epam.library.app.model.Library;
import com.epam.library.app.model.LibraryDto;
import com.epam.library.app.model.UserDto;
import com.epam.library.app.repository.LibraryRepository;
import com.epam.library.app.service.LibraryService;

@SpringBootTest
class LibraryServiceTest {

	@Mock
	private LibraryRepository libraryRepository;

	@Mock
	private ModelMapper modelMapper;

	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private LibraryService libraryService;
	
	@Mock
	private UserClient userClient;

	@Mock
	private BookClient bookClient;

	@Test
	public void testIssueBook() {
		// given
		String username = "testuser";
		int bookId = 123;

		Library library = new Library();
		library.setBookId(bookId);
		library.setUsername(username);

		Library savedLibrary = new Library();
		savedLibrary.setBookId(bookId);
		savedLibrary.setUsername(username);

		LibraryDto expectedLibraryDto = new LibraryDto();
		expectedLibraryDto.setId(1L);
		expectedLibraryDto.setBookId(123L);
		expectedLibraryDto.setUsername(username);

		ResponseEntity<BookDto> bookResponseEntity = new ResponseEntity<>(HttpStatus.OK);
		ResponseEntity<UserDto> userResponseEntity = new ResponseEntity<>(HttpStatus.OK);

		when(bookClient.getBookById(bookId)).thenReturn(bookResponseEntity);
		when(userClient.getUserByUsername(username)).thenReturn(userResponseEntity);
		when(libraryRepository.existsByUsernameAndBookId(username, bookId)).thenReturn(false);
		when(libraryRepository.countByUsername(username)).thenReturn(2);
		when(libraryRepository.save(library)).thenReturn(savedLibrary);
		when(modelMapper.map(savedLibrary, LibraryDto.class)).thenReturn(expectedLibraryDto);

		// when
		LibraryDto actualLibraryDto = libraryService.issueBook(username, bookId);

		// then
		assertEquals(expectedLibraryDto, actualLibraryDto);
		verify(bookClient).getBookById(bookId);
		verify(userClient).getUserByUsername(username);
		verify(libraryRepository).existsByUsernameAndBookId(username, bookId);
		verify(libraryRepository).countByUsername(username);
		verify(libraryRepository).save(library);
		verify(modelMapper).map(savedLibrary, LibraryDto.class);
	}
	
	@Test
	public void testIssueBookWithInvalidInputs() {
		// given
		String username = "testuser";
		int bookId = 123;

		ResponseEntity<BookDto> bookResponseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		ResponseEntity<UserDto> userResponseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

		when(bookClient.getBookById(bookId)).thenReturn(bookResponseEntity);
		when(userClient.getUserByUsername(username)).thenReturn(userResponseEntity);

		// when and then
		assertThrows(LibraryException.class, () -> {
			libraryService.issueBook(username, bookId);
		});
		verify(bookClient).getBookById(bookId);
		verify(libraryRepository, never()).existsByUsernameAndBookId(username, bookId);
		verify(libraryRepository, never()).countByUsername(username);
		verify(libraryRepository, never()).save(any());
		verify(modelMapper, never()).map(any(), eq(LibraryDto.class));
	}
	
	@Test
	public void testIssueBookAlreadyIssued() {
		// given
		String username = "testuser";
		int bookId = 123;

		when(bookClient.getBookById(bookId)).thenReturn(new ResponseEntity<>(HttpStatus.OK));
		when(userClient.getUserByUsername(username)).thenReturn(new ResponseEntity<>(HttpStatus.OK));
		when(libraryRepository.existsByUsernameAndBookId(username, bookId)).thenReturn(true);

		// when and then
		assertThrows(LibraryException.class, () -> {
			libraryService.issueBook(username, bookId);
		});
		verify(bookClient).getBookById(bookId);
		verify(userClient).getUserByUsername(username);
		verify(libraryRepository).existsByUsernameAndBookId(username, bookId);
		verify(libraryRepository, never()).countByUsername(username);
		verify(libraryRepository, never()).save(any());
		verify(modelMapper, never()).map(any(), eq(LibraryDto.class));
	}

	@Test
	void testIssueBookExceededLimit() {
		// given
		String username = "testuser";
		int bookId = 123;

		when(bookClient.getBookById(bookId)).thenReturn(new ResponseEntity<>(HttpStatus.OK));
		when(userClient.getUserByUsername(username)).thenReturn(new ResponseEntity<>(HttpStatus.OK));
		when(libraryRepository.existsByUsernameAndBookId(username, bookId)).thenReturn(false);
		when(libraryRepository.countByUsername(username)).thenReturn(3);

		// when and then
		assertThrows(LibraryException.class, () -> {
			libraryService.issueBook(username, bookId);
		});
		verify(bookClient).getBookById(bookId);
		verify(userClient).getUserByUsername(username);
		verify(libraryRepository).existsByUsernameAndBookId(username, bookId);
		verify(libraryRepository).countByUsername(username);
		verify(libraryRepository, never()).save(any());
		verify(modelMapper, never()).map(any(), eq(LibraryDto.class));
	}
	
	@Test
    void testUnIssueBook() {
        // call the method being tested
        libraryService.unIssueBook("John", 1L);

        // verify that the expected method was called on the mock object
        verify(libraryRepository).deleteDistinctByUsernameAndBookId(anyString(), anyLong());
    }
	
	@Test
    void testDeleteLibrary() {
        // call the method being tested
        libraryService.deleteLibrary(1L);

        // verify that the expected method was called on the mock object
        verify(libraryRepository).deleteByBookId(anyLong());
    }
	
	@Test
    void testGetAllByUsername() {
        // create a list of sample library objects
        Library lib1 = new Library();
        lib1.setBookId(1);
        lib1.setUsername("John");
        Library lib2 = new Library();
        lib2.setBookId(2);
        lib2.setUsername("John");
        List<Library> libraryList = Arrays.asList(lib1, lib2);

        // configure the mock object to return the sample library list
        when(libraryRepository.findByUsername(anyString())).thenReturn(libraryList);

        // call the method being tested
        List<Integer> result = libraryService.getAllByUsername("John");

        // assert that the expected result was returned
        assertEquals(Arrays.asList(1, 2), result);
    }
	
	@Test
	void TestDeleteUserFromLibrary() {
		doNothing().when(libraryRepository).deleteByUsername(anyString());
		libraryService.deleteUserFromLibrary("username");
		verify(libraryRepository).deleteByUsername(anyString());
	}

}