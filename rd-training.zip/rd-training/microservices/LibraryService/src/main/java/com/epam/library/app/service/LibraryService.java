package com.epam.library.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.epam.library.app.client.BookClient;
import com.epam.library.app.client.UserClient;
import com.epam.library.app.exception.LibraryException;
import com.epam.library.app.model.Library;
import com.epam.library.app.model.LibraryDto;
import com.epam.library.app.repository.LibraryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LibraryService {

	@Autowired
	LibraryRepository libraryRepository;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	UserClient userClient;
	
	@Autowired
	BookClient bookClient;
	
	public LibraryDto issueBook(String username,int bookId) {
		log.info("issuing book to user");

		Library library=new Library();
		library.setBookId(bookId);
		library.setUsername(username);
		
		if (bookClient.getBookById(bookId).getStatusCode().equals(HttpStatus.BAD_REQUEST)
				|| userClient.getUserByUsername(username).getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
			throw new LibraryException("invalid inputs");
		}
		if (libraryRepository.existsByUsernameAndBookId(username, bookId)) {
			log.error("same book already issued to user");
			throw new LibraryException("same book already issued to user");
		}
		if(libraryRepository.countByUsername(username)==3)
		{
			throw new LibraryException("you already took 3 books");
		}
		library=libraryRepository.save(library);
		return modelMapper.map(library, LibraryDto.class);
	}
	
	@Transactional
	public void unIssueBook(String username,Long bookId)
	{
		log.info("taking book from user");

		libraryRepository.deleteDistinctByUsernameAndBookId(username, bookId);
	}
	@Transactional
	public void deleteLibrary(Long id) {
		log.info("deleting book from library");

		libraryRepository.deleteByBookId(id);
	}
	
	public List<Integer> getAllByUsername(String username){
		log.info("getting all book ids by userngetAllBooksByUsername(Stame");

		return libraryRepository.findByUsername(username).stream().map(l->l.getBookId()).toList();
	}
	
	@Transactional
	public void deleteUserFromLibrary(String username) {
		
		log.info("deleting user from library");
		libraryRepository.deleteByUsername(username);
	}
	
	
}
