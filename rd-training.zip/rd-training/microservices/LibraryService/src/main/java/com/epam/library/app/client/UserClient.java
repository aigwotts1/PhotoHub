package com.epam.library.app.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.epam.library.app.model.UserDto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

@FeignClient(name = "user", url = "http://localhost:9001/")
public interface UserClient {

	@GetMapping("users")
	public ResponseEntity<List<UserDto>> getAllUsers();

	@GetMapping("users/{username}")
	public ResponseEntity<UserDto> getUserByUsername(
			@PathVariable @Valid @NotBlank(message = "invalid username") String username);

	@PostMapping("users")
	public ResponseEntity<UserDto> addUser(@RequestBody @Valid UserDto userDTO);

	@DeleteMapping("users/{username}")
	public ResponseEntity<Void> deleteUser(
			@PathVariable @Valid @NotBlank(message = "invalid username") String username);

	@PutMapping("users/{username}")
	public ResponseEntity<UserDto> updateUser(
			@PathVariable @Valid @NotBlank(message = "invalid username") String username,
			@RequestBody @Valid UserDto userDTO);

}

