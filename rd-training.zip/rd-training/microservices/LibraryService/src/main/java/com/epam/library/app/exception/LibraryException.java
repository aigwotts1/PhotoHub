package com.epam.library.app.exception;

public class LibraryException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LibraryException(String message) {
	super(message);
	}

}