package com.epam.library.app.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDto {
	private int id;
	@NotBlank(message = "invalid username")
	private String username;
	@Email(message = "invalid email")
	private String email;
	@NotBlank(message = "invalid name")
	private String name;
}
