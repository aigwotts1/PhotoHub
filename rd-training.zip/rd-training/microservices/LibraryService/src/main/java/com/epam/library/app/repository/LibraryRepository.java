package com.epam.library.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.epam.library.app.model.Library;


public interface LibraryRepository  extends CrudRepository<Library, Long> {
	
	void deleteDistinctByUsernameAndBookId(String username,Long bookId);	
	void deleteByBookId(Long id);
	List<Library> findByUsername(String username);
	int countByUsername(String username);
    void deleteByUsername(String username);
	boolean existsByUsernameAndBookId(String username, int bookId);
    
}
