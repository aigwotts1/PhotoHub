package com.epam.library.app.model;

import org.hibernate.validator.constraints.Range;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LibraryDto {
	@JsonIgnore
	Long id;
	@NotNull(message = "Invalid Username")
	String username;
	@Range(min = 1L, message = "Invalid Book Id")
	Long bookId;
}