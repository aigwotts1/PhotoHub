package com.epam.library.app.controller;

import java.util.List;

import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.epam.library.app.client.BookClient;
import com.epam.library.app.client.UserClient;
import com.epam.library.app.model.BookDto;
import com.epam.library.app.model.LibraryDto;
import com.epam.library.app.model.UserDto;
import com.epam.library.app.service.LibraryService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/library")
public class LibraryController {

	@Autowired
	LibraryService libraryService;

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	UserClient userClient;
	
	@Autowired
	BookClient bookClient;

	@GetMapping("/books")
	public ResponseEntity<List<BookDto>> getAllBooks() {
		log.info("get request to get all books");
		return bookClient.getAllBooks();
	}

	@GetMapping("/books/{id}")
	public ResponseEntity<BookDto> getBookById(@PathVariable @Valid @Range(min = 1, message = "invalid id") int id) {
		log.info("get request to get book by id: {}", id);
		return bookClient.getBookById(id);
	}

	@PostMapping("/books")
	public ResponseEntity<BookDto> addBook(@RequestBody @Valid BookDto bookDto) {
		log.info("post request to add book: {}", bookDto);
		return bookClient.addBook(bookDto);
	}

	@PutMapping("/books")
	public ResponseEntity<BookDto> modifyBook(@RequestBody @Valid BookDto bookDto) {
		log.info("put request to update book: {}", bookDto);
		return bookClient.updateBook(bookDto);	
	}

	@DeleteMapping("/books/{bookId}")
	public ResponseEntity<Void> deleteBookById(@PathVariable Long bookId) {
		log.info("delete request to delete book with id: {}", bookId);
		libraryService.deleteLibrary(bookId);
		return bookClient.deleteBook(bookId);
	}

	@GetMapping("/users")
	public ResponseEntity<List<UserDto>> getAllUsers() {
		log.info("get request to get all users");
		return userClient.getAllUsers();
	}

	@GetMapping("/users/{username}")
	public ResponseEntity<List<Object>> getUsersByUsername(@PathVariable String username) {

		log.info("get request to get user by username: {}", username);
		ResponseEntity<UserDto> responseEntity = userClient.getUserByUsername(username);
		return new ResponseEntity<>(List.of(responseEntity.getBody(), libraryService.getAllByUsername(username)), HttpStatus.OK);
	}

	@PostMapping("/users")
	public ResponseEntity<UserDto> addUser(@RequestBody @Valid UserDto userDto) {
		log.info("post request to add user: {}", userDto);
		return userClient.addUser(userDto);
	}

	@PutMapping("/users/{username}")
	public ResponseEntity<UserDto> modifyUser(
			@PathVariable @Valid @NotBlank(message = "username invalid") String username,
			@RequestBody @Valid UserDto userDTO) {

		log.info("post request to update user: {}", userDTO);
		return userClient.updateUser(username, userDTO);
	}

	@DeleteMapping("/users/{username}")
	public ResponseEntity<Void> deleteUserByUsername(@PathVariable String username) {
		log.info("delete request to delete user with username: {}", username);
		libraryService.deleteUserFromLibrary(username);
		return userClient.deleteUser(username);	
	}

	@PostMapping("/users/{username}/books/{bookId}")
	public ResponseEntity<LibraryDto> issueBooks(@PathVariable String username, @PathVariable int bookId) {
		log.info("post request to issue book: {} to user: {}", bookId, username);
		return new ResponseEntity<>(libraryService.issueBook(username, bookId), HttpStatus.CREATED);
	}

	@DeleteMapping("/users/{username}/books/{bookId}")
	public ResponseEntity<Void> unIssueBooks(@PathVariable String username, @PathVariable Long bookId) {
		log.info("delete request to take book: {} from user: {}", bookId, username);
		libraryService.unIssueBook(username, bookId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
