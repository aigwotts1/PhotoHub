package com.epam.library.app.client;

import java.util.List;

import org.hibernate.validator.constraints.Range;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.epam.library.app.model.BookDto;

import jakarta.validation.Valid;

@FeignClient(name = "book", url = "http://localhost:9000/")
public interface BookClient {

	@GetMapping("books")
	public ResponseEntity<List<BookDto>> getAllBooks();
	
	@GetMapping("books/{bookId}")
	public ResponseEntity<BookDto> getBookById(@PathVariable @Valid @Range(min = 1, message = "invalid id") int bookId);
	
	@PostMapping("books")
	public ResponseEntity<BookDto> addBook(@RequestBody @Valid BookDto bookDTO);
	
	@DeleteMapping("books/{bookId}")
	public ResponseEntity<Void> deleteBook(@PathVariable @Valid @Range(min = 1, message = "invalid id") Long bookId);
	
	@PutMapping("books")
	public ResponseEntity<BookDto> updateBook(@RequestBody @Valid BookDto bookDTO);
	
}
