package com.epam.user.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.epam.user.app.exception.UserException;
import com.epam.user.app.model.User;
import com.epam.user.app.model.UserDto;
import com.epam.user.app.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	ModelMapper modelMapper;

	private static final String NOT_FOUND = "no user found with given username";

	public List<UserDto> getAllUsers() {
		return userRepository.findAll().stream().map(user -> modelMapper.map(user, UserDto.class)).toList();
	}

	public UserDto getUserByUsername(String username) {
		return modelMapper.map(userRepository.findByUsername(username).orElseThrow(() -> {
			log.error(NOT_FOUND);
			return new UserException(NOT_FOUND);
		}), UserDto.class);
	}

	public UserDto addUser(UserDto userDto) {
		return modelMapper.map(userRepository.save(modelMapper.map(userDto, User.class)), UserDto.class);
	}

	@Transactional
	public void deleteUser(String username) {
		if (!userRepository.existsByUsername(username)) {
			log.error(NOT_FOUND);
			throw new UserException(NOT_FOUND);
		}
		userRepository.deleteByUsername(username);
	}

	public UserDto updateUser(String username, UserDto userDto) {
		User oldUser = userRepository.findByUsername(username).orElseThrow(() -> {
			log.error(NOT_FOUND);
			throw new UserException(NOT_FOUND);
		});
		oldUser.setName(userDto.getName());
		oldUser.setEmail(userDto.getEmail());
		oldUser.setUsername(userDto.getUsername());
		return modelMapper.map(userRepository.save(oldUser), UserDto.class);
	}
}
