package com.epam.user.app.controller.tests;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.epam.user.app.controller.UserRestController;
import com.epam.user.app.model.UserDto;
import com.epam.user.app.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(UserRestController.class)
class UserRestControllerTest {

	@MockBean
	private UserService userService;

	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	void testGetAllUsers() throws Exception {
		UserDto user1 = new UserDto(1, "john", "john@example.com", "John Doe");
		UserDto user2 = new UserDto(2, "jane", "jane@example.com", "Jane Doe");

		List<UserDto> users = Arrays.asList(user1, user2);

		when(userService.getAllUsers()).thenReturn(users);

		mockMvc.perform(get("/users")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id", is(user1.getId())))
				.andExpect(jsonPath("$[0].name", is(user1.getName())))
				.andExpect(jsonPath("$[0].email", is(user1.getEmail())))
				.andExpect(jsonPath("$[1].id", is(user2.getId()))).andExpect(jsonPath("$[1].name", is(user2.getName())))
				.andExpect(jsonPath("$[1].email", is(user2.getEmail())));

		verify(userService, times(1)).getAllUsers();
		verifyNoMoreInteractions(userService);
	}

	@Test
	void testGetUserByUsername() throws Exception {
		UserDto UserDto = new UserDto(1, "john", "john@example.com", "John Doe");
		when(userService.getUserByUsername("john")).thenReturn(UserDto);

		mockMvc.perform(get("/users/{username}", "john")).andExpect(status().isOk()).andExpect(jsonPath("$.id", is(1)))
				.andExpect(jsonPath("$.username", is("john"))).andExpect(jsonPath("$.email", is("john@example.com")))
				.andExpect(jsonPath("$.name", is("John Doe")));

		verify(userService).getUserByUsername("john");
	}

	@Test
	void testAddUser() throws Exception {
		UserDto userDto = UserDto.builder().id(1).username("john_doe").email("john_doe@example.com").name("John Doe")
				.build();

		when(userService.addUser(any(UserDto.class))).thenReturn(userDto);

		mockMvc.perform(post("/users").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(userDto))).andExpect(status().isCreated())
				.andExpect(jsonPath("$.id", is(userDto.getId())))
				.andExpect(jsonPath("$.username", is(userDto.getUsername())))
				.andExpect(jsonPath("$.email", is(userDto.getEmail())))
				.andExpect(jsonPath("$.name", is(userDto.getName())));
	}

	@Test
	void testDeleteUser() throws Exception {
		mockMvc.perform(delete("/users/testuser")).andExpect(status().isNoContent());
	}

	@Test
	void testUpdateUser() throws Exception {
		String username = "john_doe";
		UserDto userDto = UserDto.builder().id(1).username(username).email("john_doe@example.com").name("John Doe")
				.build();

		when(userService.updateUser(eq(username), any(UserDto.class))).thenReturn(userDto);

		mockMvc.perform(put("/users/{username}", username).contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(userDto))).andExpect(status().isOk())
				.andExpect(jsonPath("$.id", is(userDto.getId())))
				.andExpect(jsonPath("$.username", is(userDto.getUsername())))
				.andExpect(jsonPath("$.email", is(userDto.getEmail())))
				.andExpect(jsonPath("$.name", is(userDto.getName())));
	}

}
