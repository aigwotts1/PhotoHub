package com.epam.user.app.service.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.epam.user.app.exception.UserException;
import com.epam.user.app.model.User;
import com.epam.user.app.model.UserDto;
import com.epam.user.app.repository.UserRepository;
import com.epam.user.app.service.UserService;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private ModelMapper modelMapper;

	@InjectMocks
	private UserService userService;

	private User user1;
	private User user2;
	private UserDto userDto1;
	private UserDto userDto2;

	@BeforeEach
	void setUp() throws Exception {
		user1 = new User(1, "john", "john@example.com", "John Doe");
		user2 = new User(2, "jane", "jane@example.com", "Jane Doe");

		userDto1 = new UserDto(1, "john", "john@example.com", "John Doe");
		userDto2 = new UserDto(2, "jane", "jane@example.com", "Jane Doe");
	}

	@Test
		void testGetAllUsers() {
			when(userRepository.findAll()).thenReturn(Arrays.asList(user1, user2));
			when(modelMapper.map(user1, UserDto.class)).thenReturn(userDto1);
			when(modelMapper.map(user2, UserDto.class)).thenReturn(userDto2);

			List<UserDto> users = userService.getAllUsers();

			assertEquals(2, users.size());
			assertEquals(userDto1, users.get(0));
			assertEquals(userDto2, users.get(1));

			verify(userRepository).findAll();
			verify(modelMapper).map(user1, UserDto.class);
			verify(modelMapper).map(user2, UserDto.class);
		}

	@Test
		void testGetUserByUsername() {
			when(userRepository.findByUsername("john")).thenReturn(Optional.of(user1));
			when(modelMapper.map(user1, UserDto.class)).thenReturn(userDto1);

			UserDto user = userService.getUserByUsername("john");

			assertEquals(userDto1, user);

			verify(userRepository).findByUsername("john");
			verify(modelMapper).map(user1, UserDto.class);
		}

	@Test
		void testAddUser() {
			when(modelMapper.map(userDto1, User.class)).thenReturn(user1);
			when(userRepository.save(user1)).thenReturn(user1);
			when(modelMapper.map(user1, UserDto.class)).thenReturn(userDto1);

			UserDto user = userService.addUser(userDto1);

			assertEquals(userDto1, user);

			verify(modelMapper).map(userDto1, User.class);
			verify(userRepository).save(user1);
			verify(modelMapper).map(user1, UserDto.class);
		}

	@Test
		void testDeleteUser() {
			when(userRepository.existsByUsername("john")).thenReturn(true);

			userService.deleteUser("john");

			verify(userRepository).existsByUsername("john");
			verify(userRepository).deleteByUsername("john");
		}

	@Test
	void testUpdateUser() {
		String username = "john";
		UserDto updatedUserDto = new UserDto(1, "john", "johndoe@example.com", "John Doe");
		User updatedUser = new User(1, "john", "johndoe@example.com", "John Doe");

		when(userRepository.findByUsername(username)).thenReturn(Optional.of(user1));
		when(userRepository.save(updatedUser)).thenReturn(updatedUser);
		when(modelMapper.map(updatedUser, UserDto.class)).thenReturn(updatedUserDto);

		UserDto result = userService.updateUser(username, updatedUserDto);

		assertEquals(updatedUserDto, result);

		verify(userRepository).findByUsername(username);
		verify(userRepository).save(updatedUser);
		verify(modelMapper).map(updatedUser, UserDto.class);
	}

	@Test
	void testUpdateUserNotFound() {
		String username = "john";
		UserDto updatedUserDto = new UserDto(1, "john", "johndoe@example.com", "John Doe");

		when(userRepository.findByUsername(username)).thenReturn(Optional.empty());

		UserException exception = org.junit.jupiter.api.Assertions.assertThrows(UserException.class, () -> {
			userService.updateUser(username, updatedUserDto);
		});

		assertEquals("no user found with given username", exception.getMessage());

		verify(userRepository).findByUsername(username);
	}

	@Test
	void testGetUserByUsernameThrowsException() {
		when(userRepository.findByUsername(anyString())).thenReturn(Optional.empty());

		UserException exception = org.junit.jupiter.api.Assertions.assertThrows(UserException.class, () -> {
			userService.getUserByUsername("john");
		});
		assertEquals("no user found with given username", exception.getMessage());

		verify(userRepository).findByUsername("john");
	}

	@Test
	void testDeleteUserDoesNotExist() {
		String username = "jane";
		when(userRepository.existsByUsername(username)).thenReturn(false);

		assertThrows(UserException.class, () -> {
			userService.deleteUser(username);
		});

		verify(userRepository).existsByUsername(username);
		verify(userRepository, never()).deleteByUsername(username);
	}
}
