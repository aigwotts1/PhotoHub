package com.epam.book.app.controller.test;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.epam.book.app.controller.BookController;
import com.epam.book.app.model.Book;
import com.epam.book.app.model.BookDto;
import com.epam.book.app.service.BookService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(BookController.class)
class BookControllerTest {

    @MockBean
    private BookService bookService;
    
    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void testCreateBook() throws Exception {
		BookDto BookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);

        when(bookService.addBook(any(BookDto.class))).thenReturn(BookDto);

        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(BookDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is(BookDto.getName())))
                .andExpect(jsonPath("$.publisher", is(BookDto.getPublisher())))
                .andExpect(jsonPath("$.author", is(BookDto.getAuthor())));
    }

    @Test
    void testDeleteBook() throws Exception {
        int bookId = 1;

        mockMvc.perform(delete("/books/{id}", bookId))
                .andExpect(status().isNoContent());

        verify(bookService, times(1)).deleteBookById(bookId);
    }

    @Test
    void testDisplayAllBook() throws Exception {
		Book BookDto1 = new Book(1, "Book 1", "Publisher 1", "Author 1", 100);
		Book BookDto2 = new Book(1, "Book 1", "Publisher 1", "Author 1", 100);


        List<Book> BookDtoList = Arrays.asList(BookDto1, BookDto2);

        when(bookService.getAllBooks()).thenReturn(BookDtoList);

        mockMvc.perform(get("/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.[0].id", is(BookDto1.getId())))
                .andExpect(jsonPath("$.[0].name", is(BookDto1.getName())))
                .andExpect(jsonPath("$.[0].publisher", is(BookDto1.getPublisher())))
                .andExpect(jsonPath("$.[0].author", is(BookDto1.getAuthor())))
                .andExpect(jsonPath("$.[1].id", is(BookDto2.getId())))
                .andExpect(jsonPath("$.[1].name", is(BookDto2.getName())))
                .andExpect(jsonPath("$.[1].publisher", is(BookDto2.getPublisher())))
                .andExpect(jsonPath("$.[1].author", is(BookDto2.getAuthor())));
    }

    @Test
    void testDisplayBookById() throws Exception {
        int bookId = 1;
		BookDto BookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);


        when(bookService.getBookById(bookId)).thenReturn(BookDto);

        mockMvc.perform(get("/books/{id}", bookId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(BookDto.getId())))
                .andExpect(jsonPath("$.name", is(BookDto.getName())))
                .andExpect(jsonPath("$.publisher", is(BookDto.getPublisher())))
                .andExpect(jsonPath("$.author", is(BookDto.getAuthor())));
    }
    
    @Test
    void testModifyBook() throws Exception {
		BookDto BookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);

        when(bookService.updateBook(any(BookDto.class))).thenReturn(BookDto);

        mockMvc.perform(put("/books")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(new ObjectMapper().writeValueAsString(BookDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is(BookDto.getName())))
                .andExpect(jsonPath("$.author", is(BookDto.getAuthor())))
                .andExpect(jsonPath("$.publisher", is(BookDto.getPublisher())));
    }
}
