package com.epam.book.app.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.epam.book.app.exception.BookException;
import com.epam.book.app.model.Book;
import com.epam.book.app.model.BookDto;
import com.epam.book.app.repository.BookRepository;
import com.epam.book.app.service.BookService;

@ExtendWith(MockitoExtension.class)
class BookServiceTest {
	
	@InjectMocks
	private BookService bookService;
	
	@Mock
	private BookRepository bookRepository;
	
	@Mock
	private ModelMapper modelMapper;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testGetAllBooks() {
		// Mocking the repository's response
		List<Book> bookList = new ArrayList<>();
		bookList.add(new Book(1, "Book 1", "Publisher 1", "Author 1", 100));
		bookList.add(new Book(2, "Book 2", "Publisher 2", "Author 2", 200));
		when(bookRepository.findAll()).thenReturn(bookList);
		
		// Calling the service method
		List<Book> result = bookService.getAllBooks();
		
		// Asserting the result
		assertEquals(2, result.size());
		assertEquals("Book 1", result.get(0).getName());
		assertEquals("Publisher 2", result.get(1).getPublisher());
	}
	
	@Test
	void testGetBookById() {
		// Mocking the repository's response
		Book book = new Book(1, "Book 1", "Publisher 1", "Author 1", 100);
		BookDto bookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);

		when(modelMapper.map(book, BookDto.class)).thenReturn(bookDto);
		when(bookRepository.findById(1)).thenReturn(Optional.of(book));
		
		// Calling the service method
		BookDto result = bookService.getBookById(1);
		
		// Asserting the result
		assertEquals("Book 1", result.getName());
		assertEquals("Publisher 1", result.getPublisher());
		assertEquals("Author 1", result.getAuthor());
		assertEquals(100, result.getPages());
	}
	
	@Test
	void testGetBookByIdNotFound() {
		// Mocking the repository's response
		when(bookRepository.findById(1)).thenReturn(Optional.empty());
		
		// Asserting that the service method throws an exception
		assertThrows(BookException.class, () -> bookService.getBookById(1));
	}
	
	@Test
	void testAddBook() {
		// Creating the input data
		BookDto bookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);
		// Mocking the repository's response
		Book book = new Book(1, "Book 1", "Publisher 1", "Author 1", 100);
		when(modelMapper.map(book, BookDto.class)).thenReturn(bookDto);
		when(modelMapper.map(bookDto, Book.class)).thenReturn(book);

		when(bookRepository.save(book)).thenReturn(book);
		
		// Calling the service method
		BookDto result = bookService.addBook(bookDto);
		
		// Asserting the result
		assertEquals(1, result.getId());
		assertEquals("Book 1", result.getName());
		assertEquals("Publisher 1", result.getPublisher());
		assertEquals("Author 1", result.getAuthor());
		assertEquals(100, result.getPages());
	}
	
	@Test
	void testDeleteBookById() {
		// Creating the input data
		int id = 1;
		
		// Mocking the repository's response
		Book book = new Book(id, "Book 1", "Publisher 1", "Author 1", 100);
		when(bookRepository.findById(id)).thenReturn(java.util.Optional.of(book));
		
		// Calling the service method
		bookService.deleteBookById(id);
		
		// Verifying the results
		verify(bookRepository, times(1)).deleteById(id);
	}
	
	@Test
	void testDeleteBookByIdWithInvalidId() {
		// Creating the input data
		int id = 1;
		
		// Mocking the repository's response
		when(bookRepository.findById(id)).thenReturn(java.util.Optional.empty());
		
		// Calling the service method and verifying that it throws an exception
		try {
			bookService.deleteBookById(id);
		} catch (BookException ex) {
			assertEquals("Book Not Found", ex.getMessage());
			verify(bookRepository, times(0)).deleteById(id);
		}
	}
	
	@Test
	void testUpdateBook() {
		// Creating the input data
		int id = 1;
		BookDto bookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);

		
		// Mocking the repository's response
		Book book = new Book(id, "Book 1", "Publisher 1", "Author 1", 100);
		when(modelMapper.map(book, BookDto.class)).thenReturn(bookDto);
		when(modelMapper.map(bookDto, Book.class)).thenReturn(book);
		when(bookRepository.findById(id)).thenReturn(java.util.Optional.of(book));
		when(bookRepository.save(book)).thenReturn(book);
		
		// Calling the service method
		BookDto updatedBookDto = bookService.updateBook(bookDto);
		
		// Verifying the results
		verify(bookRepository, times(1)).findById(id);
		verify(bookRepository, times(1)).save(book);
		assertEquals(id, updatedBookDto.getId());
		assertEquals("Book 1", updatedBookDto.getName());
		assertEquals("Publisher 1", updatedBookDto.getPublisher());
		assertEquals("Author 1", updatedBookDto.getAuthor());
		assertEquals(100, updatedBookDto.getPages());
	}
	
	@Test
	void testUpdateBookWithInvalidId() {
		// Creating the input data
		int id = 1;
		BookDto bookDto = new BookDto(1, "Book 1", "Publisher 1", "Author 1", 100);

		
		// Mocking the repository's response
		when(bookRepository.findById(id)).thenReturn(java.util.Optional.empty());
		
		// Calling the service method and verifying that it throws an exception
		try {
			bookService.updateBook(bookDto);
		} catch (BookException ex) {
			assertEquals("Book Not Found", ex.getMessage());
			verify(bookRepository, times(0)).save(Mockito.any(Book.class));
		}
	}
	
}
