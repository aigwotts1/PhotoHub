package com.epam.book.app.model;

import org.hibernate.validator.constraints.Range;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BookDto {
	
	int id;
	@NotBlank(message = "Invalid Name")
	String name;
	
	@NotBlank(message = "Invalid Publisher Name")
	String publisher;
	
	@NotBlank(message = "Invalid Author Name")
	String author;
	
	@Range(min=0 ,message = "Invalid Pages")
	int pages;
}
