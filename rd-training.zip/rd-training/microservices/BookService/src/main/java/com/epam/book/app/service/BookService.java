package com.epam.book.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epam.book.app.exception.BookException;
import com.epam.book.app.model.Book;
import com.epam.book.app.model.BookDto;
import com.epam.book.app.repository.BookRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookService {
	
	@Autowired
	BookRepository bookRepository;

	@Autowired
	ModelMapper modelMapper;
	
	Book book;
	
	public List<Book> getAllBooks() {
		log.info("Entered into getAllBooks");
		return (List<Book>) bookRepository.findAll();
	}

	public BookDto getBookById(int id) {
		log.info("Entered into getBookById {}:",id);
		return modelMapper.map(bookRepository.findById(id).orElseThrow(() -> new BookException("Book Not Found")),BookDto.class);
	}

	public BookDto addBook(BookDto bookDto) {
		log.info("Entered into addBook {}:",bookDto);
		book = modelMapper.map(bookDto, Book.class);
		return modelMapper.map(bookRepository.save(book),BookDto.class);
	}

	public void deleteBookById(int id) {
		log.info("Entered into deleteBookById {}:",id);
		book = bookRepository.findById(id).orElseThrow(() -> new BookException("Book Not Found"));
		bookRepository.deleteById(id);
	}

	public BookDto updateBook(BookDto bookDto) {
		log.info("Entered into updateBook {}:",bookDto);
		int id = bookDto.getId();
		book = bookRepository.findById(id).orElseThrow(() -> new BookException("Book Not Found"));
		book = modelMapper.map(bookDto, Book.class);
		return modelMapper.map(bookRepository.save(book),BookDto.class);
	}

}
