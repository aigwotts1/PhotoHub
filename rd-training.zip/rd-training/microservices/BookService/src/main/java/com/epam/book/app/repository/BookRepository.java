package com.epam.book.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.epam.book.app.model.Book;

public interface BookRepository extends CrudRepository<Book, Integer>{

}
