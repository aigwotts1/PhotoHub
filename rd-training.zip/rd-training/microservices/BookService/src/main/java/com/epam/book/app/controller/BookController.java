package com.epam.book.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.epam.book.app.model.Book;
import com.epam.book.app.model.BookDto;
import com.epam.book.app.service.BookService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class BookController {

	@Autowired
	BookService bookService;
	
	@GetMapping("/books")
	public ResponseEntity<List<Book>> getAllBooks() {
		log.info("Get request to Get All Books");
		return new ResponseEntity<>(bookService.getAllBooks(),HttpStatus.OK);
	}
	
	@GetMapping("/books/{id}")
	public ResponseEntity<BookDto> getBookById(@PathVariable @Valid @NotBlank(message = "Invalid Id") int id) {
		log.info("Get request to get Book By Id");
		return new ResponseEntity<>(bookService.getBookById(id),HttpStatus.OK);
	}
	
	@PostMapping("/books")
	public ResponseEntity<BookDto> addBook(@RequestBody @Valid BookDto bookDto) {
		log.info("Recieved Post request to save {}:",bookDto);
		return new ResponseEntity<>(bookService.addBook(bookDto),HttpStatus.OK);
	}
	
	@DeleteMapping("/books/{id}")
	public ResponseEntity<Void> deleteBook(@PathVariable @Valid @NotBlank(message = "Invalid Id") int id) {
		log.info("Delete request to delete book by id");
		bookService.deleteBookById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/books")
	public ResponseEntity<BookDto> updateBook(@RequestBody @Valid BookDto bookDto) {
		log.info("Put request to update book");
		return new ResponseEntity<>(bookService.updateBook(bookDto),HttpStatus.OK);
	}
}
