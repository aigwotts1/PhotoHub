package open_close;

public class WhatsappNotificationServiceImpl {

	public void sendOTP(String medium) {
		if (medium.equals("WhatsaApp")) {
			System.out.println("Whatsapp Notification");
		}
	}
}