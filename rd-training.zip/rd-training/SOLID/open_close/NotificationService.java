package open_close;

public interface NotificationService {

	public void sendOTP(String medium);
}