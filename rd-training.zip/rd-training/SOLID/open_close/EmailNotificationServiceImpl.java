package open_close;

public class EmailNotificationServiceImpl implements NotificationService {

	@Override
	public void sendOTP(String medium) {
		if (medium.equals("Email")) {
			System.out.println("Email Notification");
		}
	}
}