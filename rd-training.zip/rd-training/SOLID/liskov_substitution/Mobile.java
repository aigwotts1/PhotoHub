package liskov_substitution;

public interface Mobile {

	public default void sendSMS() {

	}

	public default void call() {

	}

	public abstract void playMusic(String fileName);

	public default void playVideo(String videoFileName) {

	}
}