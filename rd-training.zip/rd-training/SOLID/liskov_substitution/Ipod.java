package liskov_substitution;

public class Ipod implements Mobile {

	@Override
	public void playMusic(String fileName) {

		System.out.println("Playing music " + fileName);

	}
}