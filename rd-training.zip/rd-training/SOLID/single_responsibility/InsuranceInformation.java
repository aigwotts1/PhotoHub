package single_responsibility;

public class InsuranceInformation {

	public void getTravelInsuranceInfo(int ticketId) {

	}
}
