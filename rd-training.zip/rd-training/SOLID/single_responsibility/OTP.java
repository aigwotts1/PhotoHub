package single_responsibility;

public class OTP {

	public void sendOTP(String medium) {
		if (medium.equals("email")) {
		}
	}
}