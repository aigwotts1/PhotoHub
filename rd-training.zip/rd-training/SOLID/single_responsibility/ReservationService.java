package single_responsibility;

public class ReservationService {

	public String search(String source, String destination) {

		return "Buses Found";
	}

	public String bookTicket(int numberOfSeats) {

		return "Ticket Booked";
	}

	public void printTickect() {

	}
}