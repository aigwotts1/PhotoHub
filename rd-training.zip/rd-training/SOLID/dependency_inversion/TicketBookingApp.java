package dependency_inversion;

public class TicketBookingApp {
	
	private Swipeable card;

	public TicketBookingApp(Swipeable debitCard) {
		this.card = debitCard;
	}

	public void doPayment(int noOfTickets, int amount) {
		card.doTransaction(amount);
	}

	public static void main(String[] args) {
		Swipeable debitCard = new DebitCard();
		TicketBookingApp ticketApp = new TicketBookingApp(debitCard);
		ticketApp.doPayment(4, 5000);
	}
}