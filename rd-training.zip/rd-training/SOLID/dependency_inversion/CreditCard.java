package dependency_inversion;

public class CreditCard implements Swipeable {

	@Override
	public void doTransaction(int amount) {
		System.out.println("CreditCard");
	}
}