package dependency_inversion;

public class DebitCard implements Swipeable {

	@Override
	public void doTransaction(int amount) {
		System.out.println("Debit Card");
	}
}