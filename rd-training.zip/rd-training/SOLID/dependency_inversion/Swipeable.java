package dependency_inversion;

public interface Swipeable {

	public void doTransaction(int amount);
	
}