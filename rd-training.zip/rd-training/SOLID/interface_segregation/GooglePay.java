package interface_segregation;

public class GooglePay implements UPIPayments, CashBack {

	@Override
	public void getCashBackAsCreditBalance() {

	}

	@Override
	public void payMoney() {

	}

	@Override
	public void getScratchCard() {

	}
}