package interface_segregation;

public class Paytm implements UPIPayments {

	@Override
	public void payMoney() {

	}

	@Override
	public void getScratchCard() {

	}
}