package interface_segregation;

public interface CashBack {

	public void getCashBackAsCreditBalance();
}