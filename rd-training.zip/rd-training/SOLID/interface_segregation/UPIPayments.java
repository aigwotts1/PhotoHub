package interface_segregation;

public interface UPIPayments {

	public void payMoney();

	public void getScratchCard();
}