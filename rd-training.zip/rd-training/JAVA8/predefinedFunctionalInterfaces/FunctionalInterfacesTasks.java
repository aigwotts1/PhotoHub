package predefinedFunctionalInterfaces;

import java.util.List;

public class FunctionalInterfacesTasks {

	private static final String ELECTRONIC_PRODUCT = "Electronics";
	private static final String WOMENS_FASHION = "Women's Fashion";
	private static final String MENS_FASHION = "Men's Fashion";
	private static final String NORMAL_QUALITY = "Normal";
	private static final String KIDS_CATEGORY = "Kids";

	public static void main(String[] args) {

		List<Product> companyProducts = List.of(new Product(ELECTRONIC_PRODUCT, "Iphone", 48000, "Premium"),
				new Product(ELECTRONIC_PRODUCT, "MacBook", 150000.0, NORMAL_QUALITY),
				new Product(ELECTRONIC_PRODUCT, "Sony Video Projector", 425000, NORMAL_QUALITY),
				new Product("Eatable", "KurKure", 20, NORMAL_QUALITY),
				new Product(WOMENS_FASHION, "Fast-Track Watch", 10000, NORMAL_QUALITY),
				new Product(WOMENS_FASHION, "Leather HandBag", 2500, NORMAL_QUALITY),
				new Product(MENS_FASHION, "T-Shirt", 5000, NORMAL_QUALITY),
				new Product(ELECTRONIC_PRODUCT, "Light Pen", 50, NORMAL_QUALITY),
				new Product(MENS_FASHION, "Reebok Shoes", 5000, NORMAL_QUALITY),
				new Product(MENS_FASHION, "Titan Watch", 4800, NORMAL_QUALITY),
				new Product(KIDS_CATEGORY, "HeadBands", 200, NORMAL_QUALITY),
				new Product(KIDS_CATEGORY, "Canvas Cap", 1200, NORMAL_QUALITY),
				new Product("Cosmetics", "Makeup Kit", 500, NORMAL_QUALITY));

		calculateCostOfAllProducts(companyProducts);

		calculateCostOfProductsPricedAboveThousand(companyProducts);

		calculateCostOfAllElectronicProducts(companyProducts);

		calculateCostOfElectronicProductsPricedAboveThousand(companyProducts);
	}

	private static void calculateCostOfAllProducts(List<Product> companyProducts) {

		double sumOfProducts = companyProducts.stream().mapToDouble(product -> product.getPrice()).sum();
		System.out.println(sumOfProducts);

	}

	private static void calculateCostOfProductsPricedAboveThousand(List<Product> companyProducts) {

		double sumOfProducts = companyProducts.stream().filter(product -> product.getPrice() > 1000)
				.mapToDouble(product -> product.getPrice()).sum();
		System.out.println(sumOfProducts);

	}

	private static void calculateCostOfAllElectronicProducts(List<Product> companyProducts) {

		double sumOfProducts = companyProducts.stream()
				.filter(product -> product.getCategory().equals(ELECTRONIC_PRODUCT))
				.mapToDouble(product -> product.getPrice()).sum();
		System.out.println(sumOfProducts);

	}

	private static void calculateCostOfElectronicProductsPricedAboveThousand(List<Product> companyProducts) {

		double sumOfProducts = companyProducts.stream()
				.filter(product -> product.getPrice() > 1000 && product.getCategory().equals(ELECTRONIC_PRODUCT))
				.mapToDouble(product -> product.getPrice()).sum();
		System.out.println(sumOfProducts);

	}
}