package predefinedFunctionalInterfaces;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerTasks {

	private static final String ELECTRONIC_PRODUCT = "Electronics";
	private static final String WOMENS_FASHION = "Women's Fashion";
	private static final String MENS_FASHION = "Men's Fashion";
	private static final String NORMAL_QUALITY = "Normal";
	private static final String KIDS_CATEGORY = "Kids";

	public static void main(String[] args) {

		List<Product> companyProducts = List.of(new Product(ELECTRONIC_PRODUCT, "Iphone", 48000, "Premium"),
				new Product(ELECTRONIC_PRODUCT, "MacBook", 150000.0, NORMAL_QUALITY),
				new Product(ELECTRONIC_PRODUCT, "Sony Video Projector", 425000, NORMAL_QUALITY),
				new Product("Eatable", "KurKure", 20, NORMAL_QUALITY),
				new Product(WOMENS_FASHION, "Fast-Track Watch", 10000, NORMAL_QUALITY),
				new Product(WOMENS_FASHION, "Leather HandBag", 2500, NORMAL_QUALITY),
				new Product(MENS_FASHION, "T-Shirt", 5000, NORMAL_QUALITY),
				new Product(ELECTRONIC_PRODUCT, "Light Pen", 50, NORMAL_QUALITY),
				new Product(MENS_FASHION, "Reebok Shoes", 5000, NORMAL_QUALITY),
				new Product(MENS_FASHION, "Titan Watch", 4800, NORMAL_QUALITY),
				new Product(KIDS_CATEGORY, "HeadBands", 200, NORMAL_QUALITY),
				new Product(KIDS_CATEGORY, "Canvas Cap", 1200, NORMAL_QUALITY),
				new Product("Cosmetics", "Makeup Kit", 500, NORMAL_QUALITY));

		printDataOnFileAndConsole(companyProducts);

		updateProductsPricedAboveThousand(companyProducts);

		updateProductsPricedAboveThreeThousand(companyProducts);

		getPremiumProductsEndingWithStar(companyProducts);
	}

	private static void printDataOnFileAndConsole(List<Product> companyProducts) {
		Consumer<List<Product>> printDataOnFile = list -> {
			PrintStream onFile;
			try {
				onFile = new PrintStream(new File(
						"C:\\java epam\\FunctionalProgramming\\src\\predefinedFunctionalInterfaces\\file.txt"));

				PrintStream console = System.out;

				System.setOut(onFile);

				for (Product prod : list) {
					System.out.println(prod.toString());
				}

				System.setOut(console);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		};

		System.out.println("First Consumer to be printed on file");

		printDataOnFile.accept(companyProducts);

		Consumer<List<Product>> printDataOnConsole = list -> {
			for (Product prod : list) {
				System.out.println(prod.toString());
			}
		};

		System.out.println("First Task of Consumer to be printed on Console");
		printDataOnConsole.accept(companyProducts);

	}

	private static void updateProductsPricedAboveThousand(List<Product> companyProducts) {

		companyProducts.stream().filter(product -> product.getPrice() > 1000)
				.peek(product -> product.setGrade("Premium")).forEach(System.out::println);

	}

	private static void updateProductsPricedAboveThreeThousand(List<Product> companyProducts) {

		companyProducts.stream().filter(product -> product.getPrice() > 3000)
				.peek(product -> product.setName(product.getName() + "*")).forEach(System.out::println);

	}

	private static void getPremiumProductsEndingWithStar(List<Product> companyProducts) {

		companyProducts.stream()
				.filter(product -> product.getGrade().equals("Premium") && product.getName().endsWith("*"))
				.forEach(System.out::println);

	}
}