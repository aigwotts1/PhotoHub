package predefinedFunctionalInterfaces;

import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

public class SupplierTasks {

	private static final String ELECTRONIC_PRODUCT = "Electronics";
	private static final String WOMENS_FASHION = "Women's Fashion";
	private static final String MENS_FASHION = "Men's Fashion";
	private static final String NORMAL_QUALITY = "Normal";
	private static final String KIDS_CATEGORY = "Kids";

	public static void main(String[] args) {

		List<Product> companyProducts = List.of(new Product(ELECTRONIC_PRODUCT, "Iphone", 48000, "Premium"),
				new Product(ELECTRONIC_PRODUCT, "MacBook", 150000.0, NORMAL_QUALITY),
				new Product(ELECTRONIC_PRODUCT, "Sony Video Projector", 425000, NORMAL_QUALITY),
				new Product("Eatable", "KurKure", 20, NORMAL_QUALITY),
				new Product(WOMENS_FASHION, "Fast-Track Watch", 10000, NORMAL_QUALITY),
				new Product(WOMENS_FASHION, "Leather HandBag", 2500, NORMAL_QUALITY),
				new Product(MENS_FASHION, "T-Shirt", 5000, NORMAL_QUALITY),
				new Product(ELECTRONIC_PRODUCT, "Light Pen", 50, NORMAL_QUALITY),
				new Product(MENS_FASHION, "Reebok Shoes", 5000, NORMAL_QUALITY),
				new Product(MENS_FASHION, "Titan Watch", 4800, NORMAL_QUALITY),
				new Product(KIDS_CATEGORY, "HeadBands", 200, NORMAL_QUALITY),
				new Product(KIDS_CATEGORY, "Canvas Cap", 1200, NORMAL_QUALITY),
				new Product("Cosmetics", "Makeup Kit", 500, NORMAL_QUALITY));

		getRandomProduct(companyProducts);
		getRandomOTP(companyProducts);

	}

	private static void getRandomProduct(List<Product> companyProducts) {

		Supplier<Product> randomValue = () -> {
			Random random = new Random();
			int randomNumber = random.nextInt(companyProducts.size());
			return companyProducts.get(randomNumber);

		};
		System.out.println(randomValue.get());

	}

	private static void getRandomOTP(List<Product> companyProducts) {

		Supplier<String> randomOTP = () -> {
			String otp = "";
			for (int i = 0; i < 4; i++) {
				otp = otp + (int) (Math.random() * 10);
			}
			return otp;
		};
		System.out.println(randomOTP.get());

	}
}