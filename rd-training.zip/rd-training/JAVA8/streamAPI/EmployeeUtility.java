package streamAPI;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class EmployeeUtility {

	private final String MALE = "Male";
	private final String PRODUCT_DEVELOPMENT = "Product Development";
	private final String SALES_AND_MARKETING = "Sales And Marketing";
	private final String FEMALE = "Female";

	public void getCountOfAllEmployees(List<Employee> employeeList) {
		long countOfMaleEmployees = employeeList.stream()
				.filter(employee -> employee.getGender().equalsIgnoreCase(MALE)).count();
		long countOfFemaleEmployees = employeeList.stream()
				.filter(employee -> employee.getGender().equalsIgnoreCase(FEMALE)).count();
		System.out.println(String.format("Male Employees: %d, Female Employees: %d\n", countOfMaleEmployees,
				countOfFemaleEmployees));
	}

	public void getAllDepartments(List<Employee> employeeList) {
		System.out.println("\nDepartment Names : ");
		employeeList.stream().map(employee -> employee.getDepartment()).distinct().forEach(System.out::println);
		System.out.println();
	}

	public void getAverageAgeOfMaleAndFemaleEmployees(List<Employee> employeeList) {
		int averageAgeOfMaleEmployees = (int) employeeList.stream()
				.filter(employee -> employee.getGender().equalsIgnoreCase(MALE)).mapToInt(employee -> employee.getAge())
				.average().orElse(0);
		int averageAgeOfFemaleEmployees = (int) employeeList.stream()
				.filter(employee -> employee.getGender().equalsIgnoreCase(FEMALE))
				.mapToInt(employee -> employee.getAge()).average().orElse(0);
		System.out.println("Male Employees Average Age: " + averageAgeOfMaleEmployees
				+ ", Female Employees Average Age: " + averageAgeOfFemaleEmployees);
	}

	public void getHighestPaidEmployee(List<Employee> employeeList) {
		Optional<Employee> highestPaidEmployee = employeeList.stream()
				.sorted((employeeOne, employeeTwo) -> employeeTwo.getSalary() > employeeOne.getSalary() ? 1 : -1)
				.findFirst();
		System.out.println("\nHighest Paid Employee Details: ");
		highestPaidEmployee.stream().forEach(System.out::println);
	}

	public void getNewEmployeeNames(List<Employee> employeeList) {
		System.out.println("\nNew Employees Names : ");
		employeeList.stream().filter(employee -> employee.getYearOfJoining() > 2015)
				.forEach(employee -> System.out.println(employee.getName()));
		System.out.println();
	}

	public void getAllDepartmentEmployees(List<Employee> employeeList) {
		System.out.println("\nAll Department Names : ");
		Map<String, Long> mapOfAllDepartmentEmployees = employeeList.stream().map(employee -> employee.getDepartment())
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		for (Map.Entry<String, Long> map : mapOfAllDepartmentEmployees.entrySet()) {
			System.out.println(map.getKey() + ": " + map.getValue());
		}
		System.out.println();
	}

	public void getAverageSalaryPerDepartment(List<Employee> employeeList) {
		System.out.println("\nAverage Salary Per Department : ");
		System.out.println(employeeList.stream().collect(
				Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee::getSalary)))
				+ "\n");
	}

	public void getYoungestEmployeeInProductDevelopment(List<Employee> employeeList) {
		Optional<Employee> youngestEmployeeInProductDevelopment = employeeList.stream()
				.filter(employee -> employee.getDepartment().equals(PRODUCT_DEVELOPMENT))
				.sorted((employeeOne, employeeTwo) -> Integer.compare(employeeOne.getAge(), employeeTwo.getAge()))
				.findFirst();
		System.out.println("Youngest Employee Details in Product Development : ");
		youngestEmployeeInProductDevelopment.stream().forEach(System.out::println);
	}

	public void getMostExperiencedEmployee(List<Employee> employeeList) {
		System.out.print("\nMost Experienced Employee : ");
		employeeList.stream()
				.sorted((employeeOne, employeeTwo) -> Integer.compare(2023 - employeeTwo.getYearOfJoining(),
						2023 - employeeOne.getYearOfJoining()))
				.limit(1).forEach(employee -> System.out.println(employee.getName()));
		System.out.println();
	}

	public void getEmployeesInSalesAndMarketing(List<Employee> employeeList) {
		long countOfMaleEmployees = employeeList.stream()
				.filter(employee -> employee.getDepartment().equalsIgnoreCase(SALES_AND_MARKETING)
						& employee.getGender().equalsIgnoreCase(MALE))
				.count();
		long countOfFemaleEmployees = employeeList.stream()
				.filter(employee -> employee.getDepartment().equalsIgnoreCase(SALES_AND_MARKETING)
						& employee.getGender().equalsIgnoreCase(FEMALE))
				.count();
		System.out.println(String.format(
				"Male Employees in Sales and Marketing: %d, Female Employees in Sales and Marketing: %d\n",
				countOfMaleEmployees, countOfFemaleEmployees));
	}

	public void getAverageSalaryByGender(List<Employee> employeeList) {
		int averageSalaryOfMaleEmployees = (int) employeeList.stream()
				.filter(employee -> employee.getGender().equals(MALE)).mapToInt(employee -> employee.getAge()).average()
				.orElse(0);
		int averageSalaryOfFemaleEmployees = (int) employeeList.stream()
				.filter(employee -> employee.getGender().equals(FEMALE)).mapToInt(employee -> employee.getAge())
				.average().orElse(0);
		System.out.println("\nAverage Male Salary : " + averageSalaryOfMaleEmployees + ", Average Female Salary : "
				+ averageSalaryOfFemaleEmployees);
	}

	public void getAllEmployeeNames(List<Employee> employeeList) {
		employeeList.stream().collect(Collectors.groupingBy(Employee::getDepartment)).forEach((key, val) -> {
			System.out.println(key + " Employees : ");
			for (Employee employee : val) {
				System.out.println(employee.getName());
			}
		});
		System.out.println();
	}

	public void getAverageAndTotalSalary(List<Employee> employeeList) {
		double totalSalary = employeeList.stream().mapToDouble(employee -> employee.getSalary()).sum();
		double averageSalary = employeeList.stream().mapToDouble(employee -> employee.getSalary()).average().orElse(0);
		System.out.println(String.format("total salary: %.2f, average salary: %.2f\n", totalSalary, averageSalary));
	}

	public void getEmployeesSeparatedByAge(List<Employee> employeeList) {
		Map<Boolean, List<Employee>> mapOfEmployeesSeparatedByAge = employeeList.stream()
				.collect(Collectors.partitioningBy(employee -> employee.getAge() <= 25));
		System.out.println(
				"Details of Employees Younger Or Equal To 25 Year of Age: \n" + mapOfEmployeesSeparatedByAge.get(true));
		System.out.println(
				"Details of Employees Older Than 25 Years of Age: \n" + mapOfEmployeesSeparatedByAge.get(false) + "\n");
	}

	public void getOldestEmployee(List<Employee> employeeList) {
		System.out.print("Oldest Employee : ");
		employeeList.stream()
				.sorted((employeeOne, employeeTwo) -> Integer.compare(employeeTwo.getAge(), employeeOne.getAge()))
				.limit(1).forEach(employee -> System.out
						.println(employee.getName() + ", " + employee.getAge() + ", " + employee.getDepartment()));
	}
}