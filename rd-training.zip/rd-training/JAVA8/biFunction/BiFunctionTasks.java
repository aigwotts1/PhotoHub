package biFunction;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

public class BiFunctionTasks {
	
	public static void main(String[] args) {

		generateProduct();
		calculateCostOfProducts();

	}

	private static void generateProduct() {
		BiFunction<String, Double, Product> productGenerator = (name, price) -> {
			Product product = new Product();
			product.setName(name);
			product.setPrice(price);
			return product;
		};
		System.out.println(productGenerator.apply("Laptop", 50000.0));
	}

	private static void calculateCostOfProducts() {
		BiFunction<Product, Integer, Double> costCalculator = (product, quantity) -> product.getPrice() * quantity;

		Map<Product, Integer> cartOfProductAndQuantity = new HashMap<>();
		cartOfProductAndQuantity.put(new Product("t-shirt", 1000.0, "Designer", "premium"), 2);
		cartOfProductAndQuantity.put(new Product("trousers", 1500.0, "Fashion", "basic"), 2);
		cartOfProductAndQuantity.put(new Product("jacket", 3000.0, "Fashion", "premium"), 1);
		double cost = 0;
		for (Map.Entry<Product, Integer> map : cartOfProductAndQuantity.entrySet()) {
			cost += costCalculator.apply(map.getKey(), map.getValue());
		}
		System.out.println(cost);
	}
}