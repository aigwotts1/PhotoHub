package lambdas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.BiPredicate;
import java.util.stream.IntStream;

public class LambdasTasks {

	public static void main(String[] args) {

		checkPalindrome();
		getSecondLargestNumberInList();
		validateStringRotation();
		printNumbersUsingRunnableInterface();
		reverseSortNumbersUsingComparator();
		sortByNameUsingComparator();
		reverseSortTreeSetByNumber();
		sortTreeSetByName();
		sortTreeMapByValues();
		reverseSortTreeSetByName();
		reverseSortListByName();

	}

	private static void checkPalindrome() {
		String sentence = "abcdd";
		System.out.print("Is the string " + sentence + " a Palindrome : ");
		System.out.println(IntStream.range(0, sentence.length() / 2)
				.noneMatch(index -> sentence.charAt(index) != sentence.charAt(sentence.length() - index - 1)));
	}

	private static void getSecondLargestNumberInList() {
		List<Integer> listOfNumbers = Arrays.asList(5, 9, 18, 2, 8, 21, 1);
		int secondLargestNumber = listOfNumbers.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
		System.out.println("\nSecond largest number in List : " + secondLargestNumber);
		System.out.println();

	}

	private static void validateStringRotation() {
		System.out.print("Are the strings Rotational : ");
		BiPredicate<String, String> isRotation = (stringOne, stringTwo) -> (stringOne.length() == stringTwo.length())
				&& ((stringOne + stringOne).contains(stringTwo));
		System.out.println(isRotation.test("Abhi", "hiAb"));

	}

	private static void printNumbersUsingRunnableInterface() {
		System.out.print("\nPrinting Numbers Using Runnable Interface : ");
		List<Integer> listOfNumbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
		Runnable runnable = () -> {
			listOfNumbers.stream().forEach(i -> System.out.print(i + " "));
		};
		System.out.println();
		runnable.run();
	}

	private static void reverseSortNumbersUsingComparator() {
		System.out.println("\n\nReverse Sorting Numbers Using Comparator :");
		List<Integer> listOfNumbers = Arrays.asList(1, 2, 3, 4, 5);
		Comparator<Integer> reverseSort = (first, second) -> second.compareTo(first);
		Collections.sort(listOfNumbers, reverseSort);
		listOfNumbers.stream().forEach(System.out::println);
		System.out.println();
	}

	private static void sortByNameUsingComparator() {
		System.out.println("Sort List By Name Using Comparator :");
		List<Employee> listOfEmployees = Arrays.asList(new Employee(1, "Abhi"), new Employee(2, "Aditya"),
				new Employee(3, "Chaitanya"), new Employee(4, "Aaadi"));

		Comparator<Employee> sortByName = (employeeOne, employeeTwo) -> employeeOne.getName()
				.compareTo(employeeTwo.getName());
		Collections.sort(listOfEmployees, sortByName);
		listOfEmployees.stream().forEach(System.out::println);
		System.out.println();
	}

	private static void reverseSortTreeSetByNumber() {
		System.out.println("Reverse Sort TreeSet By Numbers : ");
		Comparator<Integer> ReverseSort = (first, second) -> second.compareTo(first);
		TreeSet<Integer> treeSetOfNumbers = new TreeSet<>(ReverseSort);
		treeSetOfNumbers.add(3);
		treeSetOfNumbers.add(1);
		treeSetOfNumbers.add(4);
		treeSetOfNumbers.add(2);
		treeSetOfNumbers.add(6);
		treeSetOfNumbers.add(0);

		treeSetOfNumbers.stream().forEach(System.out::println);
		System.out.println();
	}

	private static void sortTreeSetByName() {
		System.out.println("Sort TreeSet By Name :");
		Comparator<Employee> sortByName = (employeeOne, employeeTwo) -> employeeOne.getName()
				.compareTo(employeeTwo.getName());

		TreeSet<Employee> treeSetOfEmployees = new TreeSet<>(sortByName);
		treeSetOfEmployees.add(new Employee(1, "Abhinav"));
		treeSetOfEmployees.add(new Employee(2, "Chaitanya"));
		treeSetOfEmployees.add(new Employee(3, "Adi"));
		treeSetOfEmployees.add(new Employee(4, "Deepan"));

		treeSetOfEmployees.stream().forEach(System.out::println);
		System.out.println();
	}

	private static void sortTreeMapByValues() {
		System.out.println("Sort TreeMap By Values :");
		TreeMap<Integer, Integer> treeMap = new TreeMap<>();
		treeMap.put(3, 2);
		treeMap.put(1, 3);
		treeMap.put(4, 0);
		treeMap.put(2, 9);
		treeMap.put(6, 4);
		treeMap.put(0, 5);

		Set<Map.Entry<Integer, Integer>> entrySet = treeMap.entrySet();
		List<Map.Entry<Integer, Integer>> entryList = new ArrayList<>(entrySet);
		Collections.sort(entryList, (entry1, entry2) -> Integer.compare(entry2.getValue(), entry1.getValue()));

		System.out.println(entryList);
		System.out.println();
	}

	private static void reverseSortTreeSetByName() {
		System.out.println("Reverse Sort TreeSet By Name :");
		Comparator<Employee> sortByName = (employeeOne, employeeTwo) -> employeeOne.getName()
				.compareTo(employeeTwo.getName());

		TreeSet<Employee> treeSetOfEmployees = new TreeSet<>(sortByName);
		treeSetOfEmployees.add(new Employee(1, "Abhinav"));
		treeSetOfEmployees.add(new Employee(2, "Chaitanya"));
		treeSetOfEmployees.add(new Employee(3, "Adi"));
		treeSetOfEmployees.add(new Employee(4, "Deepan"));

		treeSetOfEmployees.stream().forEach(System.out::println);
		System.out.println();
	}

	private static void reverseSortListByName() {
		System.out.println("Reverse Sort List By Name :");
		List<Employee> sortListByName = Arrays.asList(new Employee(1, "Abhi"), new Employee(2, "Aditya"),
				new Employee(3, "Chaitanya"), new Employee(4, "Aaadi"));

		Comparator<Employee> sortByName = (employeeOne, employeeTwo) -> employeeTwo.getName()
				.compareTo(employeeOne.getName());
		Collections.sort(sortListByName, sortByName);
		sortListByName.stream().forEach(System.out::println);

	}
}