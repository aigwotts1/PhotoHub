package binaryAndUnaryOperator;

import java.util.Random;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.function.IntSupplier;

public class BinaryAndUnaryOperatorTasks {

	public static void main(String[] args) {

		isNumberPrimeOrNot();
		getSquareOfNumber();
		getRandomIntegerBelowFiveThousand();

	}

	private static void isNumberPrimeOrNot() {
		IntPredicate intPredicate = (number) -> {
			boolean flag = true;
			for (int i = 2; i <= number / 2; i++) {
				if (number % i == 0) {
					flag = false;
				}
			}
			return flag;
		};
		System.out.println(intPredicate.test(11));
	}

	private static void getSquareOfNumber() {
		IntConsumer intConsumer = (number) -> {
			System.out.println(Math.pow(number, 2));
		};
		intConsumer.accept(13);
	}

	private static void getRandomIntegerBelowFiveThousand() {
		IntSupplier intSupplier = () -> {
			Random random = new Random();
			return random.nextInt(5000);
		};
		System.out.println(intSupplier.getAsInt());
	}
}