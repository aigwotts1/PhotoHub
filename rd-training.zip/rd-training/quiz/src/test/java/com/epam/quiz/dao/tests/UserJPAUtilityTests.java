package com.epam.quiz.dao.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.jpa.utilites.UserJPAUtility;
import com.epam.model.User;

@ExtendWith(MockitoExtension.class)
class UserJPAUtilityTests {
 
    @Mock
    private EntityManager entityManager;
    
    @Mock
    private EntityTransaction transaction;
    
    @Mock
    private TypedQuery<User> query;
    
    @InjectMocks
    private UserJPAUtility userJPAUtility;
    
    @Test
    void happyPath_addUserWithFalseAdminTest() {
    	String username = "abhi";
        String password = "password";
        when(entityManager.getTransaction()).thenReturn(transaction);
        User user = userJPAUtility.addUser(username, password);
        assertEquals(username, user.getUserName());
        assertEquals(password, user.getPassword());
        assertFalse(user.isAdmin());
        verify(entityManager,times(2)).getTransaction();
        verify(entityManager).persist(user);
        verify(transaction).commit();
    }

    @Test
    void testAddUserWithEmptyUsernameWithFalseAdmin() {

        String username = "";
        String password = "testpassword";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> userJPAUtility.addUser(username, password));
        assertEquals("username can't be empty", exception.getMessage());
        verify(entityManager, never()).persist(any());
        verify(transaction, never()).commit();
    }

    @Test
    void testAddUserWithEmptyPasswordWithFalseAdmin() {

        String username = "testuser";
        String password = "";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> userJPAUtility.addUser(username, password));
        assertEquals("password can't be empty", exception.getMessage());
        verify(entityManager, never()).persist(any());
        verify(transaction, never()).commit();
    }   
    
    @Test
    void addUserThrowsNullPointerException() {
        String username = "yo";
        String password = "pass";
        //User user = userJPAUtility.addUser(username, password);
        when(entityManager.getTransaction()).thenReturn(transaction);
        doThrow(RuntimeException.class).when(entityManager).persist(any(User.class));
        assertThrows(IllegalArgumentException.class, () -> userJPAUtility.addUser(username, password));
        verify(entityManager, times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
    }
    @Test
    void testGetUserWithValidUsernameAndPassword() {
        String userName = "testUser";
        String password = "testPassword";
        User user = new User(userName, password);
        List<User> users = Collections.singletonList(user);
        when(query.getResultList()).thenReturn(users);
        when(entityManager.createQuery("FROM User u WHERE u.userName='" + userName + "'")).thenReturn(query);

        assertEquals(user, userJPAUtility.getUser(userName, password));
        verify(entityManager).createQuery("FROM User u WHERE u.userName='" + userName + "'");
    }
    @Test
    void testGetUserWithBlankUsername() {
        String userName = "";
        String password = "testPassword";

        assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.getUser(userName, password); });
        verify(entityManager, never()).createQuery(anyString());
    }
    @Test
    void testGetUserWithBlankPassword() {
        String userName = "testUser";
        String password = "";

        assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.getUser(userName, password); });
        verify(entityManager, never()).createQuery(anyString());
    }
    @Test
    void testGetUserWithIncorrectUsernameOrPassword() {
        String userName = "testUser";
        String password = "testPassword";
        when(query.getResultList()).thenReturn(Collections.emptyList());
        when(entityManager.createQuery("FROM User u WHERE u.userName='" + userName + "'")).thenReturn(query);

        assertThrows(IllegalArgumentException.class, () -> { userJPAUtility.getUser(userName, password); });
        verify(entityManager).createQuery("FROM User u WHERE u.userName='" + userName + "'");
    }

    @Test
    void testAddUserWithAdminFunctionality() {
    	String username = "abhi";
        String password = "password";
        when(entityManager.getTransaction()).thenReturn(transaction);
        User user = userJPAUtility.addUser(username, password,true);
        assertEquals(username, user.getUserName());
        assertEquals(password, user.getPassword());
        assertTrue(user.isAdmin());
        verify(entityManager,times(2)).getTransaction();
        verify(entityManager).persist(user);
        verify(transaction).commit();
    }

    @Test
    void testAddUserWithEmptyUsernameAdminFunctionality() {

        String username = "";
        String password = "testpassword";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> userJPAUtility.addUser(username, password,true));
        assertEquals("username can't be empty", exception.getMessage());
        verify(entityManager, never()).persist(any());
        verify(transaction, never()).commit();
    }

    @Test
    void testAddUserWithEmptyPasswordAdminFunctionality() {

        String username = "testuser";
        String password = "";

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> userJPAUtility.addUser(username, password,true));
        assertEquals("password can't be empty", exception.getMessage());
        verify(entityManager, never()).persist(any());
        verify(transaction, never()).commit();
    } 
    @Test
    void addUserThrowsNullPointerExceptionWithAdminFunctionality() {
        String username = "yo";
        String password = "pass";
        when(entityManager.getTransaction()).thenReturn(transaction);
        doThrow(RuntimeException.class).when(entityManager).persist(any(User.class));
        assertThrows(IllegalArgumentException.class, () -> userJPAUtility.addUser(username, password,true));
        verify(entityManager, times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
    }
}