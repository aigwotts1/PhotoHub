package com.epam.quiz.mock.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.model.User;
import com.epam.service.UserService;
import com.epam.user.dao.UserUtility;

@ExtendWith(MockitoExtension.class)
class UserServicetTest {

    @Mock
    private UserUtility userUtility;

    @InjectMocks    
    private UserService userService;

    String username;
    String password;
    
    @BeforeEach
    void setup() {
    	username = "john.doe";
        password = "password";
    }
    
    @Test
    void testAddUser() {
 
        User expectedUser = new User(username, password, false);

        when(userUtility.addUser(username, password)).thenReturn(expectedUser);
        User actualUser = userService.addUser(username, password);
        assertEquals(expectedUser, actualUser);
        verify(userUtility).addUser(username, password);
    }

    @Test
    void testAddAdminUser() {
        
        User expectedUser = new User(username, password, true);

        when(userUtility.addUser(username, password, true)).thenReturn(expectedUser);

        User actualUser = userService.addUser(username, password, true);
        assertEquals(expectedUser, actualUser);
        verify(userUtility).addUser(username, password, true);
    }

    @Test
    void testGetUser() {
        
        User expectedUser = new User(username, password, false);

        when(userUtility.getUser(username, password)).thenReturn(expectedUser);

        User actualUser = userService.getUser(username, password);
        assertEquals(expectedUser, actualUser);
        verify(userUtility).getUser(username, password);
    }
}