package com.epam.quiz.dao.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.jpa.utilites.QuizJPAUtility;
import com.epam.model.Question;
import com.epam.model.QuestionBuilder;
import com.epam.model.Quiz;
import com.epam.question.dao.QuestionUtility;
import com.epam.quiz.dao.QuizMarks;

@ExtendWith(MockitoExtension.class)
class QuizJPAUtilityTests {

	@Mock
	private EntityManager entityManager;

	@Mock
	private QuestionUtility questionUtility;

	@Mock
	private EntityTransaction entityTransaction;

	@Mock
	private TypedQuery<Quiz> query;

	@InjectMocks
	private QuizJPAUtility quizJPAUtility;


	@Test
    void addMarksToQuizQuestionTest() {

        Question question = new Question();
        question.setTitle("Question 1");
        
        when(questionUtility.veiwQuestion("Question 1")).thenReturn(question);

        Quiz quiz = new Quiz();
        quiz.setQuestionList(new ArrayList<>());

        Quiz modifiedQuiz = quizJPAUtility.addMarksToQuizQuestion("Question 1", 10, quiz);

        verify(questionUtility).modifyQuestion("Question 1", question);

        assertEquals(question.getMarks(), 10);
    }

	@Test
	void testAddQuiz() {
		Quiz quiz = new Quiz();
		quiz.setTitle("Sample Quiz");
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		quiz = quizJPAUtility.addQuiz(quiz);
		verify(entityTransaction).begin();
		verify(entityManager).merge(quiz);
		verify(entityTransaction).commit();
		assertEquals("Sample Quiz", quiz.getTitle());
	}

	@Test
	void sadPath_addQuizFailTest() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);

		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		doThrow(PersistenceException.class).when(entityManager).merge(testQuiz);
		assertThrows(RuntimeException.class, () -> quizJPAUtility.addQuiz(testQuiz));
		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(entityTransaction).rollback();
	}

	@Test
	void sadPath_addQuizWithNoTitleTest() {
		Question question = new Question();
		Quiz quiz = new Quiz("", List.of(question));
		Exception exception = assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.addQuiz(quiz));
		assertEquals(exception.getMessage(), "invalid title");
	}

	@Test
	void removeQuizTest() {
		String title = "Test Quiz";
		Quiz quiz = new Quiz(title, new ArrayList<>());
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(quiz);

		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(quizList);

		quizJPAUtility.removeQuiz(title);

		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(query).getResultList();
		verify(entityManager).remove(quiz);
		verify(entityTransaction).commit();
	}

	@Test
	void removeQuiz_invalidTitleTest() {
		String title = "";
		Exception exception = assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.removeQuiz(title));
		assertEquals(exception.getMessage(), "invalid title");
	}

	@Test
	void testModifyQuiz() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Question newQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		Quiz newTestQuiz = new Quiz("testQuiz", Arrays.asList(newQuestion), 10);
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(testQuiz);

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(quizList);
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		Quiz result = quizJPAUtility.modifyQuiz("testQuiz", newTestQuiz);
		assertEquals(testQuiz, result);
		verify(entityManager, times(1)).createQuery(anyString());
		verify(query, times(1)).getResultList();
	}

	@Test
	void testViewQuiz() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		List<Quiz> quizList = List.of(testQuiz);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(quizList);
		Quiz result = quizJPAUtility.viewQuiz(testQuiz.getTitle());
		assertEquals(testQuiz, result);
		verify(entityManager, times(1)).createQuery(anyString());
		verify(query, times(1)).getResultList();
	}

	@Test
	void testViewAllQuiz() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		Map<String, Quiz> testMap = new HashMap<>();
		testMap.put("testQuiz", testQuiz);
		List<Quiz> quizList = List.of(testQuiz);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(quizList);
		Map<String, Quiz> result = quizJPAUtility.viewAllQuiz();
		assertEquals(testMap, result);
		verify(entityManager, times(1)).createQuery(anyString());
		verify(query, times(1)).getResultList();
	}

	@Test
	void modifyQuiz_InvalidInput_ThrowsException() {
		// Arrange
		String title = "";
		Quiz quiz = new Quiz("Valid Quiz Title",
				Arrays.asList(new QuestionBuilder().setTitle("Question 1").getQuestionBuilder(),
						new QuestionBuilder().setTitle("Question 2").getQuestionBuilder()));

		assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.modifyQuiz(title, quiz));
		verify(entityManager, never()).persist(any());
		verify(entityManager, never()).getTransaction();
	}

	@Test
	void modifyQuizNotFoundTest() {
		String title = "quiz";
		Quiz quiz = new Quiz("quiz", Arrays.asList(new QuestionBuilder().setTitle("Question 1").getQuestionBuilder(),
				new QuestionBuilder().setTitle("Question 2").getQuestionBuilder()));
		List<Quiz> list = List.of();
		when(entityManager.createQuery("FROM Quiz q WHERE q.title='" + title + "'")).thenReturn(query);
		when(query.getResultList()).thenReturn(list);
		Exception exception = assertThrows(NullPointerException.class, () -> quizJPAUtility.modifyQuiz(title, quiz));

	}

	@Test
	void viewQuizWithBlankTitleThrowsExceptionTest() {
		Exception exception = assertThrows(IllegalArgumentException.class, () -> quizJPAUtility.viewQuiz(""));
		assertEquals(exception.getMessage(), "invalid title");
	}

	@Test
	void testRemoveQuizFail() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(testQuiz);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		when(query.getResultList()).thenReturn(quizList);
		doThrow(PersistenceException.class).when(entityManager).remove(testQuiz);
		assertThrows(RuntimeException.class, () -> quizJPAUtility.removeQuiz(testQuiz.getTitle()));
		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(entityTransaction).rollback();
	}

	@Test
	void sadPath_modifyQuizTest() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy", "java", 1);
		Quiz testQuiz = new Quiz("testQuiz", Arrays.asList(question), 10);
		List<Quiz> quizList = new ArrayList<>();
		quizList.add(testQuiz);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(entityManager.getTransaction()).thenReturn(entityTransaction);
		when(query.getResultList()).thenReturn(quizList);
		doThrow(PersistenceException.class).when(entityManager).persist(testQuiz);
		assertThrows(RuntimeException.class, () -> quizJPAUtility.modifyQuiz(testQuiz.getTitle(), testQuiz));
		verify(entityManager, times(2)).getTransaction();
		verify(entityTransaction).begin();
		verify(entityTransaction).rollback();
	}

	@Test
	void sadPath_TestRemoveQuizWhenNoQuizFound() {
		Quiz quiz = new Quiz("quiz", Arrays.asList(new QuestionBuilder().setTitle("Question 1").getQuestionBuilder(),
				new QuestionBuilder().setTitle("Question 2").getQuestionBuilder()));
		List<Quiz> list = List.of();
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(list);
		Exception exception = assertThrows(RuntimeException.class, () -> quizJPAUtility.removeQuiz(quiz.getTitle()));
		assertEquals(exception.getMessage(), "not found");
	}
}