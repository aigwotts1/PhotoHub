package com.epam.quiz.mock.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.model.Question;
import com.epam.question.dao.QuestionUtility;
import com.epam.service.QuestionService;

@ExtendWith(MockitoExtension.class)
 class QuestionServiceTest {

	@InjectMocks
    private QuestionService questionService;

    @Mock
    private QuestionUtility questionUtility;

    Question question;
    String title;
    
    @BeforeEach
    void setup() {
        question = new Question("Title", null, "Content", null, 0);
        title = "Title";
    }
    
    @Test
    void testCreateQuestion() {
        when(questionUtility.createQuestion(question)).thenReturn(question);

        Question createdQuestion = questionService.createQuestion(question);
        assertEquals(question, createdQuestion);

        verify(questionUtility).createQuestion(question);
    }

    @Test
    void testRemoveQuestion() {
        when(questionUtility.removeQuestion(title)).thenReturn(question);

        Question removedQuestion = questionService.removeQuestion(title);
        assertEquals(question, removedQuestion);

        verify(questionUtility).removeQuestion(title);
    }

    @Test
    void testModifyQuestion() {
        when(questionUtility.modifyQuestion((title), question)).thenReturn(question);

        Question modifiedQuestion = questionService.modifyQuestion(title, question);
        assertEquals(question, modifiedQuestion);

        verify(questionUtility).modifyQuestion((title),(question));
    }

    @Test
    void testVeiwQuestion() {
        when(questionUtility.veiwQuestion(title)).thenReturn(question);

        Question viewedQuestion = questionService.veiwQuestion(title);
        assertEquals(question, viewedQuestion);

        verify(questionUtility).veiwQuestion(title);

    }

    @Test
    void testVeiwAllQuestion() {
        Map<String, Question> questionMap = new HashMap<>();
        questionMap.put("Title1", new Question("Title1", null, "Content1", null, 0));
        questionMap.put("Title2", new Question("Title2", null, "Content2", null, 0));
        when(questionUtility.veiwAllQuestion()).thenReturn(questionMap);

        Map<String, Question> viewedQuestionMap = questionService.veiwAllQuestion();
        assertEquals(questionMap, viewedQuestionMap);

        verify(questionUtility).veiwAllQuestion();
    }
}