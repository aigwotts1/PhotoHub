package com.epam.quiz.dao.tests;

import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.jpa.utilites.QuestionJPAUtility;
import com.epam.model.Question;
import com.epam.model.Quiz;

@ExtendWith(MockitoExtension.class)
class QuestionJPAUtilityTest {

	@Mock
	EntityManagerFactory entityManagerFactory;
	
    @Mock
    private EntityManager entityManager;

    @Mock
    private EntityTransaction transaction;
    
    @Mock
	private TypedQuery<Question> query;

    @InjectMocks
    private QuestionJPAUtility questionJPAUtility;

    @Test
    void createValidQuestionTest() {
        Question question = new Question();
        question.setTitle("valid title");

        when(entityManager.getTransaction()).thenReturn(transaction);

        Question result = questionJPAUtility.createQuestion(question);

        assertEquals(question, result);
        verify(transaction).begin();
        verify(entityManager).persist(question);
        verify(transaction).commit();
    }

    @Test
    void createQuestion_withInvalidTitle_shouldThrowIllegalArgumentException() {
        Question question = new Question();
        question.setTitle("valid title");
        when(entityManager.getTransaction()).thenReturn(transaction);
        doThrow(RuntimeException.class).when(entityManager).persist(question);
        assertThrows(IllegalArgumentException.class, () -> questionJPAUtility.createQuestion(question));
        verify(entityManager,times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
    }

    @Test
    void createQuestionWithEmptyTitle() {
    	Question question = new Question();
    	question.setTitle("");
    	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,() -> questionJPAUtility.createQuestion(question));
    	assertEquals("invalid title", exception.getMessage());
    }

    
	@Test
	void testRemoveQuestion() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);

		List<Question> questionList = new ArrayList<>();
		questionList.add(testQuestion);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);
		when(entityManager.getTransaction()).thenReturn(transaction);
		Question result = questionJPAUtility.removeQuestion("testQuestion");
		assertEquals(testQuestion, result);
		verify(entityManager, times(1)).createQuery(anyString());
		verify(query, times(1)).getResultList();
	}
	@Test
	void testRemoveQuestionFail() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		List<Question> questionList = new ArrayList<>();
		questionList.add(testQuestion);
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);
		when(entityManager.getTransaction()).thenReturn(transaction);      
		doThrow(RuntimeException.class).when(entityManager).remove(testQuestion);
        assertThrows(IllegalArgumentException.class, () -> questionJPAUtility.removeQuestion("testQuestion"));
        verify(entityManager, times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
	}
	@Test
	void sadPath_testRemoveQuestionFailIfQuizListPresent() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		List<Question> questionList = new ArrayList<>();
		questionList.add(testQuestion);
		Quiz quiz = new Quiz();
		testQuestion.setQuizList(List.of(quiz));
		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);
		Exception exception = assertThrows(IllegalArgumentException.class, () -> questionJPAUtility.removeQuestion("testQuestion"));
		assertEquals(exception.getMessage(),"Question is mapped to a quiz can't be deleted you can modify it");
		
	}
	@Test
	void removeQuestionWithEmptyTest() {
		Question question = new Question();
    	question.setTitle("");
    	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,() -> questionJPAUtility.removeQuestion(question.getTitle()));
    	assertEquals("invalid title", exception.getMessage());
	}
	
	@Test
	void removeQuestionWithQuestionNotFoundTest() {
		Question question = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		List<Question> listOfQuestion =new ArrayList<>();
		when(query.getResultList()).thenReturn(listOfQuestion);
        when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "testQuestion" + "'")).thenReturn(query);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> { questionJPAUtility.removeQuestion("testQuestion"); });
        verify(entityManager).createQuery("FROM Question q WHERE q.title = '" + "testQuestion" + "'");
        assertEquals(exception.getMessage(),"question not found");
	}
	
    @Test
	void testModifyQuestion() {
		Question question = new Question();
		question.setTitle("title");
        when(entityManager.getTransaction()).thenReturn(transaction);

		Question result = questionJPAUtility.modifyQuestion("title", question);

		verify(entityManager,times(2)).getTransaction();
		verify(transaction).begin();
		verify(entityManager).merge(question);
		verify(transaction).commit();
		assertSame(question, result);
	}
    @Test
	void testModifyQuestion_WithInvalidTitle() {

		Question question = new Question();
		question.setTitle("title");

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {questionJPAUtility.modifyQuestion("", question);});
		assertEquals("invalid title", exception.getMessage());
	}
    @Test
	void testModifyQuestionNotPresent() {
		Question testQuestion = new Question("testQuestion", Arrays.asList("a", "b", "c"), "easy","java", 1);
		when(entityManager.getTransaction()).thenReturn(transaction);
        doThrow(RuntimeException.class).when(entityManager).merge(any(Question.class));
        assertThrows(IllegalArgumentException.class, () -> questionJPAUtility.modifyQuestion("testQuestion", testQuestion));
        verify(entityManager, times(2)).getTransaction();
        verify(transaction).begin();
        verify(transaction).rollback();
	}
    @Test
	void testViewQuestion() {

		Question question = new Question();
		question.setTitle("title");
		List<Question> questionList = new ArrayList<>();
		questionList.add(question);
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "title" + "'")).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);

		Question result = questionJPAUtility.veiwQuestion("title");
		
		assertSame(question, result);
	}
    @Test
	void testViewQuestion_WithInvalidTitle() {

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {questionJPAUtility.veiwQuestion("");});
		assertEquals("No question Exist", exception.getMessage());
	}
	@Test
	void testViewQuestion_NotFound() {

		List<Question> questionList = new ArrayList<>();
		when(entityManager.createQuery("FROM Question q WHERE q.title = '" + "title" + "'")).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);

		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {questionJPAUtility.veiwQuestion("title");});
		assertEquals("question not found", exception.getMessage());
		verify(query).getResultList();
	}
	@Test
	void testViewAllQuestion() {

		List<Question> questionList = new ArrayList<>();
		Question question1 = new Question();
		question1.setTitle("title1");
		Question question2 = new Question();
		question2.setTitle("title2");
		questionList.add(question1);
		questionList.add(question2);
		when(entityManager.createQuery("FROM Question")).thenReturn(query);
		when(query.getResultList()).thenReturn(questionList);

		Map<String, Question> result = questionJPAUtility.veiwAllQuestion();

		verify(entityManager).createQuery("FROM Question");
		verify(query).getResultList();
		assertEquals(2, result.size());
		assertSame(question1, result.get("title1"));
		assertSame(question2, result.get("title2"));
	}
}