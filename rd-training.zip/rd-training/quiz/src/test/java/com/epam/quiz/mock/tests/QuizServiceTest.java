package com.epam.quiz.mock.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.epam.model.Question;
import com.epam.model.Quiz;
import com.epam.quiz.dao.QuizMarks;
import com.epam.quiz.dao.QuizUtility;
import com.epam.service.QuizService;

@ExtendWith(MockitoExtension.class)
class QuizServiceTest {

	@InjectMocks
    private QuizService quizService;

    @Mock
    private QuizUtility quizUtility;

    @Mock
    private QuizMarks quizMarks;

    Question question;
    List<Question> listOfQuestions;
    
    @BeforeEach
    void setup() {
    	question = new Question("JAVA IS GOOD?",Arrays.asList("Option1","Option2"),"easy","java",1);
        listOfQuestions = Arrays.asList(question);
    }
    
    @Test
    void testAddQuiz() {
        Quiz quiz = new Quiz("Math Quiz", listOfQuestions);

        when(quizUtility.addQuiz(quiz)).thenReturn(quiz);

        Quiz addedQuiz = quizService.addQuiz(quiz);
        assertEquals(quiz, addedQuiz);

        verify(quizUtility).addQuiz(quiz);
    }

    @Test
    void testRemoveQuiz() {
        String title = "Math Quiz";
        Quiz quiz = new Quiz(title, listOfQuestions);

        when(quizUtility.removeQuiz(title)).thenReturn(quiz);

        Quiz removedQuiz = quizService.removeQuiz(title);
        assertEquals(quiz, removedQuiz);

        verify(quizUtility).removeQuiz(title);
    }

    @Test
    void testModifyQuiz() {
        String title = "Math Quiz";
        Quiz quiz = new Quiz(title, listOfQuestions);

        when(quizUtility.modifyQuiz(title, quiz)).thenReturn(quiz);

        Quiz modifiedQuiz = quizService.modifyQuiz(title, quiz);
        assertEquals(quiz, modifiedQuiz);

        verify(quizUtility).modifyQuiz(title, quiz);
    }

    @Test
    void testViewQuiz() {
        String title = "Math Quiz";
        Quiz quiz = new Quiz(title, listOfQuestions);

        when(quizUtility.viewQuiz(title)).thenReturn(quiz);

        Quiz viewedQuiz = quizService.viewQuiz(title);
        assertEquals(quiz, viewedQuiz);

        verify(quizUtility).viewQuiz(title);
    }
    @Test
	void testViewAllQuiz() {
		Map<String, Quiz> expectedQuizzes = new HashMap<>();
		expectedQuizzes.put("Quiz 1", new Quiz("Quiz 1",listOfQuestions));
		expectedQuizzes.put("Quiz 2", new Quiz("Quiz 2",listOfQuestions));
		
		when(quizUtility.viewAllQuiz()).thenReturn(expectedQuizzes);
		
		Map<String, Quiz> actualQuizzes = quizService.viewAllQuiz();
		
		verify(quizUtility).viewAllQuiz();
		assertEquals(expectedQuizzes,actualQuizzes);
	}
	
	@Test
	void testAddMarksToQuizQuestion() {
		String title = "Quiz 1";
		int questionMarks = 10;
		Quiz quiz = new Quiz(title,listOfQuestions);
		Quiz expectedQuiz = new Quiz(title,listOfQuestions);
		expectedQuiz.setTotalMarks(questionMarks);
		
		when(quizMarks.addMarksToQuizQuestion(title, questionMarks, quiz)).thenReturn(expectedQuiz);
		
		Quiz actualQuiz = quizService.addMarksToQuizQuestion(title, questionMarks, quiz);
		
		verify(quizMarks).addMarksToQuizQuestion(title, questionMarks, quiz);
		assertEquals(expectedQuiz, actualQuiz);
	}
}