package com.epam.question.dao;

import java.util.HashMap;

import java.util.Map;

import com.epam.model.Question;

public class QuestionDatabase {
	
	private QuestionDatabase() {
	}
	private Map<String, Question> questionMap = new HashMap<>();
	
	private static class Singleton{
		private static QuestionDatabase questionDatabase = new QuestionDatabase();
	}
	public static QuestionDatabase getInstance() {
		return Singleton.questionDatabase;
	}
	
	public Map<String, Question> getQuestion() {
		return questionMap;
	} 
}