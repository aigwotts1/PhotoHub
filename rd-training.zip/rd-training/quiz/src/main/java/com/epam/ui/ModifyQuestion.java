package com.epam.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.jpa.utilites.QuestionJPAUtility;
import com.epam.model.Question;
import com.epam.question.dao.QuestionUtility;
import com.epam.service.QuestionService;

public class ModifyQuestion {

	QuestionService questionService = new QuestionService();
	private static final Logger LOGGER = LogManager.getLogger(ModifyQuestion.class);
	Scanner inputScanner = new Scanner(System.in);

	public Question updateQuestion() {
		QuestionUtility questionUtility = new QuestionJPAUtility();
		LOGGER.info("Enter Title of Question To Be Modified :");
		String oldTitle = inputScanner.nextLine();
		Question question = questionUtility.veiwQuestion(oldTitle);
		question.setTitle(oldTitle);
		LOGGER.info("Enter Number Of  Options i.e. 2/4 :");
		String option = inputScanner.nextLine();
		List<String> questionOptions = new ArrayList<>();
		String option1;
		String option2;
		String option3;
		String option4;
		switch(option) {
		case "4":
			LOGGER.info("Enter option 1 :");
			option1 = inputScanner.nextLine();
			LOGGER.info("Enter option 2 :");
			option2 = inputScanner.nextLine();
			LOGGER.info("Enter option 3 :");
			option3 = inputScanner.nextLine();
			LOGGER.info("Enter option 4 :");
			option4 = inputScanner.nextLine();
			questionOptions.add(option1);
			questionOptions.add(option2);
			questionOptions.add(option3);
			questionOptions.add(option4);
			break;
		case "2":
			LOGGER.info("Enter option 1 :");
			option1 = inputScanner.nextLine();
			LOGGER.info("Enter option 2 :");
			option2 = inputScanner.nextLine();
			questionOptions.add(option1);
			questionOptions.add(option2);
			break;
		default:
			throw new IllegalArgumentException("Enter Valid Number");
		}

		question.setOptions(questionOptions);
		LOGGER.info("Enter  Difiiculty i.e. Easy,Medium,etc : ");
		String dificulty = inputScanner.nextLine();
		question.setDificulty(dificulty);
		LOGGER.info("Enter Topics Tags : ");
		String topics = inputScanner.nextLine();
		LOGGER.info("Select Answer Number :");
		question.setTopics(topics);
		int answer = inputScanner.nextInt();
		question.setAnswer(answer);
		return questionService.modifyQuestion(oldTitle, question);
	}
}