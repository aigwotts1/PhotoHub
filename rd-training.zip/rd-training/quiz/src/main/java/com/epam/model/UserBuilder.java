package com.epam.model;

public class UserBuilder {
	
	private String userName;
	private String password;
	public UserBuilder setUserName(String userName) {
		this.userName = userName;
		return this;
	}
	public UserBuilder setPassword(String password) {
		this.password = password;
		return this;
	}
	public User getUserBuilder() {
		return new User(userName, password);
	}
}