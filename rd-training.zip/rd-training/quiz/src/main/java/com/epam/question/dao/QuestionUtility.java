package com.epam.question.dao;

import java.util.Map;

import com.epam.model.Question;

public interface QuestionUtility {

	Question createQuestion(Question question);
	Question removeQuestion(String title);
	Question modifyQuestion(String title, Question question);
	Question veiwQuestion(String title);
	Map<String, Question> veiwAllQuestion();
	
}