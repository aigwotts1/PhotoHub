package com.epam.service;

import java.util.Map;

import com.epam.jpa.utilites.QuestionJPAUtility;
import com.epam.model.Question;
import com.epam.question.dao.QuestionUtility;

public class QuestionService {
	
	public QuestionUtility questionUtility = new QuestionJPAUtility();

	public Question createQuestion(Question question) {
		return questionUtility.createQuestion(question);
	}

	public Question removeQuestion(String title) {
		return questionUtility.removeQuestion(title);
	}

	public Question modifyQuestion(String title, Question question) {
		 return questionUtility.modifyQuestion(title, question);
	}

	public Question veiwQuestion(String title) {
		return questionUtility.veiwQuestion(title);
	}

	public Map<String, Question> veiwAllQuestion() {
		 return questionUtility.veiwAllQuestion();
	}
}