package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.User;
import com.epam.service.QuizService;

public class QuizOperations {
	
	private static final Logger LOGGER = LogManager.getLogger(QuizOperations.class);
	QuizService quizLibrary = new QuizService();
	Scanner inputScanner = new Scanner(System.in);

    enum QuizOptions {	
    	
	    CREATE("1"),
	    UPDATE("2"),
	    DELETE("3"),
	    DISPLAY("4"),
		EXIT("5");

	    private final String option;
	    
	    QuizOptions(String option) {
	        this.option = option;
	    }

	    public String getOption() {
	        return option;
	    }
	}

	public User performQuizOperations() {
		
		LOGGER.info("TYPE: \n '1' to create a quiz \n '2' to modify a quiz \n '3' to delete a quiz \n '4' to view all quizes \n '5' to Go Back\n");

	    String input = inputScanner.nextLine();
	    User user = null;
	    QuizOptions selectedOption = null;

	    for (QuizOptions option : QuizOptions.values()) {
	        if (option.getOption().equals(input)) {
	            selectedOption = option;
	        }
	    }
	    if (selectedOption == null) {
	        throw new IllegalArgumentException("Enter Valid Number");
	    }

	    switch (selectedOption) {
	        case CREATE:
	        	//object naming
	            CreateQuiz create = new CreateQuiz();
	            create.createQuiz();
	            break;
	        case UPDATE:
	            UpdateQuiz update = new UpdateQuiz();
	            update.updateQuiz();
	            break;
	        case DELETE:
	            DeleteQuiz delete = new DeleteQuiz();
	            delete.deleteQuiz();
	            break;
	        case DISPLAY:
	            DisplayQuiz display = new DisplayQuiz();
	            display.viewAllQuiz();
	            break;
	        case EXIT:
	        	break;
	    }
	    return user;
	}
}