package com.epam.ui;

import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.Quiz;
import com.epam.quiz.dao.QuizDatabase;
import com.epam.service.QuizService;

public class DisplayQuiz {
	private static final Logger LOGGER = LogManager.getLogger(DisplayQuiz.class);
	QuizService quizService = new QuizService();
	QuizDatabase quizDatabase = QuizDatabase.getInstance();
//naming
	public QuizDatabase viewAllQuiz() {
		for (Map.Entry<String, Quiz> map : quizService.viewAllQuiz().entrySet()) {
			LOGGER.info("[" + map.getValue().getTitle() + ", " + map.getValue().getQuestionList() + "]\n");
		}
		return quizDatabase;
	}
}