package com.epam.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(unique = true)
	private String title;
	
	@ManyToMany(cascade = CascadeType.PERSIST)
	private List<Question> questionList = new ArrayList<>();
	
	private int totalMarks;

	public Quiz() {
	}

	public Quiz(String title, List<Question> questionList) {
		super();
		this.title = title;
		this.questionList = questionList;
	}

	public Quiz(String title, List<Question> questionList, int totalMarks) {
		super();
		this.title = title;
		this.questionList = questionList;
		this.totalMarks = totalMarks;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	@Override
	public int hashCode() {
		return Objects.hash(questionList, title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Quiz other = (Quiz) obj;
		return Objects.equals(questionList, other.questionList) && Objects.equals(title, other.title);
	}

	@Override
	public String toString() {
		return "Quiz [title=" + title + ", questionList=" + questionList + "]";
	}

	public int getTotalMarks() {
		int sumMarks = 0;
		for (Question question : questionList) {
			sumMarks += question.getMarks();
			this.totalMarks = sumMarks;
		}
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}
}