package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.question.dao.QuestionDatabase;
import com.epam.service.QuestionService;

public class ViewQuestion {
	
	QuestionService questionService = new QuestionService();
	QuestionDatabase questionDatabase = QuestionDatabase.getInstance();
	private static final Logger LOGGER = LogManager.getLogger(ViewQuestion.class);
	Scanner inputScanner = new Scanner(System.in);


	public QuestionDatabase viewQuestion() {
		LOGGER.info("Enter Title of Specific Question To View :");
		String quesTitle = inputScanner.nextLine();
		LOGGER.info(questionService.veiwQuestion(quesTitle));
		LOGGER.info("\n");
		return questionDatabase;
	}
}