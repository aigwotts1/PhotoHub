package com.epam.quiz.dao;

import com.epam.model.Quiz;

public interface QuizMarks {
	Quiz addMarksToQuizQuestion(String title, int questionMarks, Quiz quiz);
}
