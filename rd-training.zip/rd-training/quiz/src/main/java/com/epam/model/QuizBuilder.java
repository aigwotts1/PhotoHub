package com.epam.model;

import java.util.ArrayList;
import java.util.List;

public class QuizBuilder {
	
	private String title;
	List<Question> questionList = new ArrayList<>();
	
	public QuizBuilder setTitle(String title) {
		this.title = title;
		return this;
	}
	public QuizBuilder setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
		return this;
	}
	public Quiz getQuizBuilder() {
		return new Quiz(title, questionList);
	}
}
