package com.epam.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.Question;
import com.epam.service.QuestionService;

//naming
public class CreateQuestion {

	QuestionService questionService = new QuestionService();
	private static final Logger LOGGER = LogManager.getLogger(CreateQuestion.class);
	Scanner inputScanner = new Scanner(System.in);

	public Question addQuestion() {

		LOGGER.info("Enter Title Of New Question :");
		String questionTitle = inputScanner.nextLine();

		LOGGER.info("Enter Number Of  Options i.e. 2/4 :");
		String option = inputScanner.nextLine();

		List<String> questionOptions = new ArrayList<>();
		String option1;
		String option2;
		String option3;
		String option4;
		switch (option) {
		case "4":
			LOGGER.info("Enter option 1 :");
			option1 = inputScanner.nextLine();
			LOGGER.info("Enter option 2 :");
			option2 = inputScanner.nextLine();
			LOGGER.info("Enter option 3 :");
			option3 = inputScanner.nextLine();
			LOGGER.info("Enter option 4 :");
			option4 = inputScanner.nextLine();
			questionOptions.add(option1);
			questionOptions.add(option2);
			questionOptions.add(option3);
			questionOptions.add(option4);
			break;
		case "2":
			LOGGER.info("Enter option 1 :");
			option1 = inputScanner.nextLine();
			LOGGER.info("Enter option 2 :");
			option2 = inputScanner.nextLine();
			questionOptions.add(option1);
			questionOptions.add(option2);
			break;
		default:
			throw new IllegalArgumentException("Enter Valid Number");
		}

		LOGGER.info("Enter Difiiculty i.e. Easy,Medium,etc :");
		String dificulty = inputScanner.nextLine();
		LOGGER.info("Enter Topic Tags :");
		String topics = inputScanner.nextLine();
		LOGGER.info("Type Answer Number Which Is Correct :");
		int answer = inputScanner.nextInt();
		Question question = new Question(questionTitle, questionOptions, dificulty, topics, answer);
		return questionService.createQuestion(question);
	}
}