package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.question.dao.QuestionDatabase;
import com.epam.service.QuestionService;
//naming
public class RemoveQuestion {
	
	QuestionService questionService = new QuestionService();
	QuestionDatabase questionDatabase = QuestionDatabase.getInstance();
	private static final Logger LOGGER = LogManager.getLogger(RemoveQuestion.class);

	public QuestionDatabase deleteQuestion() {
		@SuppressWarnings("resource")
		Scanner inputScanner = new Scanner(System.in);
		LOGGER.info("Enter Title Of Question To Be Removed :");
		String questionTitle = inputScanner.nextLine();
		questionService.removeQuestion(questionTitle);
		return questionDatabase;
	}
}