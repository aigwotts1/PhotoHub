package com.epam.user.dao;

import java.util.HashMap;
import java.util.Map;

import com.epam.model.User;

public class UserDatabase {
	
	private UserDatabase() {
	}
	
	private static Map<String, User> userMap = new HashMap<>();
	
	private static class Singleton{
		private static UserDatabase userDatabase = new UserDatabase();
	}
	
	public static UserDatabase getInstance() {
		return Singleton.userDatabase;
	}
	
	public Map<String, User> getUsers() {
		return userMap;
	}
	public void setUserMap(String name, User user) {
		userMap.put(name, user);
	}	
}