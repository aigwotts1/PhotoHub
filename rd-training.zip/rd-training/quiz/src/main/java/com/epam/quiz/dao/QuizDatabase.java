package com.epam.quiz.dao;

import java.util.HashMap;
import java.util.Map;

import com.epam.model.Quiz;

public class QuizDatabase {
	
	private QuizDatabase() {
	}
	
	private static class Singleton{
		private static QuizDatabase quizDatabase = new QuizDatabase();
	}
	
	public static QuizDatabase getInstance() {
		return Singleton.quizDatabase;
	}
	private static Map<String, Quiz> quizMap = new HashMap<>();
	public Map<String, Quiz> getQuizes ()
	{
		return quizMap;
	}
}