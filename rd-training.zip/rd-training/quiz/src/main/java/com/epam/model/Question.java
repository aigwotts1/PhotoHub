package com.epam.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(unique = true)
	private String title;
	
	@ManyToMany(mappedBy = "questionList", cascade = CascadeType.PERSIST)
	private List<Quiz> quizList=new ArrayList<>();

	@ElementCollection
	private List<String> options = new ArrayList<>();
	
	private String dificulty;
	private String topics;
	private int answer;
	private int marks;

	public List<Quiz> getQuizList() {
		return quizList;
	}

	public void setQuizList(List<Quiz> quizList) {
		this.quizList = quizList;
	}
	
	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		if(title != null) {
			 this.title = title;	
		}
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		if(!options.isEmpty()) {
			this.options = options;
		}
	}

	public String getDificulty() {
		return dificulty;
	}

	public void setDificulty(String dificulty) {
		if(dificulty != null) {
			this.dificulty = dificulty;	
		}
	}

	public String getTopics() {
		return topics;
	}

	public void setTopics(String topics) {
		if(topics!=null) {
			this.topics = topics;		
		}
	}

	public int getAnswer() {
		return answer;
	}

	public void setAnswer(int answer) {
		if(answer != 0) {
			this.answer = answer;		
		}
	}

	@Override
	public int hashCode() {
		return Objects.hash(answer, dificulty, marks, options, topics, title);
    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Question other = (Question) obj;
		return Objects.equals(answer, other.answer) 
				&& Objects.equals(dificulty, other.dificulty)
				&& marks == other.marks 
				&& Objects.equals(options, other.options)
				&& Objects.equals(topics, other.topics)
				&& Objects.equals(title, other.title);
	}

	public Question() {
	}

	public Question(String title, List<String> options, String dificulty, String topics, int answer) {
		super();
		this.title = title;
		this.options = options;
		this.dificulty = dificulty;
		this.topics = topics;
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Question [title=" + title + ", options=" + options + ", dificulty=" + dificulty
				+ ", topics=" + topics + ", answer=" + answer + ", marks=" + marks + "]";
	}
}