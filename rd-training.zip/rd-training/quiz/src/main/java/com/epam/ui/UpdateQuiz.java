package com.epam.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.Question;
import com.epam.model.Quiz;
import com.epam.quiz.dao.QuizDatabase;
import com.epam.service.QuestionService;
import com.epam.service.QuizService;

public class UpdateQuiz {

	private static final Logger LOGGER = LogManager.getLogger(UpdateQuiz.class);
	QuizService quizService = new QuizService();
	QuizDatabase quizDatabase = QuizDatabase.getInstance();
//segregation
	public QuizDatabase updateQuiz() {
		@SuppressWarnings("resource")
		Scanner inputScanner = new Scanner(System.in);
		String newTitle;
		LOGGER.info("\nEnter title of the quiz to be modified: ");
		String title = inputScanner.nextLine();
		List<Question> questionsList = new ArrayList<>();
		while (true) {
			LOGGER.info("Enter question title: ");
			String questionTitle = inputScanner.nextLine();

			QuestionService questionLibrary = new QuestionService();
			if (!questionLibrary.veiwAllQuestion().containsKey(questionTitle)) {
				throw new IllegalArgumentException("No Question Exist with the Given Title");

			}
			LOGGER.info("Enter Quiz Details to be modified: ");
			 newTitle = inputScanner.nextLine();
			LOGGER.info("Enter Marks :");
			int questionMarks = Integer.parseInt(inputScanner.nextLine());
			Question question = questionLibrary.veiwAllQuestion().get(questionTitle);
			question.setMarks(questionMarks);
			questionsList.add(question);
			LOGGER.info("input '1' to exit or any other key to Modify Again: ");
			if (inputScanner.nextLine().equals("1"))
				break;
		}
		quizService.modifyQuiz(title, new Quiz(newTitle, questionsList));
		LOGGER.info("Quiz modified!");
		return quizDatabase;
	}
}