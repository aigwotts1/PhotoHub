package com.epam.jpa.utilites;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.epam.model.Question;
import com.epam.question.dao.QuestionUtility;

public class QuestionJPAUtility implements QuestionUtility{
	
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("my-local-mySql");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	private static final String INVALID_TITLE = "invalid title";

	@Override
	public Question createQuestion(Question question) {

		if (question.getTitle().isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);		
		}
		entityManager.getTransaction().begin();
		try {
			entityManager.persist(question);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			throw new IllegalArgumentException("Failed Creation");
		}
		return question;
	}

	@Override
	public Question removeQuestion(String title) {

		if (title.isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
		List<Question> questionList = entityManager.createQuery("FROM Question q WHERE q.title = '" + title + "'").getResultList();
		if (questionList.isEmpty()) {
			throw new IllegalArgumentException("question not found");
		}
		if(questionList.get(0).getQuizList().isEmpty()) {
		entityManager.getTransaction().begin();
		try {
			entityManager.remove(questionList.get(0));
			entityManager.getTransaction().commit();
		} 
		catch (Exception e) {
			entityManager.getTransaction().rollback();
			throw new IllegalArgumentException("Failed removal");
		}
		return questionList.get(0);
		}
		else {
			throw new IllegalArgumentException("Question is mapped to a quiz can't be deleted you can modify it");
		}
	}

	@Override
	public Question modifyQuestion(String title, Question question) {
		 if (title.isBlank()) {
			 throw new IllegalArgumentException(INVALID_TITLE);	 
		 }
		 entityManager.getTransaction().begin();
		 try {
		 entityManager.merge(question);
		 entityManager.getTransaction().commit();
		 } 
		 catch (Exception e) {
		 entityManager.getTransaction().rollback();
		 throw new IllegalArgumentException("Failed Creation");
		 }
		 return question;
	}

	@Override
	public Question veiwQuestion(String title) {
		if (title.isBlank()) {
			throw new IllegalArgumentException("No question Exist");
		}
		List<Question> questionList = entityManager.createQuery("FROM Question q WHERE q.title = '" + title + "'").getResultList();
		if (questionList.isEmpty()) {
			 throw new IllegalArgumentException("question not found");			 
		}
		return questionList.get(0);
	}

	@Override
	public Map<String, Question> veiwAllQuestion() {
		 List<Question> questionList = entityManager.createQuery("FROM Question").getResultList();
		 Map<String, Question> map = new HashMap<>();
		 for (int i = 0; i < questionList.size(); i++) {
		 map.put(questionList.get(i).getTitle(), questionList.get(i));
		 }
		 return map;
	}
}