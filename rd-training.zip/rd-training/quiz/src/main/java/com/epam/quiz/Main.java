package com.epam.quiz;

import com.epam.ui.App;

public class Main 
{
    public static void main(String[] args )
    {		
		App quizProgram = new App();
		quizProgram.startQuizProgram();
    }
}