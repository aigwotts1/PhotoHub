package com.epam.ui;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.Question;
import com.epam.question.dao.QuestionDatabase;
import com.epam.service.QuestionService;

public class ViewAllQuestions {

	QuestionService questionService = new QuestionService();
	QuestionDatabase questionDatabase = QuestionDatabase.getInstance();
	private static final Logger LOGGER = LogManager.getLogger(ViewAllQuestions.class);

	public QuestionDatabase viewAllQuestions() {
		Map<String, Question> questionMap = questionService.veiwAllQuestion();
		if (questionMap.isEmpty()) {
			throw new IllegalArgumentException("No Questions Added");
		}
		LOGGER.info(questionMap);
		LOGGER.info("\n");
		return questionDatabase;
	}
}