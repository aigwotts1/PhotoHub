package com.epam.quiz.dao;

import java.util.Map;

import com.epam.model.Quiz;

public interface QuizUtility {

	Quiz addQuiz(Quiz quiz);
	Quiz removeQuiz(String title);
	Quiz modifyQuiz(String title, Quiz quiz);
	Quiz viewQuiz(String title);
	Map<String, Quiz> viewAllQuiz();
}
