package com.epam.user.dao;

import java.util.Map;

import com.epam.model.User;
import com.epam.model.UserBuilder;

public class UserCollectionUtility implements UserUtility{
	
	UserDatabase userDetails = UserDatabase.getInstance();
	Map<String, User> users = userDetails.getUsers();

	@Override
	public User addUser(String userName, String password) {

		User user = new UserBuilder().setUserName(userName).setPassword(password).getUserBuilder();
		// dry
		users = userDetails.getUsers();
		if (users.containsKey(userName)) {
			throw new IllegalArgumentException("username already exists");
		}
		userDetails.getUsers().put(user.getUserName(), user);
		return user;
	}

	@Override
	public User addUser(String userName, String password, boolean isAdmin) {

		User user = new User(userName, password, isAdmin);
		users = userDetails.getUsers();
		// dry
		if (users.containsKey(userName)) {
			throw new IllegalArgumentException("username already exists");
		}
		users.put(user.getUserName(), user);
		return user;
	}

	@Override
	public User getUser(String userName, String password) {
		User result = null;
		users = userDetails.getUsers();
		if (users.containsKey(userName)) {
			if (users.get(userName).getPassword().equals(password)) {
				result = users.get(userName);
			} else {
				throw new IllegalArgumentException("username or password incorrect");
			}
		} else {
			throw new IllegalArgumentException("username or password incorrect");
		}
		return result;
	}
}