package com.epam.service;

import com.epam.jpa.utilites.UserJPAUtility;
import com.epam.model.User;
import com.epam.user.dao.UserUtility;

public class UserService {
	
	UserUtility userUtility = new UserJPAUtility();

	public User addUser(String username, String password) {
		return userUtility.addUser(username, password);
	}

	public User addUser(String userName, String password, boolean isAdmin) {
		return userUtility.addUser(userName, password, isAdmin);
	}

	public User getUser(String userName, String password) {
    	return userUtility.getUser(userName, password);
	}
}