package com.epam.ui;

//naming
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.User;

public class App {

	private static final Logger LOGGER = LogManager.getLogger(App.class);
	Scanner inputScanner = new Scanner(System.in);
	private static final String ONE = "1";
	private static final String TWO = "2";
	private static final String THREE = "3";

	public void startQuizProgram() {

		LOGGER.info("-----------Welcome To The Quiz :)-----------\n");

		do {
			LOGGER.info("\nTo Start The Quiz - Press '1' for Login or '2' for Register: \n");
			String input = inputScanner.nextLine();

//---------Check If The Person Is Admin Or User:----------------	
			User user = null;
			UserLogin login = new UserLogin();
			UserRegister register = new UserRegister();
			switch (input) {
			case ONE:
				user = login.loginUser();
				break;
			case TWO:
				user = register.registerUser();
				break;
			default:
				throw new IllegalArgumentException("Enter Valid Number\n");
			}

			if (user.isAdmin()) {
				// do while
				do {
					LOGGER.info("TYPE: \n '1' to modify question library \n '2' to modify quiz library \n '3' to exit \n");
					input = inputScanner.nextLine();
					switch (input) {
//----------Question Library Code For Admins:-------------------					
					case ONE:
						QuestionOperations questionOperations = new QuestionOperations();
						questionOperations.performQuestionOperations();
						break;
//----------Quiz Library code For Admins:------------------------
					case TWO:
						QuizOperations quizOperations = new QuizOperations();
						quizOperations.performQuizOperations();
						break;
					case THREE:
						break;
					default:
						throw new IllegalArgumentException("Enter Valid Number\n");
					}
				} while(inputIsNotEqualToThree(input));
			}
//----------Quiz User Giving Quiz:-------------------------------			
			else {	
				UserQuizExam quizExam = new UserQuizExam();
				quizExam.takeQuiz();
				break;
			}
			LOGGER.info("Enter 1 to exit the Quiz or Press Enter to Continue Quiz:");
		} while (inputIsNotEqualToOne(inputScanner.nextLine()));
	}
	private boolean inputIsNotEqualToThree(String input) {
		return !input.equals(THREE);
	}
	private boolean inputIsNotEqualToOne(String input) {
		return !input.equals(ONE);
	}
}