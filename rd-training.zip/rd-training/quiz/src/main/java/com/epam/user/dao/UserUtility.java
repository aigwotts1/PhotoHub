package com.epam.user.dao;

import com.epam.model.User;

public interface UserUtility {
	User addUser(String userName, String password);
	User addUser(String userName, String password, boolean isAdmin);
	User getUser(String userName, String password);
}