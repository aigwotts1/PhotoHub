package com.epam.jpa.utilites;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.epam.model.Question;
import com.epam.model.Quiz;
import com.epam.question.dao.QuestionUtility;
import com.epam.quiz.dao.QuizMarks;
import com.epam.quiz.dao.QuizUtility;

public class QuizJPAUtility implements QuizUtility, QuizMarks {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("my-local-mySql");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	private static final String INVALID_TITLE = "invalid title";
	QuestionUtility questionUtility = new QuestionJPAUtility();
	
	@Override
	public Quiz addMarksToQuizQuestion(String title, int questionMarks, Quiz quiz) {
		Question question = questionUtility.veiwQuestion(title);
		question.setMarks(questionMarks);
		questionUtility.modifyQuestion(title, question);
		quiz.getQuestionList().add(question);
		return quiz;
	}

	@Override
	public Quiz addQuiz(Quiz quiz) {
		if (quiz.getTitle().isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
		entityManager.getTransaction().begin();
		try {
		for (Question question : quiz.getQuestionList()) {
			question.getQuizList().add(quiz);
		}
		entityManager.merge(quiz);
		entityManager.getTransaction().commit();
		}
		catch (Exception e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
			throw new IllegalArgumentException("failure");
		}
		return quiz;
	}

	@Override
	public Quiz removeQuiz(String title) {

		if (title.isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
		List<Quiz> quizList = entityManager.createQuery("FROM Quiz q WHERE q.title = '" + title + "'").getResultList();
		if (quizList.isEmpty()) {
			throw new IllegalArgumentException("not found");
		}
		entityManager.getTransaction().begin();
		try {
			for (Question question : quizList.get(0).getQuestionList()) {
				question.getQuizList().remove(quizList.get(0));
			}
			entityManager.remove(quizList.get(0));
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
			throw new IllegalArgumentException("quiz not found");

		}
		return quizList.get(0);
	}

	@Override
	public Quiz modifyQuiz(String title, Quiz quiz) {

		if (title.isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
		List<Quiz> quizList = entityManager.createQuery("FROM Quiz q WHERE q.title='" + title + "'").getResultList();
		if (quizList.isEmpty()) {
			throw new NullPointerException();
		}
		Quiz modifiedQuiz = quizList.get(0);
		modifiedQuiz.setQuestionList(quiz.getQuestionList());
		entityManager.getTransaction().begin();
		try {
			entityManager.persist(modifiedQuiz);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
			throw new IllegalArgumentException("failure");
		}
		return modifiedQuiz;
	}

	@Override
	public Quiz viewQuiz(String title) {

		if (title.isBlank()) {
			throw new IllegalArgumentException(INVALID_TITLE);
		}
		List<Quiz> quizList = entityManager.createQuery("FROM Quiz q WHERE q.title = '" + title + "'").getResultList();
		return quizList.get(0);
	}

	@Override
	public Map<String, Quiz> viewAllQuiz() {
		List<Quiz> quizList = entityManager.createQuery("FROM Quiz").getResultList();
		Map<String, Quiz> quizMap = new HashMap<>();
		for (int i = 0; i < quizList.size(); i++) {
			quizMap.put(quizList.get(i).getTitle(), quizList.get(i));
		}
		return quizMap;
	}
}