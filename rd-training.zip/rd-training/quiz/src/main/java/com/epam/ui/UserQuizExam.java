package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.Question;
import com.epam.model.Quiz;
import com.epam.service.QuizService;

public class UserQuizExam {

	private static final Logger LOGGER = LogManager.getLogger(UserQuizExam.class);
	Scanner inputScanner = new Scanner(System.in);
	
	public Quiz takeQuiz() {
		LOGGER.info("Enter quiz title: ");
		String userInput = inputScanner.nextLine();
		int marksScored = 0;
		QuizService quizLibrary = new QuizService();
		Quiz quiz = quizLibrary.viewAllQuiz().get(userInput);

		if (quiz == null) {
			throw new IllegalArgumentException("quiz not found");
		}

		for (Question question : quiz.getQuestionList()) {
			LOGGER.info("%s%n", question.getTitle());
			for (int i = 0; i < question.getOptions().size(); i++) {
				if (question.getOptions().get(i) == null) {
					break;
				}
				LOGGER.info("%d. %s%n", i + 1, question.getOptions().get(i));
			}
			LOGGER.info("your answer: ");
			int answer = inputScanner.nextInt();
			if (answer == question.getAnswer()) {
				marksScored += question.getMarks();
			}
			LOGGER.info("-----------------------------------------------------\n");
		}
		LOGGER.info("your score: %d/%d%n", marksScored, quiz.getTotalMarks());
		return quiz;
	}
}