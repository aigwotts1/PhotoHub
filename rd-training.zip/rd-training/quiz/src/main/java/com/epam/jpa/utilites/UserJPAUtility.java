package com.epam.jpa.utilites;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.epam.model.User;
import com.epam.user.dao.UserUtility;

public class UserJPAUtility implements UserUtility{
	
	
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("my-local-mySql");
	EntityManager entityManager = entityManagerFactory.createEntityManager();

	@Override
	public User addUser(String username, String password) throws IllegalArgumentException {

		if (username.isBlank()) {
			throw new IllegalArgumentException("username can't be empty");
		}
		if (password.isBlank()) {
			throw new IllegalArgumentException("password can't be empty");
		}

		User user = new User(username, password);
		user.setUserName(username);
		user.setPassword(password);
		user.setIsAdmin(false);
		entityManager.getTransaction().begin();
		try {
			entityManager.persist(user);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
			throw new IllegalArgumentException("failure");
		}
		return user;
	}

	@Override
	public User addUser(String userName, String password, boolean isAdmin) throws IllegalArgumentException {

		if (userName.isBlank()) {
			throw new IllegalArgumentException("username can't be empty");
		}
		if (password.isBlank()) {
			throw new IllegalArgumentException("password can't be empty");
		}

		User user = new User();
		user.setUserName(userName);
		user.setPassword(password);
		user.setIsAdmin(isAdmin);
		entityManager.getTransaction().begin();
		try {
			entityManager.persist(user);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			e.printStackTrace();
			throw new IllegalArgumentException("failure");
		}
		return user;
	}

	@Override
	public User getUser(String userName, String password) throws IllegalArgumentException {
		if (userName.isBlank()) {
			throw new IllegalArgumentException("username can't be blank");		
		}
		if (password.isBlank()) {
			throw new IllegalArgumentException("password can't be blank");
		}

		List<User> list = entityManager.createQuery("FROM User u WHERE u.userName='" + userName + "'").getResultList();

		if (list.isEmpty()) {
			throw new IllegalArgumentException("username or password incorrect");
		}
		return list.get(0);
	}
}