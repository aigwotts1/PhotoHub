package com.epam.question.dao;

import java.util.Map;

import com.epam.model.Question;

public class QuestionCollectionsUtility implements QuestionUtility{
	QuestionDatabase questionDatabase =  QuestionDatabase.getInstance();
	Map<String, Question> questions = questionDatabase.getQuestion();
	private static final String NO_QUESTION_EXIST = "No question Exist";

	public Question createQuestion(Question question) throws IllegalArgumentException {
		if (question.getTitle().isBlank()) {
			throw new IllegalArgumentException("invalid title");		
		}
		questions.put(question.getTitle(), question);
		return question;
	}

	public Question removeQuestion(String title) throws IllegalArgumentException {
		if (questions.get(title) == null) {
			throw new IllegalArgumentException(NO_QUESTION_EXIST);
		}
		return questions.remove(title);
	}

	public Question modifyQuestion(String title, Question question) throws IllegalArgumentException {

		if (questions.get(title) == null) {
			throw new IllegalArgumentException(NO_QUESTION_EXIST);
		}
		questions.remove(title);
		Question ques = question;
		return questions.put(title, ques);
	}

	public Question veiwQuestion(String title) throws IllegalArgumentException {
		if (questions.get(title) == null) {
			throw new IllegalArgumentException(NO_QUESTION_EXIST);			
		}
		return questions.get(title);
	}

	public Map<String, Question> veiwAllQuestion() throws IllegalArgumentException {
		return questions;
	}
}