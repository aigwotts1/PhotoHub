package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.epam.model.User;
import com.epam.service.UserService;

public class UserRegister {
//same
	private static final Logger LOGGER = LogManager.getLogger(UserRegister.class);
	UserService service = new UserService();
	Scanner input = new Scanner(System.in);

	public User registerUser() {
		LOGGER.info("Enter Username :");
		String userName = input.nextLine();
		LOGGER.info("Enter Password :");
		String password = input.nextLine();
		LOGGER.info("Press 1 if user is set to be Admin or Press Enter If Not :");

		String check = input.nextLine();
		boolean isUserAdmin = false;
		if(check.equals("1")) {
			isUserAdmin = true;
			LOGGER.info("User Registered :)\n");
			return service.addUser(userName, password, isUserAdmin);
		}
		LOGGER.info("User Registered :)\n");
		return service.addUser(userName, password);
	}
}