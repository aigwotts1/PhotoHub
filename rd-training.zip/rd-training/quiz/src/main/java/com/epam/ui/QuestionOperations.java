package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.User;

public class QuestionOperations {
	
	private static final Logger LOGGER = LogManager.getLogger(QuestionOperations.class);
	Scanner inputScanner = new Scanner(System.in);

	enum UserOption {
		
		ADD_QUESTION("1"),
		REMOVE_QUESTION("2"),
		MODIFY_QUESTION("3"),
		VIEW_SPECIFIC_QUESTION("4"),
		VIEW_ALL_QUESTIONS("5"),
		BACK("6");

		private final String option;

		UserOption(String option) {
			this.option = option;
		}

		public String getOption() {
			return option;
		}
	}

	public User performQuestionOperations() {
		
		User user = null;	
		LOGGER.info("Press 1 to Add Question :\n");
		LOGGER.info("Press 2 to Remove Question :\n");
		LOGGER.info("Press 3 to Modify Question :\n");
		LOGGER.info("Press 4 to View Specific Question :\n");
		LOGGER.info("Press 5 to View All Questions :\n");
		LOGGER.info("Press 6 to Go Back :\n");

			String input = inputScanner.nextLine();
		    UserOption selectedOption = null;

		    for (UserOption option : UserOption.values()) {
		        if (option.getOption().equals(input)) {
		            selectedOption = option;
		        }
		    }
		    if (selectedOption == null) {
		        throw new IllegalArgumentException("Enter Valid Number");
		    }
			switch (selectedOption) {
				case ADD_QUESTION:
					CreateQuestion createQuestion = new CreateQuestion();
					createQuestion.addQuestion();
					break;

				case REMOVE_QUESTION:
					RemoveQuestion removeQuestion = new RemoveQuestion();
					removeQuestion.deleteQuestion();
					break;

				case MODIFY_QUESTION:
					ModifyQuestion modifyQuestion = new ModifyQuestion();
					modifyQuestion.updateQuestion();
					break;

				case VIEW_SPECIFIC_QUESTION:
					ViewQuestion viewQuestion = new ViewQuestion();
					viewQuestion.viewQuestion();
					break;

				case VIEW_ALL_QUESTIONS:
					ViewAllQuestions viewAll = new ViewAllQuestions();
					viewAll.viewAllQuestions();
					break;

				case BACK:
					break;
			}		
		return user;
	}
}