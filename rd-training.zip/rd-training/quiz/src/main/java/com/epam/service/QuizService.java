package com.epam.service;

import java.util.Map;

import com.epam.jpa.utilites.QuizJPAUtility;
import com.epam.model.Quiz;
import com.epam.quiz.dao.QuizMarks;
import com.epam.quiz.dao.QuizUtility;

public class QuizService {

	public QuizUtility quizUtility = new QuizJPAUtility();
	public QuizMarks quizMarks = new QuizJPAUtility();
	
	public Quiz addQuiz(Quiz quiz) {
		return quizUtility.addQuiz(quiz);
	}

	public Quiz removeQuiz(String title) {
		return quizUtility.removeQuiz(title);
	}

	public Quiz modifyQuiz(String title, Quiz quiz) {
		return quizUtility.modifyQuiz(title, quiz);
	}

	public Quiz viewQuiz(String title) {
		return quizUtility.viewQuiz(title);
	}

	public Map<String, Quiz> viewAllQuiz() {
		return quizUtility.viewAllQuiz();
	}

	public Quiz addMarksToQuizQuestion(String title, int questionMarks, Quiz quiz) {
		return quizMarks.addMarksToQuizQuestion(title, questionMarks, quiz);
	}
}