package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.quiz.dao.QuizDatabase;
import com.epam.service.QuizService;

public class DeleteQuiz {

	private static final Logger LOGGER = LogManager.getLogger(DeleteQuiz.class);
	QuizService quizService = new QuizService();
	QuizDatabase quizDatabase = QuizDatabase.getInstance();
	Scanner inputScanner = new Scanner(System.in);

	public QuizDatabase deleteQuiz() {

		LOGGER.info("\nEnter the title of the quiz to be deleted: ");
    	String title = inputScanner.nextLine();
    	quizService.removeQuiz(title);
    	LOGGER.info("Quiz removed!");
		return quizDatabase;
	}
}
