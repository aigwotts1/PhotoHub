package com.epam.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.Question;
import com.epam.model.Quiz;
import com.epam.service.QuizService;

public class CreateQuiz {

	private static final Logger LOGGER = LogManager.getLogger(CreateQuiz.class);
	QuizService quizService = new QuizService();
    Scanner scanner = new Scanner(System.in);

	public Quiz createQuiz() {
		LOGGER.info("\nEnter title: ");
		String title = scanner.nextLine();
		List<Question> questionsList = new ArrayList<>();
		Quiz quiz = new Quiz(title, questionsList);
		String input;
		do {
			LOGGER.info("Enter question title :");
			String questionTitle = scanner.nextLine();
			LOGGER.info("Enter marks: ");
			int questionMarks = scanner.nextInt();
			quizService.addMarksToQuizQuestion(questionTitle, questionMarks, quiz);
			LOGGER.info("\ninput '1' to add more question or any other key to exit: ");
			scanner = new Scanner(System.in);
			input = scanner.nextLine();
		}
		while(input.equals("1"));
		LOGGER.info("----------Quiz added :)------------- \n");
		return quizService.addQuiz(quiz);
		
	}

}
