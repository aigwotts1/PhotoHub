package com.epam.quiz.dao;

import java.util.Map;

import com.epam.model.Quiz;

public class QuizCollectionsUtility implements QuizUtility {

	QuizDatabase quizDatabase = QuizDatabase.getInstance();
	private static final String NO_QUESTION_EXIST = "No question Exist";

	@Override
	public Quiz addQuiz(Quiz quiz) {
		quizDatabase.getQuizes().put(quiz.getTitle(), quiz);
		return quiz;
	}
	
	@Override
	public Quiz removeQuiz(String title) {
		if (title.isEmpty()) {
			throw new IllegalArgumentException("Title is Empty!");
		}
		if (!quizDatabase.getQuizes().containsKey(title)) {
			throw new IllegalArgumentException(NO_QUESTION_EXIST);
		}
		return quizDatabase.getQuizes().remove(title);
	}

	@Override
	public Quiz modifyQuiz(String quizTitle, Quiz quiz) {
		// move to seperate method
		if (!quizDatabase.getQuizes().containsKey(quizTitle)) {
			throw new IllegalArgumentException(NO_QUESTION_EXIST);
		} 	
		return quizDatabase.getQuizes().put(quizTitle, quiz);
	}

	@Override
	public Quiz viewQuiz(String title) {	
		if (!quizDatabase.getQuizes().containsKey(title)) {
			throw new IllegalArgumentException(NO_QUESTION_EXIST);
		}
		return quizDatabase.getQuizes().get(title);
	}

	@Override
	public Map<String, Quiz> viewAllQuiz() {
		return quizDatabase.getQuizes();
	}
}