package com.epam.ui;

import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.model.User;
import com.epam.service.UserService;

public class UserLogin {
	
	private static final Logger LOGGER = LogManager.getLogger(UserLogin.class);
	public User loginUser() {
		
		User user = null;
		@SuppressWarnings("resource")
		Scanner inputScanner = new Scanner(System.in);
		LOGGER.info("\nEnter Username: \n");
		String username = inputScanner.nextLine();
		LOGGER.info("Enter Password: \n");
		String password = inputScanner.nextLine();
		
		UserService userService = new UserService();
		user = userService.getUser(username, password);
		LOGGER.info("\n---------Login Success :)--------------\n");
		return user;
	}
}